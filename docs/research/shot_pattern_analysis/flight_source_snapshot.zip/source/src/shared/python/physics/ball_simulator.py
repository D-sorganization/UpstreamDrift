"""Core ball flight simulator using the Rust kernel for RK4 integration.

This submodule contains BallFlightSimulator, the base simulator that delegates
trajectory integration to the upstream_physics Rust wheel. Extracted from
ball_flight_physics.py as part of P1 sprint decomposition (issue #2486).

.. deprecated::
    The RK4 integration loop has a Rust kernel equivalent in ``upstream_physics``
    (via ``rust_kernel.create_integrator_config``). New simulation code should use
    the Rust-backed integrator for native performance and WASM parity with the
    React frontend.
"""

from __future__ import annotations

from typing import Any

import math
import numpy as np

from src.shared.python.core.contracts import invariant, postcondition, precondition
from src.shared.python.core.physics_constants import GOLF_BALL_DRAG_COEFFICIENT
from src.shared.python.logging_pkg.logging_config import get_logger
from src.shared.python.physics.ball_launch_conditions import (
    EnvironmentalConditions,
    LaunchConditions,
    TrajectoryPoint,
)
from src.shared.python.physics.ball_properties import (
    MAX_LIFT_COEFFICIENT,
    MIN_SPEED_THRESHOLD,
    NUMERICAL_EPSILON,
    PENNER_LIFT_EXPONENT,
    PENNER_LIFT_SCALE,
    BallProperties,
)
from src.shared.python.physics.ball_trajectory_analysis import TrajectoryAnalysisMixin

logger = get_logger(__name__)


@invariant(lambda self: self.ball.mass > 0, "Ball mass must be positive")
@invariant(lambda self: self.environment.gravity > 0, "Gravity must be positive")
class BallFlightSimulator(TrajectoryAnalysisMixin):
    """Refactored Ball Flight Simulator (Orthogonality-focused)."""

    def __init__(
        self,
        ball: BallProperties | None = None,
        env: EnvironmentalConditions | None = None,
        environment: EnvironmentalConditions | None = None,
    ) -> None:
        self.ball = ball or BallProperties()
        self.environment = env or environment or EnvironmentalConditions()

    @precondition(
        lambda self, launch, max_time=10.0, dt=0.01: (
            launch is not None and launch.velocity >= 0
        ),
        "Launch conditions must not be None and velocity must be non-negative",
    )
    @precondition(
        lambda self, launch, max_time=10.0, dt=0.01: max_time > 0 and dt > 0,
        "Max time and time step must be positive",
    )
    @postcondition(
        lambda result: result is not None and isinstance(result, list),
        "Trajectory must be returned as a non-None list",
    )
    def simulate_trajectory(
        self, launch: LaunchConditions, max_time: float = 10.0, dt: float = 0.01
    ) -> list[TrajectoryPoint]:
        """Simulate trajectory from m/s, radian angles, and RPM spin.

        When the upstream_physics Rust wheel is installed, the RK4 integration
        is delegated to the native Rust implementation for performance.
        Otherwise, falls back to the Python/Numba implementation.
        """
        return self._post_process_rust(
            self._simulate_native(launch, max_time, dt), launch
        )

    def simulate_landing(
        self, launch: LaunchConditions, max_time: float = 10.0, dt: float = 0.01
    ) -> np.ndarray:
        """Return interpolated first ground-contact position in metres.

        Uses precisely the same native RK4 trajectory as ``simulate_trajectory``;
        only its last two states cross into Python. No per-sample force or
        trajectory-object reconstruction is performed. Raises if the time limit
        is reached before ground contact. Linear interpolation matches the
        historical shot-pattern landing convention.
        """
        result = self._simulate_native(launch, max_time, dt)
        points = result.get_final_points()
        if len(points) < 2 or points[-1].z > 0.0:
            raise RuntimeError("flight exceeded max_time before landing")
        previous, final = points
        prev = np.array([previous.x, previous.y, previous.z])
        end = np.array([final.x, final.y, final.z])
        fraction = previous.z / (previous.z - final.z) if previous.z > 0 else 1.0
        return prev + fraction * (end - prev)

    def _simulate_native(
        self, launch: LaunchConditions, max_time: float, dt: float
    ) -> Any:
        """Shared native call; retain all states inside Rust until requested."""
        if (
            not math.isfinite(max_time)
            or not math.isfinite(dt)
            or min(max_time, dt) <= 0
        ):
            raise ValueError("max_time and dt must be finite and positive")
        if launch is None:
            raise ValueError("launch must be provided")
        self._validate_launch_contract(launch)
        from src.shared.python.physics.rust_kernel import is_rust_available

        if not is_rust_available():
            raise RuntimeError(
                "upstream-physics Rust kernel not found! Strict Rust Parity Enforced."
            )

        import upstream_physics  # type: ignore[import-untyped]

        v0 = launch.velocity
        ca, sa = np.cos(launch.azimuth_angle), np.sin(launch.azimuth_angle)
        cv, sv = np.cos(launch.launch_angle), np.sin(launch.launch_angle)

        initial = np.array([0.0, 0.0, 0.0, v0 * cv * ca, v0 * cv * sa, v0 * sv])
        omega = launch.spin_rate * 2 * np.pi / 60

        config = upstream_physics.IntegratorConfig(
            dt=dt, max_steps=int(max_time / dt) + 1
        )
        ball_props = upstream_physics.AeroBallProperties(
            mass=self.ball.mass,
            radius=self.ball.radius,
            # The kernel scales its Reynolds drag-crisis curve by this base
            # Cd, exactly as the enhanced engine scales cd_dimpled_sphere.
            # ball.cd0 is the spin polynomial's constant term, a different
            # model; passing it under-predicted drag by ~16 %.
            drag_coefficient=float(GOLF_BALL_DRAG_COEFFICIENT),
            spin_decay_rate=self.ball.spin_decay_rate,
        )

        air_props = upstream_physics.AirProperties(
            density=self.environment.air_density,
            viscosity=1.81e-5,
            temperature=self.environment.temperature,
            pressure=101325.0,
        )

        pos0 = [0.0, 0.0, 0.0]
        vel0 = [
            float(initial[3]),
            float(initial[4]),
            float(initial[5]),
        ]
        spin_axis = [
            float(launch.spin_axis[0]),
            float(launch.spin_axis[1]),
            float(launch.spin_axis[2]),
        ]
        gravity = [0.0, 0.0, float(-self.environment.gravity)]
        wind = [
            float(self.environment.wind_velocity[0]),
            float(self.environment.wind_velocity[1]),
            float(self.environment.wind_velocity[2]),
        ]
        logger.debug("Using Rust ball_flight trajectory (dt=%.4f)", dt)
        return upstream_physics.simulate_ball_trajectory_py(
            pos0,
            vel0,
            spin_axis,
            omega,
            gravity,
            wind,
            ball_props,
            air_props,
            config,
        )

    @staticmethod
    def _validate_launch_contract(launch: LaunchConditions) -> None:
        """Fail before the Rust boundary when launch units are inconsistent."""
        if not math.isfinite(launch.velocity) or launch.velocity < 0.0:
            raise ValueError(
                f"launch.velocity must be finite and >= 0 m/s; got {launch.velocity!r}"
            )
        if not math.isfinite(launch.launch_angle) or not (
            abs(launch.launch_angle) <= math.pi / 2.0
        ):
            raise ValueError(
                "launch.launch_angle must be radians within [-pi/2, pi/2] — "
                "did you pass degrees?"
            )
        if not math.isfinite(launch.azimuth_angle) or not (
            abs(launch.azimuth_angle) <= math.pi
        ):
            raise ValueError(
                "launch.azimuth_angle must be finite and in [-pi, pi] radians"
            )
        if not math.isfinite(launch.spin_rate) or launch.spin_rate < 0.0:
            raise ValueError(
                f"launch.spin_rate must be finite RPM and >= 0; got "
                f"{launch.spin_rate!r}"
            )
        spin_axis = np.asarray(launch.spin_axis, dtype=float)
        if spin_axis.shape != (3,) or not np.all(np.isfinite(spin_axis)):
            raise ValueError("launch.spin_axis must be a finite 3-vector")
        axis_norm = math.hypot(
            spin_axis[0], spin_axis[1], spin_axis[2]
        )  # ⚡ Bolt: math.hypot is ~5x faster than np.linalg.norm
        if abs(axis_norm - 1.0) >= 1e-6:
            raise ValueError(
                f"launch.spin_axis must be unit-norm; got norm {axis_norm!r}"
            )

    def _post_process_rust(
        self, rust_result: Any, launch: LaunchConditions
    ) -> list[TrajectoryPoint]:
        """Convert a Rust BallTrajectoryResult to a list of TrajectoryPoint objects.

        Forces are calculated once for the whole trajectory via the
        vectorized ``(3, N)`` batch path (``_calculate_forces`` dispatches on
        ``vel.ndim``), rather than once per point through the scalar path.
        """
        if launch is None:
            raise ValueError("launch must be provided")
        rust_points = list(rust_result.get_points())
        if not rust_points:
            return []

        times = [p.t for p in rust_points]
        pos = np.array(
            [
                [p.x for p in rust_points],
                [p.y for p in rust_points],
                [p.z for p in rust_points],
            ]
        )
        vel = np.array(
            [
                [p.vx for p in rust_points],
                [p.vy for p in rust_points],
                [p.vz for p in rust_points],
            ]
        )

        forces = self._calculate_forces(vel, launch)
        acc = (forces["gravity"] + forces["drag"] + forces["magnus"]) / self.ball.mass

        return [
            TrajectoryPoint(
                times[i],
                pos[:, i],
                vel[:, i],
                acc[:, i],
                {key: value[:, i] for key, value in forces.items()},
            )
            for i in range(len(rust_points))
        ]

    @precondition(
        lambda self, trajectory: trajectory is not None,
        "Trajectory must not be None",
    )
    @postcondition(
        lambda result: (
            result is not None and "carry_distance" in result and "max_height" in result
        ),
        "Analysis must include carry_distance and max_height",
    )
    def analyze_trajectory(self, trajectory: list[TrajectoryPoint]) -> dict:
        """Generate comprehensive analysis dictionary."""
        if not (trajectory is not None):
            raise ValueError("trajectory must be provided")
        # Delegate to mixin implementation (adds DbC decorators on top)
        return super().analyze_trajectory(trajectory)

    def _calculate_forces(
        self, vel: np.ndarray, launch: LaunchConditions
    ) -> dict[str, np.ndarray]:
        """Calculate forces on the ball (supports vectorized input)."""
        if vel is None:
            raise ValueError("vel must be provided")
        is_batch = vel.ndim > 1
        omega = launch.spin_rate * 2 * np.pi / 60

        shape = vel.shape
        gravity = np.zeros(shape)
        gravity[2, ...] = -self.ball.mass * self.environment.gravity

        if is_batch:
            drag, magnus = self._calculate_forces_batch(vel, omega, launch.spin_axis)
        else:
            drag, magnus = self._calculate_forces_single(vel, omega, launch)

        return {"gravity": gravity, "drag": drag, "magnus": magnus}

    def _calculate_forces_batch(
        self,
        vel: np.ndarray,
        omega: float,
        spin_axis: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Vectorized force calculation for batch velocity arrays (3, N)."""
        if vel is None:
            raise ValueError("vel must be provided")
        wind = (
            self.environment.wind_velocity.reshape(3, 1)
            if self.environment.wind_velocity.ndim == 1
            else self.environment.wind_velocity
        )
        rel_vel = vel - wind
        speed = np.sqrt(np.einsum("i...,i...->...", rel_vel, rel_vel))

        drag = np.zeros(vel.shape)
        magnus = np.zeros(vel.shape)

        mask = speed > MIN_SPEED_THRESHOLD
        if not np.any(mask):
            return drag, magnus

        valid_speed = speed[mask]
        valid_rel_vel = rel_vel[:, mask]
        s_ratio = (omega * self.ball.radius) / valid_speed
        aero_prefix = (
            0.5 * self.environment.air_density * self.ball.cross_sectional_area
        )

        # Drag
        cd = self.ball.cd0 + s_ratio * (self.ball.cd1 + s_ratio * self.ball.cd2)
        drag_force_mag = aero_prefix * cd * (valid_speed**2)
        drag[:, mask] = -drag_force_mag * (valid_rel_vel / valid_speed)

        # Magnus
        cl = np.minimum(
            MAX_LIFT_COEFFICIENT,
            PENNER_LIFT_SCALE
            * np.power(np.maximum(s_ratio, 0.0), PENNER_LIFT_EXPONENT),
        )
        magnus_force_mag = aero_prefix * cl * (valid_speed**2)

        axis = spin_axis.reshape(3, 1)
        cross = np.cross(axis, valid_rel_vel / valid_speed, axis=0)
        cross_norm = np.sqrt(np.einsum("i...,i...->...", cross, cross))
        cross_mask = cross_norm > NUMERICAL_EPSILON

        if np.any(cross_mask):
            factor = magnus_force_mag[cross_mask] / cross_norm[cross_mask]
            magnus[:, np.where(mask)[0][cross_mask]] = cross[:, cross_mask] * factor

        return drag, magnus

    def _calculate_forces_single(
        self,
        vel: np.ndarray,
        omega: float,
        launch: LaunchConditions,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Scalar force calculation for a single velocity vector (3,)."""
        if vel is None:
            raise ValueError("vel must be provided")
        rel_vel = vel - self.environment.wind_velocity
        speed = float(
            math.hypot(rel_vel[0], rel_vel[1], rel_vel[2])
        )  # ⚡ Bolt: math.hypot is ~5x faster than np.linalg.norm

        drag = np.zeros(vel.shape)
        magnus = np.zeros(vel.shape)

        if speed <= MIN_SPEED_THRESHOLD:
            return drag, magnus

        s_ratio = (omega * self.ball.radius) / speed
        cd = self.ball.calculate_cd(s_ratio)
        cl = self.ball.calculate_cl(s_ratio)
        aero_prefix = (
            0.5 * self.environment.air_density * self.ball.cross_sectional_area
        )

        drag = -(aero_prefix * cd * speed**2) * (rel_vel / speed)

        cross = np.cross(launch.spin_axis, rel_vel / speed)
        cross_norm = math.hypot(
            cross[0], cross[1], cross[2]
        )  # ⚡ Bolt: math.hypot is ~5x faster than np.linalg.norm
        if cross_norm > NUMERICAL_EPSILON:
            magnus = (aero_prefix * cl * speed**2) * (cross / cross_norm)

        return drag, magnus
