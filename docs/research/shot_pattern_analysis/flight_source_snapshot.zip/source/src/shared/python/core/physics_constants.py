"""Physical and mathematical constants with citations.

All constants must include:
1. Value with appropriate precision
2. Units in square brackets
3. Source citation
"""

import math

# Common source citations (DRY principle)
_SRC_INDUSTRY_STANDARD = "Industry Standard"
_SRC_WINTER_2009 = "Winter 2009"
_SRC_ANTHROPOMETRY = "Anthropometry"
_SRC_DERIVED = "Derived"
_SRC_PHYSICS = "Physics"


class PhysicalConstant(float):
    """A float subclass that carries physical unit and provenance metadata."""

    def __new__(
        cls, value: float, unit: str, source: str, description: str = ""
    ) -> "PhysicalConstant":
        return float.__new__(cls, value)

    def __init__(
        self, value: float, unit: str, source: str, description: str = ""
    ) -> None:
        if value is None:
            raise ValueError("value must be provided")
        self.unit = unit
        self.source = source
        self.description = description

    def __repr__(self) -> str:
        return f"PhysicalConstant({float(self):.4g}, unit='{self.unit}')"


# Mathematical constants
PI: float = math.pi  # [dimensionless] Ratio of circumference to diameter
E: float = math.e  # [dimensionless] Euler's number
PI_HALF: float = math.pi / 2
PI_QUARTER: float = math.pi / 4

# Spatial algebra constants
SPATIAL_DIM: int = 6
SPATIAL_LIN_DIM: int = 3
SPATIAL_ANG_DIM: int = 3

# Physical constants - SI units
GRAVITY_M_S2 = PhysicalConstant(
    9.80665, "m/s^2", "NIST CODATA 2018", "Standard gravity"
)
SPEED_OF_LIGHT_M_S = PhysicalConstant(
    299792458, "m/s", "SI Definition", "Speed of light in vacuum"
)
AIR_DENSITY_SEA_LEVEL_KG_M3 = PhysicalConstant(
    1.225, "kg/m^3", "ISA Standard Atmosphere", "Air density at sea level, 15C"
)
ATMOSPHERIC_PRESSURE_PA = PhysicalConstant(
    101325, "Pa", "ISA Standard Atmosphere", "Standard atmospheric pressure"
)
UNIVERSAL_GAS_CONSTANT_J_MOL_K = PhysicalConstant(
    8.314462618, "J/(mol K)", "CODATA 2018", "Molar gas constant"
)

# Golf-specific constants
GOLF_BALL_MASS_KG = PhysicalConstant(
    0.04593, "kg", "USGA Rule 5-1", "Maximum golf ball mass (1.620 oz)"
)
GOLF_BALL_DIAMETER_M = PhysicalConstant(
    0.04267, "m", "USGA Rule 5-2", "Minimum golf ball diameter (1.680 in)"
)
GOLF_BALL_RADIUS_M = PhysicalConstant(
    GOLF_BALL_DIAMETER_M / 2,
    "m",
    "USGA Rule 5-2",
    "Minimum golf ball radius (derived)",
)
GOLF_BALL_CROSS_SECTIONAL_AREA_M2 = PhysicalConstant(
    PI * (GOLF_BALL_DIAMETER_M / 2) ** 2,
    "m^2",
    "Derived",
    "Golf ball cross-sectional area",
)
GOLF_BALL_MOMENT_OF_INERTIA_KG_M2 = PhysicalConstant(
    (2 / 5) * GOLF_BALL_MASS_KG * (GOLF_BALL_DIAMETER_M / 2) ** 2,
    "kg*m^2",
    "Solid sphere approximation",
    "Golf ball moment of inertia",
)
GOLF_BALL_DRAG_COEFFICIENT = PhysicalConstant(
    0.25,
    "dimensionless",
    "Bearman & Harvey 1976",
    "Typical drag coefficient at Re=1.5e5",
)
GOLF_BALL_LIFT_COEFFICIENT = PhysicalConstant(
    0.15, "dimensionless", "Bearman & Harvey 1976", "Typical lift coefficient"
)
PUTTING_WIND_DRAG_COEFFICIENT = PhysicalConstant(
    0.4,
    "dimensionless",
    "Engineering estimate",
    "Effective drag coefficient for low-speed putting wind model",
)
PUTTING_WIND_FORCE_SCALING = PhysicalConstant(
    0.5,
    "dimensionless",
    "Model tuning",
    "Scaling factor to reduce wind influence on putting roll",
)

# Club specifications
DRIVER_LENGTH_MAX_M = PhysicalConstant(
    1.1684, "m", "USGA Rule 1-1c", "Max driver length (46 inches)"
)
DRIVER_LOFT_TYPICAL_DEG = PhysicalConstant(
    10.5, "degrees", "Modern Trade Average", "Typical driver loft"
)
IRON_LOFT_RANGE_DEG = (
    PhysicalConstant(
        18.0, "degrees", "Modern Trade Range", "Minimum typical iron loft"
    ),
    PhysicalConstant(
        64.0, "degrees", "Modern Trade Range", "Maximum typical iron loft"
    ),
)
IRON_7_LOFT_DEG = PhysicalConstant(
    34.0, "degrees", "Modern Trade Average", "Standard 7-iron loft"
)
PUTTER_LOFT_DEG = PhysicalConstant(3.0, "degrees", "Standard", "Standard putter loft")

# Clubhead MOI — Typical driver head about CG (perpendicular to face)
DRIVER_MOI_KG_M2 = PhysicalConstant(
    4.5e-4, "kg·m²", "Typical Driver Specs", "Driver clubhead MOI about CG"
)

# Course conditions
GREEN_SPEED_STIMP = PhysicalConstant(10.0, "ft", "USGA Stimpmeter", "Fast green speed")
ROUGH_HEIGHT_MM = PhysicalConstant(
    25.0, "mm", "Standard Maintenance", "Medium rough height"
)
BUNKER_DEPTH_MM = PhysicalConstant(
    100.0, "mm", "Standard Construction", "Standard bunker depth"
)

# Atmospheric conditions (Standard)
TEMPERATURE_C = PhysicalConstant(20.0, "C", "Standard", "Standard temperature")
PRESSURE_HPA = PhysicalConstant(
    1013.25, "hPa", "Standard", "Standard atmospheric pressure"
)
HUMIDITY_PERCENT = PhysicalConstant(50.0, "%", "Standard", "Standard relative humidity")

# Conversion factors (exact)
MPS_TO_KPH = PhysicalConstant(3.6, "(km/h)/(m/s)", "Exact", "m/s to km/h")
MPS_TO_MPH = PhysicalConstant(2.23694, "mph/(m/s)", "NIST", "m/s to mph")
MPH_TO_MPS = PhysicalConstant(0.44704, "(m/s)/mph", "NIST", "mph to m/s")
DEG_TO_RAD = PhysicalConstant(
    math.pi / 180, "rad/deg", "Mathematical", "Degrees to radians"
)
RAD_TO_DEG = PhysicalConstant(
    180 / math.pi, "deg/rad", "Mathematical", "Radians to degrees"
)
KG_TO_LB = PhysicalConstant(2.20462262185, "lb/kg", "NIST", "Kilograms to pounds")
M_TO_FT = PhysicalConstant(3.28084, "ft/m", "NIST", "Meters to feet")
FT_TO_M = PhysicalConstant(0.3048, "m/ft", "NIST", "Feet to meters")
FEET_TO_METERS = FT_TO_M  # Alias for compatibility
M_TO_YARD = PhysicalConstant(1.09361, "yd/m", "NIST", "Meters to yards")
YARD_TO_M = PhysicalConstant(0.9144, "m/yd", "NIST", "Yards to meters")
YARDS_TO_METERS = YARD_TO_M  # Alias for compatibility

# Material properties
GRAPHITE_DENSITY_KG_M3 = PhysicalConstant(
    1750, "kg/m^3", "Materials Handbook", "Typical golf shaft graphite"
)
STEEL_DENSITY_KG_M3 = PhysicalConstant(
    7850, "kg/m^3", "Materials Handbook", "Carbon steel"
)
TITANIUM_DENSITY_KG_M3 = PhysicalConstant(
    4506, "kg/m^3", "Materials Handbook", "Ti-6Al-4V alloy"
)
ALUMINUM_DENSITY_KG_M3 = PhysicalConstant(
    2700, "kg/m^3", "Materials Handbook", "6061-T6 aluminum"
)

# Aerodynamic coefficients
MAGNUS_COEFFICIENT = PhysicalConstant(
    0.25, "dimensionless", "Bearman & Harvey", "Magnus effect coefficient"
)
SPIN_DECAY_RATE_S = PhysicalConstant(0.05, "1/s", "Trackman Data", "Spin decay rate")
AIR_VISCOSITY_KG_M_S = PhysicalConstant(
    1.789e-5, "kg/(m s)", "ISO 2533", "Dynamic viscosity of air at 15C"
)

# Impact parameters
DRIVER_COR = PhysicalConstant(
    0.83,
    "dimensionless",
    "USGA/R&A CT limit (~0.83 equivalent COR)",
    "Coefficient of restitution for driver",
)
TYPICAL_CONTACT_DURATION_S = PhysicalConstant(
    0.0005, "s", "High-speed video studies", "Typical ball-clubface contact time"
)

# Golf club component masses (typical driver)
GOLF_GRIP_MASS_KG = PhysicalConstant(
    0.050, "kg", _SRC_INDUSTRY_STANDARD, "Typical golf grip mass (50g)"
)
GOLF_SHAFT_MASS_KG = PhysicalConstant(
    0.065, "kg", _SRC_INDUSTRY_STANDARD, "Typical graphite driver shaft mass (65g)"
)
GOLF_CLUBHEAD_MASS_KG = PhysicalConstant(
    0.200, "kg", _SRC_INDUSTRY_STANDARD, "Typical driver head mass (200g)"
)
GOLF_CLUB_TOTAL_MASS_KG = PhysicalConstant(
    0.315, "kg", _SRC_DERIVED, "Total driver mass (grip + shaft + head)"
)

# Biomechanics constants (average adult male)
HAND_MASS_KG = PhysicalConstant(
    0.4, "kg", _SRC_WINTER_2009, "Average hand mass (0.6% body mass for 67kg person)"
)
FOREARM_MASS_KG = PhysicalConstant(
    1.5, "kg", _SRC_WINTER_2009, "Average forearm mass (2.2% body mass)"
)
UPPER_ARM_MASS_KG = PhysicalConstant(
    2.5, "kg", _SRC_WINTER_2009, "Average upper arm mass (3.7% body mass)"
)
TORSO_MASS_KG = PhysicalConstant(
    35.0, "kg", _SRC_WINTER_2009, "Average torso mass (52% body mass)"
)

# Segment lengths (average adult male, 1.75m height)
HAND_LENGTH_M = PhysicalConstant(0.19, "m", _SRC_ANTHROPOMETRY, "Average hand length")
FOREARM_LENGTH_M = PhysicalConstant(
    0.27, "m", _SRC_ANTHROPOMETRY, "Average forearm length"
)
UPPER_ARM_LENGTH_M = PhysicalConstant(
    0.30, "m", _SRC_ANTHROPOMETRY, "Average upper arm length"
)

# Segment radii for collision geometry
TORSO_RADIUS_M = PhysicalConstant(
    0.14, "m", _SRC_ANTHROPOMETRY, "Average torso radius for collision"
)
ARM_SEGMENT_RADIUS_M = PhysicalConstant(
    0.035, "m", _SRC_ANTHROPOMETRY, "Average arm segment radius"
)
HAND_RADIUS_M = PhysicalConstant(
    0.025, "m", _SRC_ANTHROPOMETRY, "Average hand radius for collision"
)

# Inertia scaling factor (rod about end)
DEFAULT_ARM_INERTIA_SCALING = PhysicalConstant(
    1.0 / 12.0,
    "dimensionless",
    _SRC_PHYSICS,
    "Moment of inertia scaling for uniform rod",
)

# Numerical thresholds for aerodynamic calculations
MIN_SPEED_THRESHOLD_M_S = PhysicalConstant(
    0.1, "m/s", "Numerical", "Minimum speed for aerodynamic force calculation"
)
NUMERICAL_EPSILON: float = 1e-10  # For vector normalization
