from pathlib import Path
import hashlib,json
from vector_rasterization import render_vector
E=Path(__file__).resolve().parent;tools=json.loads((E/'native_tools.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift/docs/research/shot_pattern_analysis/phase2/final_figures_v1/social/details/seven_iron_lean0_curve1_rotation2_combined2/density')
sources={str(E/n):sha(E/n) for n in ['vector_rasterization.py','test_vector_rasterization.py']};records={}
for ext in ['pdf','svg']:
 p=base.with_suffix('.'+ext);h=sha(p);result=render_vector(p,h,E/('native_'+ext),tool_paths=tools)
 if not result['success'] or sha(p)!=h:raise ValueError('Native qualification failed')
 records[ext]=result
if sources!={p:sha(Path(p)) for p in sources}:raise ValueError('Helper drift')
(E/'native_review.json').write_text(json.dumps({'source_sha256':sources,'tools':tools,'records':records,'visual_approval':False,'source_bytes_unchanged':True},indent=2)+'\n')
print(json.dumps({k:v['actual_pixel_shape'] for k,v in records.items()}))
