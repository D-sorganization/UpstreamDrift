from pathlib import Path
p=Path('/tmp/p2-vector-raster-astra/vector_rasterization.py');s=p.read_text().replace('import sys\n','').replace('import json\n','import json\nimport os\n');a=s.index('try:\n    from scripts.');b=s.index('_NODE_SHARP_SCRIPT',a)
s=s[:a]+'''from scripts.research.shot_pattern_analysis.vector_inspection import inspect_vector

CONFIGURED_DENSITY_DPI: int = 144

'''+s[b:]
s=s.replace('''    if binary_path != DEFAULT_TOOL_PATHS["pdftoppm"]:
        return {"pdftoppm": "custom"}
''','')
a=s.index('    # Resolve tool paths');b=s.index('    stem = file_path.stem',a)
s=s[:a]+'''    if tool_paths is None:
        raise ValueError("An explicit tool_paths configuration is required")
    required = ("pdftoppm",) if vector_format == "pdf" else ("node", "sharp")
    tools: dict[str, str] = {}
    for key in required:
        if key not in tool_paths:
            raise ValueError(f"Missing required tool path: {key}")
        tool = Path(tool_paths[key]).resolve()
        if key == "sharp":
            valid = tool.is_dir() and (tool / "package.json").is_file()
        else:
            valid = tool.is_file() and os.access(tool, os.X_OK)
        if not valid:
            raise ValueError(f"Invalid tool path for {key}: {tool}")
        tools[key] = str(tool)

'''+s[b:]
a=s.index('    # Single external rendering');b=s.index('    renderer_versions:',a)
s=s[:a]+'''    target_dir.mkdir(parents=True, exist_ok=False)
    # Preserve diagnostics even when a native launch or post-render guard fails.
    launch_error: str | None = None
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        launch_error = f"{type(exc).__name__}: {exc}"
        proc = subprocess.CompletedProcess(cmd, -1, stdout="", stderr=launch_error)
    try:
        post_sha: str | None = _compute_sha256(file_path)
    except OSError:
        post_sha = None
    except FileNotFoundError:
        post_sha = None
    mutation = post_sha is None or post_sha.lower() != expected_sha256.lower()

'''+s[b:]
s=s.replace('''    if vector_format == "pdf":
        renderer_versions = _get_pdftoppm_version''','''    if vector_format == "pdf" and not mutation and proc.returncode == 0:
        renderer_versions = _get_pdftoppm_version''')
s=s.replace('''    if proc.returncode != 0:
        error = (''','''    if mutation:
        error = f"Post-render SHA256 mutation detected for {file_path.name}"
    elif proc.returncode != 0:
        error = (''')
s=s.replace('''    return {
        "success": success,''','''    record = {
        "success": success,''')
s=s.replace('''        "input_sha256": pre_sha,''','''        "input_sha256": pre_sha,
        "post_input_sha256": post_sha,
        "inspection": inspection,
        "source_sha256": _compute_sha256(Path(__file__)),
        "launch_error": launch_error,''')
s += '''
    (target_dir / "raster_diagnostics.json").write_text(
        json.dumps(record, indent=2) + "\\n", encoding="utf-8"
    )
    if mutation:
        raise ValueError(error)
    return record
'''
s=s.replace('''    except FileNotFoundError:
        post_sha = None
''','')
p.write_text(s)
