# Raster Helper Qualification Plan

Candidate code will not be inspected or edited until the parent confirms a stable snapshot. This plan uses the already qualified canonical `vector_inspection` contract, not assumptions about the mutable implementation.

## Required Boundary Checks

- Inspect the already-bound PDF/SVG through the canonical helper, retaining its source/runtime and exact input SHA. PDF physical dimensions come from `dimensions.media_box`; SVG physical dimensions come from `viewport` and/or `view_box`. Do not equate these schema shapes.
- Require explicit resolved tool paths and argument-vector subprocess execution. Reject missing tools and invalid configuration clearly. Do not silently search a personal repository or change import paths to find production code.
- Preserve subprocess arguments, exit code, stdout/stderr and failure identity when native conversion fails. Retain useful diagnostics if conversion succeeds but subsequent validation detects mutated input, missing PNG, corrupt PNG or unsuitable dimensions.
- Verify input hashes before and after conversion. Verify the generated PNG fully decodes, dimensions are positive and finite, and its final bytes match its recorded SHA. PNG validity is separate from visual approval.
- Never overwrite source vectors or accept an output path aliasing the input. Review collision behavior and ownership of temporary outputs. No generic cleanup beyond files created by this operation.
- Record actual raster dimensions and physical aspect. The installed Sharp density behavior differs from nominal Poppler density scaling; matching requested density is not evidence of equal pixels. Any comparison fitting must preserve aspect and avoid cropping.

## Meaningful Fault Tests

1. Wrong expected input hash rejects before launching a native tool.
2. Native nonzero exit retains nonempty stderr/stdout and exact command identity.
3. A native-success stub that writes no output is rejected.
4. A native-success stub that writes invalid PNG bytes is rejected.
5. A controlled input mutation during conversion is rejected with useful diagnostics retained.
6. A valid tiny PNG result passes decode/dimension/hash checks and retains `visual_approval: false`.
7. PDF and SVG physical viewport fields are extracted from their actual inspector schema, not fabricated fixtures.
8. Source/output collision and nonexistent tool cases fail before destructive side effects.

Tests should use small executable fixtures or narrowly controlled subprocess stubs, not source-string assertions. Exact API-dependent tests will be written after the stable candidate is read. Preserve actual red and green results; do not infer AGY test chronology from its final claims.

## Native Samples

After focused tests, use compact synthetic Matplotlib PDF/SVG fixtures plus one already completed original pair if useful. Reuse the known mature Poppler and Sharp invocation forms, explicit executable paths and canonical inspector. Record full input/output/tool/source hashes and actual dimensions, then decode the PNGs. No all-file batch, simulation, bootstrap, live supplemental read or publication acceptance is part of this qualification.
