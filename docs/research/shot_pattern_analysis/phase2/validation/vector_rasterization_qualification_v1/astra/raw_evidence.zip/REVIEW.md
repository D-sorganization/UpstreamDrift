# Raster Helper Independent Qualification

The corrected operational helper passes its bounded conversion/diagnostic contract. It does not approve visual quality, scientific labels or the full publication. The immutable initial candidate remains in `/tmp/p2-vector-raster-agy-terminal`; no repository, frozen producer or live v6 file was changed.

Independent red tests reproduced three initial defects: silent personal tool defaults, lost command/output evidence on input mutation, and directory creation before discovering a nonexistent tool. A fourth red test reproduced PNG replacement between decode and hash capture, yielding inconsistent dimensions and bytes. The corrected helper requires explicit tool paths and a normal canonical import, validates tool availability before creating output directories, preserves `raster_diagnostics.json` on native failures and input mutation, and compares PNG hashes before/after decode before declaring success.

The final suite passes 18 tests, including actual compact Matplotlib PDF/SVG exports, native nonzero/missing/corrupt outputs, controlled launch failure, input/output mutation, exact expected-input hash rejection and preserved output-directory ownership. Ruff, format and scoped Mypy pass without suppressions. The source is 321 lines and tests 436 lines.

The specified completed original seven-iron social-density pair also passed native conversion with unchanged source/helper hashes. PDF produced 1472×2536 pixels; SVG produced 1471×2534 pixels after the helper's explicitly recorded proportional `fit: inside` viewport-based resize. These are actual dimensions, not a pixel-equivalence result. The helper records original viewport/viewBox, maximum target dimensions, native command and versions, and each decoded PNG SHA. No crop/stretch or scientific plot rerender was performed.

The conversion helper is ready for root review and canonical relocation with import adaptation and requalification. Default tool discovery is intentionally absent: callers supply their runtime configuration. The caller still owns terminal, manifest and producer-source qualification. Returned `visual_approval` remains false.
