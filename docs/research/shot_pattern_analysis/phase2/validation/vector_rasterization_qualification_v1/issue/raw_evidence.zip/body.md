Independent Raster-Helper Review

Astra reproduced three defects in the provisional operational vector-rasterization helper associated with this validation work:

1. Omitted runtime configuration silently selected personal hardcoded repository/tool paths. Require an ordinary canonical import and explicit tool paths.
2. Input mutation after native execution raised before retaining command, stdout, stderr, exit code, and before/after hash evidence. Persist diagnostic evidence before reporting failure.
3. A nonexistent configured renderer created an output directory before leaking FileNotFoundError. Validate executable/module paths before creating output directories.

Three regression cases failed on the original candidate and pass with focused corrections; full independent qualification remains pending. No production simulation, live supplemental source, or generated study output has changed. Do not close this issue: fixes still require integration, final gates and a merged acceptance PR.
