"""Read-only diagnostics of two explicitly bound completed vector inventories."""
from pathlib import Path, PurePosixPath, PureWindowsPath
import collections, hashlib, json, re, sys, time
ROOT=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift')
sys.path.insert(0,str(ROOT))
from scripts.research.shot_pattern_analysis.vector_inspection import inspect_vector
OUT=Path('/tmp/p2-original-vector-diagnostics')
PHASE=ROOT/'docs/research/shot_pattern_analysis/phase2'
MANIFESTS={'final_figures_v1':'16e0a645fe840c24712c42467bffed59f3cb9204fabbeb8c5ce7289b3b9b2449','control_final_figures_v1':'47ea6e292883ea5958651e6786d5b73f2f463ebd004488d75c77f385036f34fd'}
HELPER=ROOT/'scripts/research/shot_pattern_analysis/vector_inspection.py'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def unique(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('Duplicate JSON key: '+k)
  d[k]=v
 return d
source=sha(HELPER); rows=[]; errors=[]; inventories={};start=time.time()
for dataset,expected in MANIFESTS.items():
 base=PHASE/dataset;manifest=base/'figure_manifest.json'
 if sha(manifest)!=expected:raise ValueError('Manifest mismatch: '+dataset)
 data=json.loads(manifest.read_text(),object_pairs_hook=unique); outputs=data['outputs'];seen=set();vectors={}
 for name,digest in outputs.items():
  if not isinstance(name,str) or not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Malformed output identity')
  posix=PurePosixPath(name)
  if '\\' in name or posix.is_absolute() or '..' in posix.parts or PureWindowsPath(name).drive:raise ValueError('Unsafe path: '+name)
  p=(base/name).resolve()
  if not p.is_relative_to(base.resolve()) or p in seen:raise ValueError('Escaped/duplicate resolved output: '+name)
  seen.add(p)
  if p.suffix.lower() in ('.pdf','.svg'):vectors[name]=digest
 actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and p.suffix.lower() in ('.pdf','.svg')}
 if actual!=set(vectors):raise ValueError('Unexpected or missing vector paths: '+dataset)
 inventories[dataset]={'manifest_sha256':expected,'expected_vectors':vectors,'counts':dict(collections.Counter(Path(n).suffix for n in vectors))}
 for name,digest in vectors.items():
  p=base/name
  try:
   diagnostic=inspect_vector(p,digest)
   rows.append({'dataset':dataset,'relative_path':name,'diagnostics':diagnostic})
  except Exception as exc:
   errors.append({'dataset':dataset,'relative_path':name,'expected_sha256':digest,'error_type':type(exc).__name__,'error':str(exc)})
  if (len(rows)+len(errors))%100==0:print('inspected',len(rows)+len(errors),'errors',len(errors),flush=True)
 if sha(manifest)!=expected:raise ValueError('Manifest mutated: '+dataset)
# Full end-of-run replay catches changes after an individual inspection.
for dataset,inventory in inventories.items():
 for name,digest in inventory['expected_vectors'].items():
  try:
   if sha(PHASE/dataset/name)!=digest:raise ValueError('Final SHA mismatch')
  except Exception as exc:errors.append({'dataset':dataset,'relative_path':name,'error_type':type(exc).__name__,'error':str(exc),'stage':'final_recheck'})
 if sha(PHASE/dataset/'figure_manifest.json')!=MANIFESTS[dataset]:raise ValueError('Final manifest drift')
if sha(HELPER)!=source:raise ValueError('Helper source changed')
(OUT/'diagnostics.json').write_text(json.dumps(rows,indent=2)+'\n')
result={'scope':'Completed original primary/control vector parsing only; no visual or scientific acceptance','format_diagnostics_pass':not errors,'full_publication_accepted':False,'source_sha256':source,'script_sha256':sha(Path(__file__)),'manifests':inventories,'inspected_successfully':len(rows),'attempted':sum(len(v['expected_vectors']) for v in inventories.values()),'errors':errors,'warning_files':[{'dataset':r['dataset'],'relative_path':r['relative_path'],'warnings':r['diagnostics'].get('warnings',[])} for r in rows if r['diagnostics'].get('warnings')],'source_manifest_and_asset_end_hash_checks_pass':not errors,'diagnostics_sha256':sha(OUT/'diagnostics.json'),'elapsed_seconds':time.time()-start}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n');print('DONE',result['attempted'],len(errors),'errors',len(result['warning_files']),'warning files',flush=True)
sys.exit(0 if not errors else 1)
