# Provisional Vector Helper Review

This review is limited to the mutable operational helper, with synthetic files under this review directory. No repository source or live v6 artifact was read or changed. `provisional_probes.json` binds the actual inspected source hash before and after the probes. No acceptance is granted.

## Confirmed Contract Gaps

1. A foreign XML namespace ending in `svg` is accepted. Require `{http://www.w3.org/2000/svg}svg` (or explicitly documented unnamespaced synthetic support), not arbitrary suffix matching.
2. An external `xml-stylesheet` processing instruction is ignored by both parse passes. Reject it through Expat's processing-instruction callback; no generic CSS engine is needed.
3. Non-image `data:` URIs are accepted despite the image-only contract. Restrict embedded resources to the actual Matplotlib image media used by qualified fixtures; preserve local glyph and clip references.
4. Duplicate IDs are silently deduplicated, making local-reference resolution ambiguous. Reject duplicates rather than reporting a valid local target.
5. A valid local `url(#id)` in a style element is rejected as external. Apply the same local-reference validation used for style attributes. Actual external import/reference cases must still fail.
6. PDF warning capture ends before lazy content/text/resource/image reads. Enclose the entire inspection in the warning/logger capture and test an extraction-time warning, including handler restoration on exceptions.
7. The SVG text extractor includes metadata descendants and omits tails after `tspan`. Extract text-element content coherently, exclude the entire metadata subtree, and label returned strings as text content, not proven visible glyphs. Comments remain separate.
8. Width-only SVG without height or viewBox is accepted while returning no usable viewport. Require a complete viewport pair or a valid viewBox for this narrowly defined export contract. This is an unsupported qualification case, not a claim that default-sized SVG is universally malformed.

## Production Compatibility

Matplotlib's inert SVG 1.1 public/system DOCTYPE should be explicitly accepted as an exact known declaration, with no internal subset, custom entity or external fetch. The candidate already approximates this allowlist; test the exact production declaration and malicious alternatives. RDF metadata namespace URLs are identifiers rather than resource dependencies. The helper must not treat parse success as page layout, glyph visibility, scientific-caption or visual acceptance.

Minimal follow-up tests should exercise these behaviors using compact synthetic files and a real compact Matplotlib PDF/SVG fixture. There is no need to implement a generic SVG renderer or rerun study statistics. The parent coordinator retains terminal/source/manifest gates; this helper inspects one already-bound file only.
