from pathlib import Path
import hashlib,sys,json
sys.path.insert(0,'/tmp/p2-vector-review-agy')
import vector_inspection as module
base=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift/docs/research/shot_pattern_analysis/phase2/final_figures_v1/social/details/seven_iron_lean0_curve1_rotation2_combined2/density')
e=Path('/tmp/p2-vector-review-astra');sources=[Path(module.__file__),Path('/tmp/p2-vector-review-agy/test_vector_inspection.py')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in sources};result={}
for suffix in ['.pdf','.svg']:
 p=base.with_suffix(suffix);h=sha(p);d=module.inspect_vector(p,h)
 if sha(p)!=h:raise ValueError('Sample changed')
 result[suffix]=d
if {str(p):sha(p) for p in sources}!=before:raise ValueError('Helper changed')
(e/'completed_sample.json').write_text(json.dumps({'source_sha256':before,'samples':result,'source_and_sample_bytes_unchanged':True,'visual_approval':False},indent=2)+'\n')
print(json.dumps({k:{'size':d['byte_size'],'images':d['embedded_image_count'],'warnings':d.get('warnings',[]),'text_count':len(d['text']),'comments':len(d.get('comments',[]))} for k,d in result.items()},indent=2))
