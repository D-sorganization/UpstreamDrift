from pathlib import Path
p=Path('/tmp/p2-vector-review-agy/vector_inspection.py');s=p.read_text();a=s.index('    page, _reader, pypdf_warnings = _read_pdf_page(file_path)');b=s.index('    _rehash_after_read(file_path, initial_sha)',a)
s=s[:a]+'''    log_handler = _ListLogHandler()
    logger = logging.getLogger("pypdf")
    logger.addHandler(log_handler)
    try:
        with warnings.catch_warnings(record=True) as recorded:
            warnings.simplefilter("always")
            page, _reader, pypdf_warnings = _read_pdf_page(file_path)
            media_box = _validate_box_coords(page.mediabox, "MediaBox")
            crop_box = _validate_box_coords(page.cropbox, "CropBox")
            _check_pdf_stream_nonempty(page)
            extracted_text = page.extract_text()
            font_inventory = _extract_font_resources(page)
            embedded_image_count = len(page.images)
            pypdf_warnings.extend(str(w.message) for w in recorded)
        pypdf_warnings.extend(log_handler.messages)
        pypdf_warnings = list(dict.fromkeys(pypdf_warnings))
    finally:
        logger.removeHandler(log_handler)

'''+s[b:]
s=s.replace('r"url\\(\\s*[\'\\\"]?([^\'\\\")]+)[\'\\\"]?\\s*\\)"','r"url\\(\\s*[\'\\\"]?([^\'\\\")]+)[\'\\\"]?\\s*\\)", re.IGNORECASE')
s=s.replace('_EXTERNAL_STYLE_REGEX = re.compile(r"@import\\s+|url\\(", re.IGNORECASE)','_EXTERNAL_STYLE_REGEX = re.compile(r"@import\\s+", re.IGNORECASE)')
s=s.replace('    parser.EntityDeclHandler = handle_entity','''    parser.EntityDeclHandler = handle_entity

    def handle_pi(target: str, data: str) -> None:
        if target.lower() == "xml-stylesheet":
            raise ValueError("External stylesheet processing instruction rejected")

    parser.ProcessingInstructionHandler = handle_pi
    parser.ExternalEntityRefHandler = lambda *_args: 0
    parser.SetParamEntityParsing(xml.parsers.expat.XML_PARAM_ENTITY_PARSING_NEVER)''')
s=s.replace('if root_tag != "svg" and not root_tag.endswith("}svg"):', 'if root_tag != "{http://www.w3.org/2000/svg}svg":')
s=s.replace('    elif clean_target.startswith("data:"):\n        return\n','')
s=s.replace('''    if "metadata" in tag:
        return 0

''','')
s=s.replace('''        elif clean_href.startswith("data:image/"):
            if clean_tag == "image":
                image_count += 1
        elif clean_href.startswith("data:"):
            pass''','''        elif clean_href.startswith("data:image/png;base64,") and clean_tag == "image":
            image_count += 1''')
s=s.replace('''            raise ValueError(
                f"External style or font resource rejected: {elem.text.strip()}"
            )

    href''','''            raise ValueError(
                f"External style or font resource rejected: {elem.text.strip()}"
            )
        for match in _URL_REF_REGEX.finditer(elem.text):
            _check_url_reference(match.group(1), valid_ids, "<style>")

    href''')
s=s.replace('''            valid_ids.add(elem_id.strip())''','''            if elem_id != elem_id.strip() or elem_id in valid_ids:
                raise ValueError(f"Invalid or duplicate SVG ID: {elem_id!r}")
            valid_ids.add(elem_id)''')
a=s.index('def _extract_svg_text(');b=s.index('\n\ndef inspect_svg',a)
s=s[:a]+'''def _extract_svg_text(root: ET.Element) -> list[str]:
    """Extract text-element content, without asserting rendered glyph visibility."""
    texts: list[str] = []

    def visit(elem: ET.Element) -> None:
        if elem.tag == "{http://www.w3.org/2000/svg}metadata":
            return
        if elem.tag == "{http://www.w3.org/2000/svg}text":
            content = "".join(elem.itertext()).strip()
            if content:
                texts.append(content)
            return
        for child in elem:
            visit(child)

    visit(root)
    return texts
'''+s[b:]
s=s.replace('''    if width_info is None and height_info is None and view_box is None:
        raise ValueError("SVG lacks both viewport dimensions and viewBox")''','''    if (width_info is None or height_info is None) and view_box is None:
        raise ValueError("Unsupported SVG qualification: complete viewport or viewBox required")''')
p.write_text(s)
