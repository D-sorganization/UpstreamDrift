from pathlib import Path
import hashlib,importlib.util,json
p=Path('/tmp/p2-vector-review-agy/vector_inspection.py');before=hashlib.sha256(p.read_bytes()).hexdigest();spec=importlib.util.spec_from_file_location('candidate',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
cases={
'wrong_namespace':'<svg xmlns="urn:not-svg" width="1" height="1"/>',
'nonimage_data':'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><image href="data:text/html;base64,SGk="/></svg>',
'external_stylesheet_pi':'<?xml-stylesheet type="text/css" href="https://example.invalid/a.css"?><svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>',
'duplicate_ids':'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><path id="a"/><path id="a"/><use href="#a"/></svg>',
'valid_local_style':'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><defs><clipPath id="a"/></defs><style>.x { clip-path: url(#a); }</style></svg>',
'partial_viewport':'<svg xmlns="http://www.w3.org/2000/svg" width="1"/>',
'metadata_text':'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><metadata><title>Not visible</title></metadata><text>Visible<tspan>Tail</tspan>After</text></svg>'}
rows=[]
for name,text in cases.items():
 f=Path('/tmp/p2-vector-review-astra')/(name+'.svg');f.write_text(text)
 try:result=m.inspect_svg(f,hashlib.sha256(f.read_bytes()).hexdigest());rows.append({'case':name,'accepted':True,'text':result['text']})
 except Exception as ex:rows.append({'case':name,'accepted':False,'exception':type(ex).__name__,'message':str(ex)})
after=hashlib.sha256(p.read_bytes()).hexdigest();Path('/tmp/p2-vector-review-astra/provisional_probes.json').write_text(json.dumps({'source_before':before,'source_after':after,'provisional':True,'cases':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
