# Operational PDF/SVG Vector Inspection Helper

## Overview

This module (`vector_inspection.py`) provides an operational inspection helper for single PDF and SVG vector artifacts in the shot-pattern publication review harness.

It implements structural, metadata, and resource diagnostics per `VECTOR_REVIEW_PLAN.md` (Pass 1). It inspects already-bound individual artifacts against an authoritative expected SHA-256 hash.

> **Important**: This tool provides structural and syntactic diagnostics only. It does **not** perform visual rendering approval, layout qualification, glyph visibility assessment, or publication acceptance. Calling coordinators enforce terminal completion boundaries, ledger binding, and raster visual inspection separately.

## Public Interfaces

- `inspect_pdf(path: Path | str, expected_sha256: str) -> dict[str, Any]`
  - Enforces pre-read and post-read SHA-256 integrity.
  - Strictly parses PDF via `pypdf` (`strict=True`).
  - Rejects encrypted files, multipage PDFs, empty content streams, and non-positive/non-finite MediaBox/CropBox dimensions.
  - Returns page dimensions, extracted text, font resource inventory (without assuming Type3/path glyphs are defective), embedded raster image count, and library warnings.
- `inspect_svg(path: Path | str, expected_sha256: str) -> dict[str, Any]`
  - Enforces pre-read and post-read SHA-256 integrity.
  - Performs safe XML parsing via standard library Expat and ElementTree.
  - Explicitly rejects DTD internal subsets, custom system DTDs, entity declarations, and non-`<svg>` root tags. Standard W3C SVG 1.1 DOCTYPE without internal subsets is accepted safely without network access.
  - Parses and validates viewport dimensions (with optional `pt`, `px`, `in`, `mm`, `cm` units) and viewBox (finite, positive width/height).
  - Validates all `href`, `xlink:href`, and `url(...)` presentation attributes: requires existing local `#id` targets, permits embedded `data:image/` layers, and rejects external network/file resource dependencies.
  - Distinguishes RDF metadata namespace URLs from external resource links.
  - Separates extracted visible text from XML comments.
- `inspect_vector(path: Path | str, expected_sha256: str) -> dict[str, Any]`
  - Dispatcher function routing `.pdf` to `inspect_pdf` and `.svg` to `inspect_svg`. Rejects unsupported formats.

## Output Structure

Diagnostics are fully JSON-serializable dictionaries including:
- `format`: `"pdf"` or `"svg"`
- `file_sha256`: Verified SHA-256 hex digest
- `expected_sha256`: Expected SHA-256 hex digest
- `byte_size`: File size in bytes
- `visual_approval`: Always `False`
- `claim`: Diagnostic disclaimer string
- `runtime_versions`: Python and pypdf version details
- `source_sha256`: SHA-256 digest of `vector_inspection.py`
- Format-specific metadata: `dimensions`, `viewport`, `view_box`, `text`, `comments`, `ids`, `font_resources`, `embedded_image_count`, `warnings`

## Verification Commands

Run using the pinned validation environment:

```bash
# Test suite
/tmp/shot-pattern-validation-venv-20261009/bin/python -m pytest -o addopts='' -q test_vector_inspection.py

# Ruff linter
/tmp/shot-pattern-validation-venv-20261009/bin/python -m ruff check /tmp/p2-vector-review-agy

# Ruff formatting check
/tmp/shot-pattern-validation-venv-20261009/bin/python -m ruff format --check /tmp/p2-vector-review-agy

# Type check
/tmp/shot-pattern-validation-venv-20261009/bin/python -m mypy --python-version 3.12 --follow-imports=silent vector_inspection.py test_vector_inspection.py
```
