# Review: Reject Missing Pair Protocols Before Rendering

## Summary
A study-owned regression in `matched_supplement_figures._render_pair_figures_core` allowed completed pair references missing `source_protocol` (but carrying generic `protocol_id`) to pass general identity extraction via `pair_comparison_identity` (which supports `protocol_id` fallback for serialized comparison records), subsequently failing with `KeyError: 'source_protocol'` during density caption formatting.

A minimal guard was added directly in `_render_pair_figures_core` immediately after the existing incomplete-status skip (`status != "completed"` check) and before `pair_comparison_identity`:
```python
if first.get("source_protocol") is None or second.get("source_protocol") is None:
    raise ValueError(
        f"pair references lack source protocol: {first.get('cell')} vs {second.get('cell')}"
    )
```

## GitHub Issue
- Issue Title: `Reject Missing Pair Protocols Before Rendering`
- Issue Number: `12169`
- Issue URL: `https://github.com/D-sorganization/UpstreamDrift/issues/12169`
- Status: Left open per instructions (no closing, issue settings change, commit, or PR creation performed).

## Scope & Changes
Files modified/created:
- `src/tools/shot_pattern_analysis/matched_supplement_figures.py` (minimal 4-line precondition guard in `_render_pair_figures_core`)
- `tests/tools/shot_pattern_analysis/test_pair_protocol_preconditions.py` (new test suite with 21 behavioral test cases)

No other files, worktrees, producers, articles, historical receipts, or datasets were modified. No production runs or simulations were executed.

### Changed Source Hashes (SHA-256)
- `src/tools/shot_pattern_analysis/matched_supplement_figures.py`: `f4282ad097854b635a8c5e0a6c19b7cc8ac8a3e2d4384efb8ede89570db74c1b`
- `tests/tools/shot_pattern_analysis/test_pair_protocol_preconditions.py`: `3bfc6fccd74a9644c9a1b718b610993fd224e0c2bc53fc77b7bde436bf200b5f`

## TDD Verification & Evidence
Evidence files stored under `/tmp/p2-protocol-precondition-agy/`:
1. `red_original_failing_test.log`: Baseline RED reproduction of `test_render_pair_figures_cross_protocol_passes_ordered_protocols` failing with `KeyError: 'source_protocol'` at line 463 of `matched_supplement_figures.py`.
2. `red_new_precondition_tests.log`: Baseline RED execution of `tests/tools/shot_pattern_analysis/test_pair_protocol_preconditions.py` demonstrating missing/None protocol fallthrough to endpoint loading and KeyError.
3. `green_new_precondition_tests.log`: GREEN run of `test_pair_protocol_preconditions.py` (21 passed).
4. `green_original_failing_test.log`: GREEN run of `test_render_pair_figures_cross_protocol_passes_ordered_protocols` (1 passed).
5. `green_test_pair_comparison_identity.log`: GREEN run of `test_pair_comparison_identity.py` (12 passed).
6. `green_test_selected_pair_renderer.log`: GREEN run of `test_selected_pair_renderer.py` (7 passed).
7. `green_test_matched_social_integration.log`: GREEN run of `test_matched_social_integration.py` (8 passed).
8. `green_test_matched_supplement.log`: GREEN run of `test_matched_supplement.py` (4 passed).
9. `ruff_check.log` and `ruff_format.log`: Zero violations.
10. `mypy_check.log`: Success, no issues found in 2 source files (`--python-version 3.12 --follow-imports=silent`).

## Acceptance & Disclaimer
All required test suites and static checks pass cleanly with zero suppressions or type ignores.
Per policy, this review makes no claim of Root/Astra independent approval or full publication acceptance.
