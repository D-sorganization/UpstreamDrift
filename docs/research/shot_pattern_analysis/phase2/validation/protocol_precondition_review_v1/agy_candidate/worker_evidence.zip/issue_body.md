## Problem

The broad phase-two pre-PR test run exposed a study-owned regression in `test_render_pair_figures_cross_protocol_passes_ordered_protocols`. A completed pair reference missing `source_protocol` but carrying `protocol_id` passes the general identity adapter, then raises `KeyError: source_protocol` while constructing the academic density caption. The renderer's intended `ValueError` contract must hold before file reads or figure allocation.

The general identity helper also serves serialized comparison records, where `protocol_id` is legitimate. Do not remove that support globally. Renderer references require their actual `source_protocol`.

## Acceptance Criteria

- Demonstrate the existing failure and add behavioral tests first for each missing/None protocol position, canonical and selected rendering, and no I/O or figure side effects.
- Reject missing required renderer protocols with a clear `ValueError` before rendering work; retain general identity validation and incomplete-status skipping.
- Preserve valid ordered protocol/cell/target identity, filenames, numerical inputs, and rendered output behavior.
- Run relevant identity, social integration, selected-renderer and figure tests plus scoped static checks.
- Preserve the live v6 producer at `4023111d2a` and its receipts; implement in a separate owned worktree. Do not restart production, alter historical hashes or rerun simulations for an invalid-input guard.
- Document verified source transition/reproduction before integration and deliver through a ready PR with a change fragment; leave this issue open until merged acceptance.

## Evidence

Original failure: `/tmp/p2-protocol-precondition-red.txt`, extracted from `/tmp/p2-prepr-readiness-20261010-safe.txt`. The selected test phase reported 24 failures, 3,822 passes, seven errors and other skips; other failures require separate baseline classification. No full repository pass is claimed.
