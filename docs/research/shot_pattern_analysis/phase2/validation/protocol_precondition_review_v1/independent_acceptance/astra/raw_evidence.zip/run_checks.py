from pathlib import Path
import subprocess,os,json,hashlib
r=Path('/home/dieterolson/.codex/worktrees/shot-pattern-bounds/UpstreamDrift');e=Path('/tmp/p2-protocol-precondition-astra-review');py='/tmp/shot-pattern-validation-venv-20261009/bin/python';p=r/'src/tools/shot_pattern_analysis/matched_supplement_figures.py';saved=p.read_bytes();env={**os.environ,'QT_QPA_PLATFORM':'offscreen','MPLBACKEND':'Agg','OPENBLAS_NUM_THREADS':'1'}
args=[py,'-m','pytest','-o','addopts=','-q','tests/tools/shot_pattern_analysis/test_pair_protocol_preconditions.py','-k','no_endpoints_or_figures']
try:
 p.write_bytes(subprocess.check_output(['git','show','HEAD:src/tools/shot_pattern_analysis/matched_supplement_figures.py'],cwd=r))
 with (e/'independent_red.txt').open('w') as f: red=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
finally:p.write_bytes(saved)
with (e/'independent_green.txt').open('w') as f: green=subprocess.run([py,'-m','pytest','-o','addopts=','-q','tests/tools/shot_pattern_analysis/test_pair_protocol_preconditions.py','tests/tools/shot_pattern_analysis/test_matched_social_integration.py','tests/tools/shot_pattern_analysis/test_pair_comparison_identity.py'],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
(e/'test_results.json').write_text(json.dumps({'red_exit':red,'green_exit':green,'source_restored_exactly':p.read_bytes()==saved},indent=2))
print(red,green)
