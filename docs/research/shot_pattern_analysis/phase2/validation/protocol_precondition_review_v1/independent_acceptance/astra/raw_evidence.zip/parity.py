from pathlib import Path
import hashlib,json,os,subprocess,sys
E=Path('/tmp/p2-protocol-precondition-astra-review'); W=Path('/home/dieterolson/.codex/worktrees'); roots={'baseline':W/'shot-pattern-presentation/UpstreamDrift','candidate':W/'shot-pattern-bounds/UpstreamDrift'}
fixture=Path('/tmp/shot-pattern-selected-renderer-review/actual_v3'); worker=Path('/tmp/shot-pattern-selected-renderer-review/qualify.py'); py='/tmp/shot-pattern-validation-venv-20261009/bin/python'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sources(r):return {str(p.relative_to(r)):sha(p) for d in ['src/tools/shot_pattern_analysis','scripts/research/shot_pattern_analysis'] for p in (r/d).rglob('*.py')}
inputs=json.loads((fixture/'qualification.json').read_text())['input_sha256']
for p,h in inputs.items():
 if sha(p)!=h:raise ValueError(f'Historical input changed: {p}')
start={k:sources(r) for k,r in roots.items()};out=E/'parity';out.mkdir(exist_ok=False)
for label,r in roots.items():
 d=out/label;d.mkdir()
 with (out/f'{label}.txt').open('w') as log:
  result=subprocess.run([py,str(worker),'--worker','candidate','--root',str(r),'--out',str(d),'--pairs',str(fixture/'pairs.json')],env={**os.environ,'QT_QPA_PLATFORM':'offscreen','MPLBACKEND':'Agg','OPENBLAS_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise ValueError(f'{label} worker exit {result.returncode}')
a=json.loads((out/'baseline/capture.json').read_text());b=json.loads((out/'candidate/capture.json').read_text())
def clean(value):
 if isinstance(value,dict):return {k:clean(v) for k,v in value.items() if k!='sha256' or set(value)!={'sha256'}}
 return value
comparisons={}
for name in a:
 for key in ['density_recipe','figures']:
  if a[name][key]!=b[name][key]:raise ValueError((name,key))
 aa=[{k:v for k,v in r.items() if k!='sha256'} for r in a[name]['ledger']];bb=[{k:v for k,v in r.items() if k!='sha256'} for r in b[name]['ledger']]
 if aa!=bb:raise ValueError((name,'ledger'))
 for p in (out/'baseline'/name).rglob('*.png'):
  q=out/'candidate'/p.relative_to(out/'baseline')
  if sha(p)!=sha(q):raise ValueError(('PNG mismatch',p))
  comparisons[str(p.relative_to(out/'baseline'))]=sha(p)
for k,r in roots.items():
 if sources(r)!=start[k]:raise ValueError('Source changed')
for p,h in inputs.items():
 if sha(p)!=h:raise ValueError('Input changed')
(E/'parity_review.json').write_text(json.dumps({'accepted_valid_input_parity':True,'publication_acceptance':False,'pairs':list(a),'png_count':len(comparisons),'png_sha256':comparisons,'source_sha256':start,'input_sha256':inputs,'worker_sha256':sha(worker),'fixture_sha256':sha(fixture/'pairs.json'),'artist_density_limits_and_metadata_equal':True,'sources_inputs_unchanged':True},indent=2)+'\n')
print('PASS',len(comparisons),'PNG; all four artist/density/ledger captures equal')
