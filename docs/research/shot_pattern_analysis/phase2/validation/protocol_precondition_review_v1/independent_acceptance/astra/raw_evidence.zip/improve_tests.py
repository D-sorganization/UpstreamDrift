from pathlib import Path
p=Path('/home/dieterolson/.codex/worktrees/shot-pattern-bounds/UpstreamDrift/tests/tools/shot_pattern_analysis/test_pair_protocol_preconditions.py')
s=p.read_text();a=s.index('def test_no_endpoints_or_figures_accessed_when_protocol_precondition_fails(');b=s.index('\n\n@pytest.mark.parametrize(',a)
s=s[:a]+'''@pytest.mark.parametrize("ref_key", ["first", "second"])
@pytest.mark.parametrize("missing", [True, False])
@pytest.mark.parametrize("renderer_kind", ["canonical", "selective"])
def test_no_endpoints_or_figures_accessed_when_protocol_precondition_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    ref_key: str,
    missing: bool,
    renderer_kind: str,
) -> None:
    """Reject either malformed reference before any data, figure or directory access."""
    pair: dict[str, Any] = {
        "comparison_kind": "curve_strength",
        "target_x_m": 180.0,
        "first": {
            "status": "completed", "cell": "first",
            "source_protocol": "original_primary/1",
        },
        "second": {
            "status": "completed", "cell": "second",
            "source_protocol": "pw-primary-face-bounds/1",
        },
    }
    pair[ref_key]["protocol_id"] = "serialized-fallback/1"
    if missing:
        pair[ref_key].pop("source_protocol")
    else:
        pair[ref_key]["source_protocol"] = None
    accessed: list[str] = []

    def forbidden(*args: Any, **kwargs: Any) -> Any:
        accessed.append("side effect")
        raise AssertionError("Malformed renderer references must fail before side effects")

    for name in (
        "_supported_endpoints", "_write_pair_density_figure",
        "_write_pair_overhead_figure", "write_pair_social_density",
    ):
        monkeypatch.setattr(figures, name, forbidden)
    from matplotlib.figure import Figure

    monkeypatch.setattr(Figure, "__init__", forbidden)
    monkeypatch.setattr(Path, "mkdir", forbidden)
    monkeypatch.setattr(Path, "open", forbidden)
    out_dir = tmp_path / "out"
    with pytest.raises(ValueError, match="pair references lack source protocol"):
        if renderer_kind == "canonical":
            _render_pair_figures(pair, out_dir)
        else:
            render_selected_pair_figures(
                pair, out_dir, figure_kinds=CLOSED_SELECTED_FIGURE_KINDS
            )
    assert accessed == []
    assert not out_dir.exists()
''' +s[b:];p.write_text(s)
