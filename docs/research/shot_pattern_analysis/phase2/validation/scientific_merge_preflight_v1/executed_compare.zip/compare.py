import hashlib,json,subprocess,os
from pathlib import Path
ROOT=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift')
BASE='2953c52b37';MERGED='ac0b22ea4d746025523fdfc6a6e53312654d738e'
RECEIPT='docs/research/shot_pattern_analysis/phase2/source_transition_supplement.json'
def git(repo,*args):
 return subprocess.check_output(['git','-C',str(repo),*args],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'))
def sha(b):return hashlib.sha256(b).hexdigest()
receipt=git(ROOT,'show',BASE+':'+RECEIPT);d=json.loads(receipt)
rows=[]
for name,accepted in d['new_execution']['source_sha256'].items():
 if name.startswith('vendor/ud-tools/'):
  p=name.removeprefix('vendor/ud-tools/')
  old=git(ROOT/'vendor/ud-tools','show','3678409fc51024150ab28970b72e3b468935f345:'+p)
  new=git(Path('/home/dieterolson/Repositories/UpstreamDrift/vendor/ud-tools'),'show','86d0f28b1cc5acf61185e07e320c816c2d005512:'+p)
 else:
  old=git(ROOT,'show',BASE+':'+name);new=git(ROOT,'show',MERGED+':'+name)
 rows.append({'path':name,'accepted_sha256':accepted,'study_sha256':sha(old),'synthetic_merge_sha256':sha(new),'already_changed_from_accepted':sha(old)!=accepted,'new_upstream_change':old!=new})
r={'scope':'54 exact accepted source paths only; synthetic metadata-conflicted tree; no runtime acceptance','study_revision':BASE,'synthetic_tree':MERGED,'accepted_receipt':RECEIPT,'accepted_receipt_sha256':sha(receipt),'sources':rows,'new_upstream_changes':[x for x in rows if x['new_upstream_change']],'already_changed_study_sources':[x for x in rows if x['already_changed_from_accepted']],'native_runtime_checked':False}
Path('/tmp/p2-scientific-merge-preflight/evidence.json').write_text(json.dumps(r,indent=2)+'\n')
print('paths',len(rows));print('new upstream',*[x['path'] for x in r['new_upstream_changes']],sep='\n');print('already study',*[x['path'] for x in r['already_changed_study_sources']],sep='\n')
