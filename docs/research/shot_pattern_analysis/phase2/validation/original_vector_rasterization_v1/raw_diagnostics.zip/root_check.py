from pathlib import Path
import hashlib,json
from collections import Counter
root=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift')
batch=Path('/tmp/p2-original-vector-rasterization')
def sha(p):
    with p.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def unique(items):
    out={}
    for k,v in items:
        assert k not in out, k
        out[k]=v
    return out
def load(p): return json.loads(p.read_text(),object_pairs_hook=unique)
review=load(batch/'review.json'); start=load(batch/'start.json'); results=load(batch/'results.json')
assert sha(batch/'review.json')=='f8a5be9b8f0b58a1e70ccc6b2c8e5b13d3a7c56c0956dc5e31accdfad62c38df'
for key,file in [('start_sha256','start.json'),('results_sha256','results.json'),('script_sha256','run.py')]: assert sha(batch/file)==review[key]
assert review['rasterization_pass'] and review['attempted']==review['diagnostic_records']==len(results)==744
assert not review['errors'] and not review['warning_files'] and not review['visual_approval']
expected={(x['dataset'],x['relative_path']):x for x in start['inventory']}
actual={(x['dataset'],x['relative_path']):x for x in results}
assert len(expected)==len(actual)==744 and set(expected)==set(actual)
counts=Counter()
for key,item in actual.items():
    initial=expected[key]; assert item['path']==initial['path'] and item['sha256']==initial['sha256']
    assert sha(Path(item['path']))==item['sha256']
    assert item['success'] and not item['warnings'] and not item['stderr']
    diag_path=Path(item['diagnostic_path']); assert sha(diag_path)==item['diagnostic_sha256']
    diag=load(diag_path); assert diag['success'] and not diag['visual_approval']
    assert diag['input_sha256']==diag['post_input_sha256']==item['sha256']
    assert diag['output_dimensions']==item['dimensions'] and diag['exit_code']==0
    assert sha(Path(item['output_png_path']))==item['output_png_sha256']==diag['output_png_sha256']
    assert all(v>0 for v in item['dimensions'].values())
    counts[(item['dataset'],Path(item['relative_path']).suffix)]+=1
for path,digest in start['sources'].items(): assert sha(Path(path))==digest
phase=root/'docs/research/shot_pattern_analysis/phase2'
for dataset,digest in start['manifests'].items(): assert sha(phase/dataset/'figure_manifest.json')==digest
receipt={'accepted_scope':'Native rasterization diagnostics for all original PDF/SVG assets','independent_root_rehash_pass':True,'input_count':744,'diagnostics_count':744,'output_count':744,'counts':{str(k):v for k,v in counts.items()},'batch_review_sha256':sha(batch/'review.json'),'coordinator_sha256':sha(batch/'run.py'),'root_check_sha256':sha(Path(__file__)),'visual_review_scope':'Separate representative24vector receipt; no all744 visual claim','full_publication_accepted':False}
(batch/'root_review.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt))
