from pathlib import Path
import hashlib,json,re,subprocess,collections,unicodedata
root=Path('/home/dieterolson/.codex/worktrees/shot-pattern-main-integration/UpstreamDrift');side=root/'docs/agents/handoffs/shot-pattern-integration-peer-records.md';handoff=root/'AGENT_HANDOFF.md';old=subprocess.check_output(['git','show','fa7ee92f5c:AGENT_HANDOFF.md'],cwd=root);raw=side.read_bytes();offset=raw.find(old);text=raw.decode();h=handoff.read_text()
def sha(b):return hashlib.sha256(b).hexdigest()
# GitHub heading slug: remove punctuation except hyphens/underscores; spaces -> hyphens; repeated headings suffix.
counts=collections.Counter();anchors=[]
for line in text.splitlines():
 if line.startswith('# '):
  title=line[2:];slug=''.join(c for c in title.lower() if c in '-_ ' or not unicodedata.category(c).startswith(('P','S'))).replace(' ','-');n=counts[slug];counts[slug]+=1;anchors.append((title,slug+('-'+str(n) if n else '')))
links=re.findall(r'\]\(docs/agents/handoffs/shot-pattern-integration-peer-records\.md#([^)]*)\)',h)
relative=[]
for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',text):
 if '://' in target or target.startswith('#'):continue
 dest=target.split('#')[0];relative.append({'label':label,'target':target,'relocated_exists':(side.parent/dest).exists(),'original_root_exists':(root/dest).exists(),'root_relative_repair':'../../../'+target})
r={'root_sha256':sha(handoff.read_bytes()),'sidecar_sha256':sha(raw),'upstream_payload_sha256':sha(old),'actual_payload_offset':offset,'claimed_offset':425,'exact_payload_suffix':offset>=0 and raw[offset:]==old,'root_lines':len(h.splitlines()),'top_level_peer_headings':len(anchors)-1,'indexed_links':len(links),'missing_anchors':[s for s in links if s not in [a for _,a in anchors]],'unindexed_peer_anchors':[a for _,a in anchors[1:] if a not in links],'relative_links':relative,'force_overlay_exists':(root/'tests/unit/force_overlay').is_dir()}
Path('/tmp/p2-handoff-independent-review/review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
