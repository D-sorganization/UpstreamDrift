from pathlib import Path
import subprocess,json,hashlib,zipfile,re,collections,unicodedata
root=Path('/home/dieterolson/.codex/worktrees/shot-pattern-main-integration/UpstreamDrift');out=Path('/tmp/p2-handoff-root-correction/independent')
paths=[root/'AGENT_HANDOFF.md',root/'docs/agents/handoffs/shot-pattern-integration-peer-records.md',root/'docs/agents/handoffs/shot-pattern-integration-peer-original.zip']
def sha(b):return hashlib.sha256(b).hexdigest()
before={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths}
original=subprocess.check_output(['git','show','fa7ee92f5c:AGENT_HANDOFF.md'],cwd=root)
with zipfile.ZipFile(paths[2]) as z:
 names=z.namelist()
 if len(names)!=1:raise ValueError('Expected one raw original member')
 archived=z.read(names[0])
 if archived!=original:raise ValueError('Archive payload differs from upstream')
side=paths[1].read_text();marker=original.decode().splitlines()[0];offset=side.index(marker);display=side[offset:]
count=0
def undo(m):
 global count
 count+=1
 return m.group(0).replace('](../../../docs/','](docs/',1)
restored=re.sub(r'\[[^\]]+\]\(\.\./\.\./\.\./docs/[^)]+\)',undo,display)
if count!=12 or restored.encode()!=original:raise ValueError('Link-only reversal mismatch')
counts=collections.Counter();anchors=[]
for line in side.splitlines():
 if line.startswith('# '):
  s=''.join(c for c in line[2:].lower() if c in '-_ ' or not unicodedata.category(c).startswith(('P','S'))).replace(' ','-');n=counts[s];counts[s]+=1;anchors.append(s+('-'+str(n) if n else ''))
h=paths[0].read_text();links=re.findall(r'\]\(docs/agents/handoffs/shot-pattern-integration-peer-records\.md#([^)]*)\)',h)
if len(links)!=68 or set(links)!=set(anchors[1:]):raise ValueError('Anchor map mismatch')
broken=[]
for p in paths[:2]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in target or target.startswith('#'):continue
  if not (p.parent/target.split('#')[0]).exists():broken.append([str(p),target])
if broken:raise ValueError(str(broken))
if len(h.splitlines())>=150:raise ValueError('Root length')
for stale in ['in the `main` worktree','recording in progress','Do not edit outside the two designated paths','only integration dependency','pytest tests/unit/force_overlay']:
 if stale in h:raise ValueError('Stale instruction: '+stale)
after={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths}
if before!=after:raise ValueError('Source changed during review')
r={'accepted_metadata_correction':True,'global_merge_or_publication_accepted':False,'sha256':before,'source_unchanged':True,'archive_member':names[0],'original_payload_sha256':sha(original),'displayed_payload_sha256':sha(display.encode()),'displayed_payload_byte_offset':len(side[:offset].encode()),'reversed_links':count,'entire_original_recovered':True,'root_lines':len(h.splitlines()),'peer_anchors':len(links),'broken_local_links':broken}
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
