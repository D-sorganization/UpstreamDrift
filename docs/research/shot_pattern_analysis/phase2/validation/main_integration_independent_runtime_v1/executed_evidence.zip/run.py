import datetime,hashlib,importlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/dieterolson/.codex/worktrees/shot-pattern-main-integration/UpstreamDrift');OUT=Path('/tmp/p2-main-integration-root-tests');PY='/tmp/shot-pattern-validation-venv-20261009/bin/python'
env=dict(os.environ,PYTHONPATH=str(ROOT/'vendor/ud-tools/src')+':'+str(ROOT),QT_QPA_PLATFORM='offscreen',MPLBACKEND='Agg',MUJOCO_GL='egl',SDL_VIDEODRIVER='dummy',OPENBLAS_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=set()
for base in ['src/tools/shot_pattern_analysis','scripts/research/shot_pattern_analysis','src/shared/python/physics','tests/tools/shot_pattern_analysis','tests/ui/tools/shot_pattern_analysis','vendor/ud-tools/src/shared/python/launch_monitor','vendor/ud-tools/src/shared/python/logging_pkg']:
 paths.update(p for p in (ROOT/base).rglob('*.py'))
paths.update(ROOT/p for p in ['src/shared/python/_seam_redirect.py','tests/unit/shared_python/test_seam_redirect.py','tests/unit/launch_monitor/test_canonical_layer_parity.py','tests/unit/physics/test_cop_consolidation.py','tests/unit/test_grip_contact_model.py','tests/unit/physics/test_incremental_contact.py','tests/unit/physics/test_rigid_contact.py'])
paths.update((ROOT/'tests/research').glob('test_shot_pattern_final_report*.py'))
before={str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
(OUT/'start.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':before,'python':PY,'pythonpath':env['PYTHONPATH'],'scope':'Independent execution of existing bounded integration tests; no reliance on AGY claimed test results.'},indent=2)+'\n')
groups={
'provider':['tests/unit/shared_python/test_seam_redirect.py','tests/unit/launch_monitor/test_canonical_layer_parity.py'],
'scoring':['tests/tools/shot_pattern_analysis/test_'+n+'.py' for n in ['scoring','scoring_cache','scoring_cache_independent','course_score_vectors','course_scoring_delegation','scenario_scoring']],
'gui':['tests/ui/tools/shot_pattern_analysis/test_embed_adapter.py','tests/ui/tools/shot_pattern_analysis/test_matched_gui.py'],
'report':['tests/tools/shot_pattern_analysis/test_'+n+'.py' for n in ['provenance','matched_report','matched_supplement_report']]+['tests/research/test_shot_pattern_final_report.py','tests/research/test_shot_pattern_final_report_assets.py'],
'physics':['tests/unit/physics/test_cop_consolidation.py','tests/unit/test_grip_contact_model.py','tests/tools/shot_pattern_analysis/test_matched_physics.py','tests/unit/physics/test_incremental_contact.py','tests/unit/physics/test_rigid_contact.py']}
results=[]
for name,files in groups.items():
 command=[PY,'-m','pytest','-o','addopts=','-q','--junitxml='+str(OUT/(name+'.xml')),*files];t=time.monotonic()
 with (OUT/(name+'.txt')).open('w') as f:r=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-t,'stdout_sha256':sha(OUT/(name+'.txt')),'junit_sha256':sha(OUT/(name+'.xml')) if (OUT/(name+'.xml')).exists() else None})
 (OUT/'groups.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,round(results[-1]['seconds'],2),flush=True)
after={str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
(OUT/'result.json').write_text(json.dumps({'groups':results,'sources_unchanged':before==after,'after_sha256':after,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print('finished; sources unchanged',before==after,flush=True)
