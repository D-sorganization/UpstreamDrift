import hashlib,importlib,json,sys,subprocess
from pathlib import Path
root=Path.cwd();out=Path('/tmp/p2-main-integration-root-tests/runtime.json');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Load through the actual consumer facade before inspecting provider identity.
import src.tools.shot_pattern_analysis.scoring as scoring
import src.tools.shot_pattern_analysis.scoring_cache as cache
import src.tools.launch_monitor_model as facade
names=['shared.python.launch_monitor.strokes_gained','shared.python.launch_monitor.strokes_gained_types','shared.python.logging_pkg.logging_config','src.shared.python.logging_pkg.logging_config','src.tools.shot_pattern_analysis.matched_physics','src.shared.python.physics.incremental_contact','src.shared.python.physics.rigid_contact','src.shared.python.physics.ball_simulator','src.shared.python.physics.rust_kernel','upstream_physics']
mods={name:importlib.import_module(name) for name in names}
assert mods[names[2]] is mods[names[3]]
for name in names[:4]:assert Path(mods[name].__file__).resolve().is_relative_to(root/'vendor/ud-tools')
for consumer in (scoring,cache,facade):assert consumer.analyze_source_backed_strokes_gained is mods[names[0]].analyze_source_backed_strokes_gained
baseline=importlib.import_module('src.tools.launch_monitor_model.strokes_gained_baseline')
mods['src.tools.launch_monitor_model.strokes_gained_baseline']=baseline
for consumer in (scoring,cache,facade):assert consumer.ExpectedStrokesBaselineV2 is baseline.ExpectedStrokesBaselineV2
for consumer in (scoring,cache,facade):assert consumer.CourseStateColumnsV1 is mods[names[1]].CourseStateColumnsV1
assert mods[names[4]].solve_incremental_contact is mods[names[5]].solve_incremental_contact
assert mods[names[4]].solve_rigid_contact is mods[names[6]].solve_rigid_contact
assert mods[names[4]].BallFlightSimulator is mods[names[7]].BallFlightSimulator
assert mods[names[8]].is_rust_available()
files={name:{'file':str(Path(mod.__file__).resolve()),'sha256':h(Path(mod.__file__))} for name,mod in mods.items()}
native={str(p):h(p) for p in Path(mods['upstream_physics'].__file__).parent.glob('*.so')}
assert '2e014290b3fe18034ab68743514806e7dea6137377ecafd8961091cdade1e2ce' in native.values()
out.write_text(json.dumps({'python':sys.executable,'module_files':files,'actual_scoring_function_and_type_identity':True,'logger_alias_identity':True,'matched_adapter_provider_identity':True,'rust_available':True,'native_files':native,'tools_pin':subprocess.check_output(['git','-C',str(root/'vendor/ud-tools'),'rev-parse','HEAD'],text=True).strip(),'probe_sha256':h(Path(__file__)),'scope_note':'An initial probe incorrectly assumed launch_monitor was a general seam-redirect alias. It is not in REDIRECTED_ROOTS. Qualification here follows the real scoring consumer facade; no global alias identity is claimed. A second probe wrongly placed the validating baseline model in Tools strokes_gained_types; the actual facade imports it from UD strokes_gained_baseline, which is checked here.'},indent=2)+'\n');print('Actual provider identities and native binary verified.')
