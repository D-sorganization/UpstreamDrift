## Problem and Scope

A broad local research-suite run during shot-pattern integration exposed existing exact-replay and provenance failures in frozen proximal-distal evidence. The relevant producer scripts, tests and stored reports/arrays are unchanged from both integration head `6ce959f22737387c904d30a14a198ad101ff634c` and main `8e9b4b974b98d0f1006514a121b3b0807ed42d9c`. This is separate from the shot-pattern study; no shot-pattern attempted rows or accepted publication assets were regenerated.

Current measurement environment: Python 3.12.13, NumPy 2.2.6, SciPy 1.15.3. Artifact-introducing commits pin these NumPy/SciPy versions in their development lock, but the evidence does not record actual producing Python, BLAS/LAPACK or solver runtime. A lockfile is not proof of the producing environment.

## Observed Evidence

- Bounded event reachability: 139 JSON numerical leaves and 19 arrays differ; no categorical changes. Largest JSON difference is 0.000007 in a multistart spread (0.249517 versus 0.249510; both exceed the existing 0.05 boundary). Maximum array absolute difference is 9.19169347857185e-7. Original JSON SHA256 `0045df6ae32fd4555de12892a43e0333f56525f2b19c3039f859fb8732e9ffa1`; NPZ `a073f9c46610e1bbc30fe9bb0287dd3f981938e3df58bb990cc6dcfbb00988ef`.
- Forward two-arm study: 48 JSON numerical leaves and 37 arrays differ; no categorical changes. Maximum JSON absolute difference 1.3997517594684788e-11; maximum array absolute difference 1.3446310731524136e-10. Original JSON SHA256 `f2e88ad80e3c1edb71421339bf47833df055eefc79e97750c901f4bc18f91281`; NPZ `df0cabfc45e9c6b6ee8b5e623df0127eb93e8f87605cd44c2e182e1ea468ba12`.
- Constraint internal-force diagnostics: all numerical and categorical fields match exactly; only two source-authority SHA values differ. Preserve the historical report and reconcile provenance through an explicit, separately reviewed source-only amendment rather than overwriting it.
- The broad run also reports a shaft-contribution replay failure; retain the complete run receipt and diagnose it separately rather than assuming the same cause.

The integration preserves the failing-run and measurement receipts under `docs/research/shot_pattern_analysis/phase2/validation/safe_followup_v1/`; PR #12278 will add their exact paths. No tolerance, numerical equality assertion, original evidence file or acceptance boundary is relaxed by this follow-up.

## Acceptance Criteria

1. Recover and document actual producing environments where possible; do not infer execution provenance solely from package locks.
2. Preserve original reports, arrays and hashes. Quantify each discrepancy and distinguish source/provenance changes from numerical behavior.
3. Resolve exact-replay failures through a governed, reproducible qualification or explicit versioned amendment, with failed experiments retained. Do not replace originals silently or loosen tolerances to pass CI.
4. Run the named evidence tests in the documented acceptance environment and publish truthful source-bound receipts. Keep physical/predictive gates open where their evidence is absent.

This issue remains open until a merged implementation demonstrably meets those criteria. It does not renew historical scientific approvals.
