# Operational Vector Rasterization Helper

## Overview

`vector_rasterization.py` provides a deterministic, hash-bound operational rasterization helper (`render_vector`) for PDF and SVG scientific figures in shot-pattern validation and review workflows.

- **Location**: `/tmp/p2-vector-raster-agy/`
- **Canonical Inspector**: Reuses `scripts.research.shot_pattern_analysis.vector_inspection.inspect_vector` for pre-rendering format, metadata, and SHA-256 validation.
- **Contract Boundary**: Returns strictly JSON-serializable diagnostics. Unconditionally sets `visual_approval: False` with no whole-publication acceptance claims.
- **Directory Isolation**: Requires a new destination directory; rejects existing directories to prevent unintentional overwrites. Partial failures are preserved for review.

---

## API Specification

```python
def render_vector(
    path: Path | str,
    expected_sha256: str,
    output_dir: Path | str,
    tool_paths: dict[str, str | Path] | None = None,
) -> dict[str, Any]:
```

### Preconditions (Design-by-Contract)
1. `path` must be an existing regular file whose SHA-256 matches `expected_sha256`.
2. Format must be supported (`.pdf` or `.svg`), validated via canonical `inspect_vector`.
3. `output_dir` must not already exist (`FileExistsError` raised on reuse/collision).
4. SVGs must possess complete, supported physical or CSS viewport dimensions (`pt`, `px`, `""`, `in`, `mm`, `cm`). Relative dimensions (`%`) or viewbox-only qualifications are rejected.

### Postconditions
1. Input file SHA-256 is rechecked after subprocess completion; any mutation raises `ValueError`.
2. External renderer execution is limited to exactly one subprocess per call.
3. Subprocess exit code, stdout, stderr, command, and renderer versions are captured.
4. If the renderer exits with a nonzero code, `success` is `False`.
5. If the target PNG is missing, empty, or undecodable by PIL, `success` is `False`.
6. Output PNG dimensions and SHA-256 are computed and verified upon success.
7. `visual_approval` is unconditionally `False`.

---

## External Rendering Engines

### PDF: Poppler `pdftoppm`
- **Binary**: `/home/dieterolson/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm`
- **Invocation**:
  ```bash
  pdftoppm -f 1 -singlefile -r 144 -png <INPUT_PDF> <OUTPUT_STEM>
  ```
- **Density**: 144 DPI (renders 2 in × 3 in PDF MediaBox to 288 × 432 px).

### SVG: Node.js + Sharp
- **Runtime**: `/home/dieterolson/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`
- **Package**: `/home/dieterolson/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp`
- **Inline Script**: Executed via Node subprocess argument with zero shell interpolation.
- **Scaling Correction**: Installed Sharp / librsvg scales `pt` units nonlinearly under configured density 144 (72pt × 144pt outputs 288 × 576 at density 144). The helper derives maximum pixel bounds at 144 pixels/inch from the original viewport:
  - `pt × 2.0` (144 / 72)
  - `px × 1.5` or unitless CSSpx (144 / 96)
  - `in × 144.0`
  - `mm × 144 / 25.4`
  - `cm × 144 / 2.54`
  Sharp renders at density 144 and proportionally fits inside these maximum dimensions (`fit: 'inside'`), preserving the physical aspect ratio without forced stretch or crop.
  - Proof: A `72pt × 144pt` SVG renders to exactly `144 × 288 px` (aspect ratio `0.5`).

---

## Test-Driven Development (TDD) Evidence

### 1. Chronology
- **Red Phase**: Full suite of 13 tests written in `test_vector_rasterization.py` against a stubbed `render_vector`. Executed via pytest; all 13 tests failed with `NotImplementedError`. Output recorded in `red.txt`.
- **Green Phase**: Complete implementation in `vector_rasterization.py`. Executed via pytest; all 13 tests passed in 5.13s. Output recorded in `green.txt`.
- **Static Analysis Phase**: `ruff check`, `ruff format --check`, and `mypy --python-version 3.12 --follow-imports=silent` executed and confirmed passing with exit code 0.

### 2. Test Coverage Matrix

| Test Name | Verification Focus | Result |
|---|---|---|
| `test_negative_expected_sha256_mismatch` | Rejects hash mismatch before execution | PASSED |
| `test_negative_unsupported_extension` | Rejects non-vector formats (.txt) | PASSED |
| `test_negative_rejected_output_reuse` | Rejects existing output directory | PASSED |
| `test_negative_external_renderer_nonzero` | Captures nonzero exit, preserves out_dir | PASSED |
| `test_negative_successful_exit_without_png` | Flags missing PNG on exit code 0 | PASSED |
| `test_negative_successful_exit_with_undecodable_png` | Flags corrupt/non-PNG bytes on exit code 0 | PASSED |
| `test_negative_postrender_input_mutation` | Detects input file modification post-render | PASSED |
| `test_negative_svg_missing_or_relative_viewport` | Rejects relative (%) or missing viewports | PASSED |
| `test_positive_compact_matplotlib_pdf` | Real compact Matplotlib PDF (288x432 px) | PASSED |
| `test_positive_compact_matplotlib_svg` | Real compact Matplotlib SVG (288x432 px) | PASSED |
| `test_positive_known_72pt_x_144pt_svg_physical_aspect` | Aspect ratio and output size proof (144x288 px) | PASSED |
| `test_positive_svg_css_px_units` | CSS px scaling proof (1.5x) | PASSED |
| `test_visual_approval_always_false` | Verifies visual_approval is strictly False | PASSED |

---

## Source SHA-256 Hashes

```
ad534c0f2d0d9a4cdca790aee4d81ed83082e1b55f7709dfdd69efbf80b1d5c2  vector_rasterization.py
d3317e7eeab464f7f0281b2009d22bf2dca8359bd0cee86c100bbda5f68fc7b8  test_vector_rasterization.py
b36d377fe475b638c4e6d6cf57b69db2905d1429476244a89328378d0457552e  conftest.py
fd02ed832c4df6beef575bac806a5f8e509a9e53919b08dbfe439641da2d88cc  mypy.ini
```

---

## Log Receipts

- `red.txt`: Exact raw stdout and failure trace from initial TDD red test run.
- `green.txt`: Exact raw output from passing test run (`13 passed in 5.13s`, `exit: 0`).
- `ruff_check.txt`: Static linting output (`All checks passed!`, `exit: 0`).
- `ruff_format.txt`: Code formatting check output (`3 files already formatted`, `exit: 0`).
- `mypy.txt`: Strict static type checking output (`Success: no issues found in 3 source files`, `exit: 0`).
