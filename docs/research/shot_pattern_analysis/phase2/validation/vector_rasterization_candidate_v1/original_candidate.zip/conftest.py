"""Pytest configuration for vector rasterization test suite."""

from __future__ import annotations

import sys
from pathlib import Path

_REPO_ROOT = Path(
    "/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift"
)
if str(_REPO_ROOT) not in sys.path and _REPO_ROOT.is_dir():
    sys.path.insert(0, str(_REPO_ROOT))
