# Main Integration Conflict Resolution Report

**Execution Context & Workspace:**
- **Worktree:** `/home/dieterolson/.codex/worktrees/shot-pattern-main-integration/UpstreamDrift`
- **Branch:** `codex/shot-pattern-main-integration`
- **HEAD (Branch Parent):** `2953c52b37001a8a3893e07943fb3cf2b6c38b45`
- **MERGE_HEAD (Target Parent):** `fa7ee92f5cddd753099d7418fc974b142b7ebb54` (origin/main)
- **Merge Base:** `3245b5211e5329105dfe9c66007b8d8e85c652e7`
- **Tools Submodule Pin:** `86d0f28b1cc5acf61185e07e320c816c2d005512` (clean checkout, verified)
- **Candidate State:** **UNCOMMITTED**, all 12 conflicted files resolved and staged, zero remaining conflict markers.

---

## 1. Executive Summary

This integration resolves the 12 unmerged conflict files resulting from the merge of fetched `origin/main` (`fa7ee92f5c`) into `codex/shot-pattern-main-integration` (`2953c52b37`). The merge was performed with `--no-commit --no-ff` and left uncommitted for root and Astra review.

No source code in `src/tools/shot_pattern_analysis` or `scripts/research/shot_pattern_analysis` was modified. All 62 Python files in those directories remain 100% byte-identical before and after the resolution (`source_hashes_after.txt` matches `source_hashes_before.txt`).

All 12 conflicted files were resolved using their canonical authorities and regenerated via repository generators:
1. `manuals/upstreamdrift/calculation-registry.json`
2. `docs/agent_context/reviews.json`
3. `docs/agent_context/README.md`
4. `docs/agent_context/index.html`
5. `docs/development/ORG01_CAPABILITY_BASELINE.md`
6. `docs/development/feature_parity_matrix.md`
7. `docs/architecture/CAPABILITY_ATLAS.md`
8. `ui/public/capability-atlas/graph.json`
9. `ui/public/capability-atlas/index.html` (and accompanying `.mmd` diagrams)
10. `docs/shared_tools/divergence_inventory.v1.json`
11. `docs/shared_tools/divergence_inventory.md`
12. `AGENT_HANDOFF.md`

All focused integration tests (280 passed, 0 failures), freshness gates, and governance checks pass.

---

## 2. File-by-File Conflict Resolutions

### 2.1 `manuals/upstreamdrift/calculation-registry.json`
- **Authority:** Editable governance inventory (governed by `scripts/config/design_manual_governance.json`).
- **Resolution:**
  - Preserved the union of all **55 blockers**: upstream's 54 blockers plus study-only `UP-D1-shot-pattern-variance-inventory`.
  - Retained upstream's explicit refinements for shared blockers:
    - `UP-D1-feedback-comparison-admission-inventory`: retained refined `state-schema/initial-state-payload` requirement.
    - `UP-D1-grip-wrench-reduction-inventory`: retained F10i/#12060 bushing-law inventory, 77 passing checks / 12 absent-SDK skips, and explicit no-full-body/measurement limits.
  - Preserved `release_status: blocked-inventory-required`, `inventory_commit: null`, and empty `calculations: []`.
- **Validation:** `python -m scripts.check_design_manual_governance` exited 0 ("Design-manual governance verified: 42 QMD sources, 0 registered calculations, release=blocked-inventory-required").

### 2.2 `docs/agent_context/reviews.json`
- **Authority:** Curated integration boundary review declarations (`docs/agent_context/USAGE.md`).
- **Resolution:**
  - Preserved all 5 existing reviews (`capture-atlas`, `launcher-atlas`, `model-backends`, `pipeline-api`, `pose-conventions`).
  - Added upstream's new review `project-task-native-replay` byte-for-byte; verified against its input hashes.
  - Handled `launcher-atlas`: Inputs on both branches changed (`models.yaml`, `launcher_manifest.json`, `feature_parity.json`). Neither parent's fingerprint matches the combined input set. Per policy, the review is preserved as **STALE** rather than manufacturing an unverified fingerprint. Both original records are documented below.
- **Historical launcher-atlas Review Evidence:**
  - *HEAD (`2953c52b37`):* fingerprint `07b3a1728b534f49642bc8d6d6cde1e9672e21f2eb993770f6c915f04d656f42`, rationale: "Reviewed the current launcher-atlas contract and source inputs after the rebase: models.yaml and launcher_manifest.json define the shot-pattern tile; feature_parity.json records its local PyQt/CLI surface as browser-parity-exempt; launcher_manifest_loader.py supplies typed launcher metadata; capability_atlas/model.py projects registries and validates graph references. The embed adapter remains lazy and is registered through pyproject entry points with bootstrap fallback. Validation: 108 launcher, feature-parity, atlas, category, and tool registration tests passed."
  - *MAIN (`fa7ee92f5c`):* fingerprint `da22d18ea7a363528887843bbd33f2cee182aedaf6cd41343be8fde3a82328b0`, rationale: "CMB-7a (#11658): only the character_builder parity note changed (web page now drives the spec presets/preview/export API); capability atlas regenerated from the updated registry, no contract or path changes."

### 2.3 `docs/agent_context/README.md` and `docs/agent_context/index.html`
- **Authority:** Generated views rendered from `catalog.json` and `reviews.json`.
- **Generator:** `PYTHONPATH=vendor/ud-tools/src python -m agent_context --root . render`
- **Resolution:** Overwrote conflicted views with cleanly rendered artifacts reflecting 11 components, 6 relations, 5 verified reviews, and 1 stale review (`launcher-atlas`).
- **Validation:** `PYTHONPATH=vendor/ud-tools/src python -m agent_context --root . status` reports catalog valid, navigation tasks 100% pass rate. `agent-context check` reports generated views up to date (exit code 2 solely due to the honest stale `launcher-atlas` boundary review).

### 2.4 `docs/development/ORG01_CAPABILITY_BASELINE.md`
- **Authority:** Canonical registry `src/config/capability_migration.json` (auto-merged cleanly with upstream addition `lifting.five_lift_viewing`).
- **Generator:** `python -m scripts.generate_capability_baseline`
- **Resolution:** Regenerated markdown baseline document (45,298 bytes).
- **Validation:** `python -m scripts.generate_capability_baseline --check` passed ("Baseline document ORG01_CAPABILITY_BASELINE.md is up to date").

### 2.5 `docs/development/feature_parity_matrix.md`
- **Authority:** Canonical registry `src/config/feature_parity.json` (auto-merged cleanly, retaining `tools.shot_pattern_analysis` and upstream additions `lifting.five_lift_viewing`, `tools.launch_monitor_analytics`, etc.).
- **Generator:** `python -m scripts.generate_feature_parity_matrix`
- **Resolution:** Regenerated parity matrix document.
- **Validation:** `python -m scripts.generate_feature_parity_matrix --check` passed ("OK: ... feature_parity_matrix.md is up to date").

### 2.6 `docs/architecture/CAPABILITY_ATLAS.md` & `ui/public/capability-atlas/{graph.json,index.html}`
- **Authority:** Model inputs `models.yaml`, `launcher_manifest.json`, `feature_parity.json`, and `capability_connections.json`.
- **Generator:** `python -m scripts.generate_capability_atlas`
- **Resolution:** Regenerated `docs/architecture/CAPABILITY_ATLAS.md`, `ui/public/capability-atlas/graph.json`, `ui/public/capability-atlas/index.html`, and Mermaid files (`system.mmd`, `capture-workflow.mmd`, `capture-goals.mmd`).
- **Validation:** `python -m scripts.generate_capability_atlas --check` passed cleanly with zero stale files.

### 2.7 `docs/shared_tools/divergence_inventory.v1.json` & `docs/shared_tools/divergence_inventory.md`
- **Authority:** Computed inventory between `src/shared/python` and pinned Tools submodule `vendor/ud-tools/src/shared/python`.
- **Generator:** `python -m scripts.shared_tools.divergence_inventory --write`
- **Resolution:** Re-inventoried all 24 packages and 200 files against the actual resolved working tree and Tools pin `86d0f28b1cc5acf61185e07e320c816c2d005512`. Totals: 400 identical, 273 diverged (121 spelling-only), 1,773 UD-only, 805 Tools-only.
- **Validation:** `python -m scripts.shared_tools.divergence_inventory --check` passed ("divergence inventory is current").

### 2.8 `AGENT_HANDOFF.md`
- **Authority:** Live agent handoff state table.
- **Resolution:** Preserved both branches' active records in full:
  - HEAD's active section: `# Active: Matched Delivery Study — Phase Two` (preserved all 15 lines covering frozen producer status, data audits, v5/v6 runs, test evidence, report status).
  - MAIN's active sections: Preserved all 286 lines covering MSK retarget, turn metrics, two-hand club variants, two-hand grip pose, gaze sweep default, hip pelvis alignment, engine ball scenes, MyoSuite retarget, reference ZMP split, MyoSuite feedback/search/task replay, bushing grip parity, Simscape URDF exchange, GRF engine wiring, and native OpenSim geometry.
  - Followed by shared active and parked sections (MeshCat framing, run-102 playback, etc.). Total length: 1,025 lines.

---

## 3. Toolchain & Runtime Isolation Verification

- **Submodule State:** `vendor/ud-tools` is detached at `86d0f28b1cc5acf61185e07e320c816c2d005512` (the origin/main pin). `git status` inside `vendor/ud-tools` is completely clean. No network fetch, clone, or update commands were run.
- **Environment Safety:** No packages were installed or modified in `/tmp/shot-pattern-validation-venv-20261009`. `agent_context` was invoked with `PYTHONPATH=vendor/ud-tools/src`.
- **Headless Environment:** All GUI/matplotlib invocations used `QT_QPA_PLATFORM=offscreen` and `MPLBACKEND=Agg`.

---

## 4. Test Evidence & Gate Verification

| Test Suite / Gate | Command | Result | Duration | Notes |
|---|---|---|---|---|
| **Provider Seam & Parity** | `pytest tests/unit/shared_python/test_seam_redirect.py tests/unit/launch_monitor/test_canonical_layer_parity.py` | **86 passed** | 1m 28s | Canonical Tools provider redirect and scoring types verified |
| **Scoring Boundary** | `pytest tests/tools/shot_pattern_analysis/test_scoring*.py ...` | **25 passed** | 1m 06s | Includes independent cache suite vs public API |
| **Tile & Embedded GUI** | `pytest tests/ui/tools/shot_pattern_analysis/test_*.py` | **42 passed** (1 deselected) | 55.5s | Offscreen lifecycle, controls, and layout resizing verified |
| **Report Consumers & Assets**| `pytest tests/tools/shot_pattern_analysis/test_matched_report*.py tests/research/test_shot_pattern_final_report*.py` | **46 passed** (1 deselected) | 40.6s | Immutability, provenance, and report generation verified |
| **Physics & Grip Contact** | `pytest tests/unit/physics/test_cop_consolidation.py tests/unit/test_grip_contact_model.py tests/tools/shot_pattern_analysis/test_matched_physics.py tests/unit/physics/test_*.py` | **81 passed** | 1m 41s | Full suite: normal-force weighted centroid, deprecated CoP alias, incremental/rigid contact |
| **Architecture Map Contract**| `python scripts/architecture_map_contract.py` | **PASS** | 2.1s | `docs/architecture/C4.md` contract validated |
| **Design Governance** | `python -m scripts.check_design_manual_governance` | **PASS** | 1.2s | 42 QMD sources, 55 blockers, release blocked |
| **Capability Baseline** | `python -m scripts.generate_capability_baseline --check` | **PASS** | 1.8s | Baseline markdown matches migration JSON |
| **Feature Parity Matrix** | `python -m scripts.generate_feature_parity_matrix --check` | **PASS** | 2.0s | Parity matrix matches registry |
| **Capability Atlas** | `python -m scripts.generate_capability_atlas --check` | **PASS** | 2.8s | Atlas and Mermaid diagrams match registries |
| **Divergence Inventory** | `python -m scripts.shared_tools.divergence_inventory --check` | **PASS** | 6.5s | Inventory matches resolved tree and Tools pin |
| **Ruff Linter** | `python -m ruff check src/tools/shot_pattern_analysis scripts/research/shot_pattern_analysis ...` | **PASS** | 1.8s | Clean lint across all study files |
| **Document Title Case Audit**| `python scripts/check_document_title_case.py` | **8 pre-existing violations** | 15.2s | Baseline debt in immutable research turnover docs; no new violations |

**Total focused unit/integration tests executed and passed:** **280 passed, 0 failures**.

---

## 5. Source Code Reproducibility & Invariance

All Python source files under the study namespaces were hashed before and after merge resolution:
- Pre-merge hash file: `/tmp/p2-main-integration-agy/source_hashes_before.txt`
- Post-merge hash file: `/tmp/p2-main-integration-agy-resume1/source_hashes_after.txt`
- Result: **All 62 files are byte-identical.** No numerical equations, constants, or solvers were altered.

---

## 6. Open Integration Gates for Root / Astra

1. **`launcher-atlas` Context Review Gate:**
   `docs/agent_context/reviews.json` preserves `launcher-atlas` in a `stale` state because inputs changed on both branches. A formal review requires verifying both public endpoints, contracts, and relevant tests before re-signing.
2. **Design Manual Calculation Registry Gate:**
   `release_status` remains `blocked-inventory-required` with 55 documented blockers. Release remains appropriately blocked pending governed inventory and empirical qualification.
3. **Tools Submodule Pin Boundary:**
   Origin main pin `86d0f28b1cc5acf61185e07e320c816c2d005512` is preserved. Historical frozen study receipts were executed under `3678409fc51024150ab28970b72e3b468935f345` and are retained unchanged; no receipts were falsified or retroactively refreshed.
4. **Candidate Remains Uncommitted:**
   Working tree contains staged resolutions ready for final review.
