from pathlib import Path
import subprocess,json,hashlib,collections,os
root=Path('/home/dieterolson/.codex/worktrees/shot-pattern-main-integration/UpstreamDrift');out=Path('/tmp/p2-main-integration-independent-review');base='2953c52b37';up='fa7ee92f5c'
def blob(ref,p):return subprocess.check_output(['git','show',ref+':'+p],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads((root/p).read_text())
conflicts=Path('/tmp/p2-remote-conflict-readiness/merge_tree.txt').read_text().split('\n\n')[0].splitlines()[1:]
canonical=['src/config/models.yaml','src/config/launcher_manifest.json','src/config/feature_parity.json','src/config/capability_migration.json','src/config/capability_connections.json','docs/agent_context/catalog.json']
paths=set(conflicts+canonical)
accepted=json.loads(blob(base,'docs/research/shot_pattern_analysis/phase2/source_transition_supplement.json'))['new_execution']['source_sha256']
paths.update(accepted)
before={p:sha((root/p).read_bytes()) for p in sorted(paths)}
(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
regs=[json.loads(blob(ref,'manuals/upstreamdrift/calculation-registry.json')) for ref in [base,up]]
current=load('manuals/upstreamdrift/calculation-registry.json');maps=[{x['id']:x for x in d['blockers']} for d in regs];expected={**maps[0],**maps[1]};actual={x['id']:x for x in current['blockers']}
reg={'count':len(current['blockers']),'unique':len(actual),'exact_expected_55_union':actual==expected,'missing':sorted(expected.keys()-actual.keys()),'extra':sorted(actual.keys()-expected.keys()),'changed':[k for k in actual.keys()&expected.keys() if actual[k]!=expected[k]],'release_status':current['release_status'],'calculations':current['calculations']}
# Preserve all upstream handoff lines as a diagnostic; report deliberate changes separately.
texts=[blob(ref,'AGENT_HANDOFF.md').decode() for ref in [base,up]];now=(root/'AGENT_HANDOFF.md').read_text();upheads=[s for s in texts[1].splitlines() if s.startswith('#')];heads=[s for s in now.splitlines() if s.startswith('#')]
handoff={'lines':len(now.splitlines()),'upstream_exact_contiguous_retained':texts[1] in now,'missing_upstream_headings':[h for h in upheads if h not in heads],'duplicate_headings':{k:v for k,v in collections.Counter(heads).items() if v>1},'new_duplicates_vs_upstream':{k:v for k,v in collections.Counter(heads).items() if v>collections.Counter(upheads)[k] and v>1}}
checks={};env=dict(os.environ,PYTHONPATH=str(root/'vendor/ud-tools/src')+':'+str(root),PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',MPLBACKEND='Agg',MUJOCO_GL='egl',SDL_VIDEODRIVER='dummy')
python='/tmp/shot-pattern-validation-venv-20261009/bin/python'
commands={'atlas':['scripts.generate_capability_atlas','--check'],'baseline':['scripts.generate_capability_baseline','--check'],'parity':['scripts.generate_feature_parity_matrix','--check'],'divergence':['scripts.shared_tools.divergence_inventory','--check'],'manual_governance':['scripts.check_design_manual_governance'],'context':['agent_context','--root','.','check']}
for label,args in commands.items():
 cmd=[python,'-m',*args]
 with (out/(label+'.txt')).open('w') as f:result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 checks[label]={'command':cmd,'exit_code':result.returncode,'log_sha256':sha((out/(label+'.txt')).read_bytes())}
after={p:sha((root/p).read_bytes()) for p in sorted(paths)}
result={'root':str(root),'base':base,'upstream':up,'unmerged':subprocess.check_output(['git','ls-files','-u'],cwd=root,text=True),'index_tree':subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip(),'before_sha256':before,'after_sha256':after,'unchanged':before==after,'registry':reg,'handoff':handoff,'checks':checks}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'unchanged':before==after,'registry':reg,'handoff':handoff,'checks':checks},indent=2))
