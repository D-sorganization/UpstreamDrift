from pathlib import Path
import subprocess,json,hashlib,ast
root=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift')
repos=[root/'vendor/ud-tools',Path('/home/dieterolson/Repositories/UpstreamDrift/vendor/ud-tools')]
pins=['3678409fc51024150ab28970b72e3b468935f345','86d0f28b1cc5acf61185e07e320c816c2d005512']
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
paths=set()
for repo,pin in zip(repos,pins):
 for prefix in ['src/shared/python/launch_monitor','src/shared/python/logging_pkg']:
  paths.update(git(repo,'ls-tree','-r','--name-only',pin,'--',prefix).decode().splitlines())
paths.update(['src/shared/__init__.py','src/shared/python/__init__.py','src/shared/python/ai/__init__.py'])
rows=[]
for path in sorted(paths):
 vals=[]
 for repo,pin in zip(repos,pins):
  proc=subprocess.run(['git','-C',str(repo),'show',f'{pin}:{path}'],capture_output=True)
  vals.append(hashlib.sha256(proc.stdout).hexdigest() if proc.returncode==0 else None)
 rows.append({'path':path,'old_sha256':vals[0],'new_sha256':vals[1],'equal':vals[0]==vals[1]})
imports=[]
for path in git(root,'ls-tree','-r','--name-only','2953c52b37','--','src/tools/shot_pattern_analysis','scripts/research/shot_pattern_analysis').decode().splitlines():
 if not path.endswith('.py'):continue
 tree=ast.parse(git(root,'show',f'2953c52b37:{path}'))
 for node in ast.walk(tree):
  if isinstance(node,ast.ImportFrom) and node.module and (node.module.startswith('shared') or node.module.startswith('src.shared') or node.module=='src.tools.launch_monitor_model'):
   imports.append({'caller':path,'line':node.lineno,'provider':node.module,'names':[a.name for a in node.names]})
result={'pins':pins,'object_repositories':[str(x) for x in repos],'provider_files':rows,'study_imports':imports,'changed_provider_files':[r for r in rows if not r['equal']],'scope':'Read-only fixed Git objects; source comparison only, no runtime acceptance'}
Path('/tmp/p2-tools-compatibility-preflight/evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print('provider files',len(rows),'changed',len(result['changed_provider_files']))
for r in result['changed_provider_files']:print(r['path'])
