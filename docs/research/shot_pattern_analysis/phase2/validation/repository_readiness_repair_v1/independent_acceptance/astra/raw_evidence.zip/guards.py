from pathlib import Path
import json,hashlib,subprocess,zipfile
R=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift');P=R/'docs/research/shot_pattern_analysis/phase2';O=Path('/tmp/p2-readiness-astra-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
startpath=P/'validation/supplement_rendering_revision_v6/start.json';start=json.loads(startpath.read_text());work=Path(start['worktree']);verified={}
for name,h in start['source_sha256'].items():
 p=work/name
 if sha(p)!=h:raise ValueError(p)
 verified[str(p)]=h
for name,h in start['input_sha256'].items():
 if sha(Path(name))!=h:raise ValueError(name)
 verified[name]=h
if sha(Path(start['native_path']))!=start['native_sha256']:raise ValueError('native')
original=P/'validation/repository_readiness_repair_v1/original_helpers.zip';manifest=json.loads(original.with_name('original_helpers_manifest.json').read_text())
with zipfile.ZipFile(original) as z:
 for name,h in manifest['files'].items():
  if hashlib.sha256(z.read(name)).hexdigest()!=h:raise ValueError(name)
files=json.loads(Path('/tmp/p2-readiness-owned-files.json').read_text())+['tests/research/test_validation_helper_contracts.py'];changed=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
if set(changed)-set(files):raise ValueError(('outside_scope',set(changed)-set(files)))
result={'frozen_sources':len(start['source_sha256']),'frozen_inputs':len(start['input_sha256']),'frozen_native_verified':True,'frozen_source_input_sha256':verified,'original_archive_sha256':sha(original),'original_archive_members_verified':len(manifest['files']),'candidate_source_sha256':{f:sha(R/f) for f in files},'tracked_diff_within_scope':True,'historical_receipts_no_tracked_modification':True,'article_sha256':sha(P.parent/'shot_pattern_analysis.tex')}
print(json.dumps(result,indent=2))
