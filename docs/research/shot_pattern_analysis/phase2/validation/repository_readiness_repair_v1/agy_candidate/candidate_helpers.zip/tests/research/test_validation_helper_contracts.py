"""Focused regression tests for validation helper typing repair contracts.

Exercises the precise Astra repair plan requirements without running historical
top-level script mutations or scientific simulations:
1. Finite Decimal parsing and exponent narrowing guards across the four Decimal sites.
2. Variable isolation in audit_candidate.py (cell_key) and preflight.py (path strings vs pair records).
3. Type-annotated containers in root/verify.py and review_batch.py.
4. Safe scrollbar binding and None rejection in capture_bounds_gui.py.
5. Typed heterogeneous capture structures in reproduce_saved_cell.py.
6. Safe spec/loader guards and monkeypatch attribute injection in test_review_batch.py.
7. Optional numeric-reference None rejection in review_batch.py.
8. Dataclass type exclusion in data_value and scoped mock patch for Figure.savefig in qualify.py.
"""

from __future__ import annotations

import ast
import dataclasses
from decimal import Decimal
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

ROOT = Path(__file__).resolve().parents[2]
DOCS_VALIDATION = ROOT / "docs/research/shot_pattern_analysis/phase2/validation"


def _extract_function_node(file_path: Path, func_name: str) -> ast.FunctionDef:
    """Extract an isolated FunctionDef AST node from a source file."""
    tree = ast.parse(file_path.read_text(encoding="utf-8"), filename=str(file_path))
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            return node
    raise ValueError(f"Function {func_name} not found in {file_path}")


def _compile_isolated_function(
    file_path: Path, func_name: str, extra_globals: dict[str, Any] | None = None
) -> Any:
    """Compile and return an isolated function from a source file."""
    node = _extract_function_node(file_path, func_name)
    module_ast = ast.Module(body=[node], type_ignores=[])
    code = compile(module_ast, filename=str(file_path), mode="exec")
    import numpy as np

    namespace: dict[str, Any] = {
        "Decimal": Decimal,
        "dataclasses": dataclasses,
        "np": np,
        **(extra_globals or {}),
    }
    exec(code, namespace)  # noqa: S102 - safe execution of repo AST node
    return namespace[func_name]


@pytest.mark.unit
def test_root_verify_decimal_guard_contract() -> None:
    """root/verify.py: number() must guard finite Decimal inputs and int exponents."""
    file_path = DOCS_VALIDATION / "article_source_repair_v1/root/verify.py"
    number_fn = _compile_isolated_function(file_path, "number")

    # Positive test: finite inputs matching precision pass cleanly
    number_fn("0", 0)
    number_fn("1.23", 1.23)
    number_fn("-0.395737", -0.395737)
    number_fn("+7.461556e-05", 7.461556e-05)

    # Negative test: display precision mismatch raises ValueError
    with pytest.raises(ValueError):
        number_fn("1.23", 1.25)

    # Negative tests: non-finite inputs must raise ValueError (not TypeError or InvalidOperation)
    for non_finite in ("NaN", "Infinity", "-Infinity", "sNaN"):
        with pytest.raises(ValueError, match="nonfinite|non-finite|invalid"):
            number_fn(non_finite, 0)
        with pytest.raises(ValueError, match="nonfinite|non-finite|invalid"):
            number_fn("0", non_finite)


@pytest.mark.unit
def test_audit_candidate_decimal_guard_contract() -> None:
    """audit_candidate.py: check() must reject non-finite inputs and compute finite tolerance."""
    file_path = DOCS_VALIDATION / "article_source_repair_v1/astra/audit_candidate.py"
    rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    check_fn = _compile_isolated_function(
        file_path,
        "check",
        extra_globals={"rows": rows, "failures": failures},
    )

    # Positive test
    check_fn("field_a", "0.50", 0.50)
    assert len(rows) == 1
    assert rows[0]["matches_display_precision"] is True
    assert len(failures) == 0

    # Non-finite inputs must raise ValueError
    for non_finite in ("NaN", "Infinity", "-Infinity"):
        with pytest.raises(ValueError, match="nonfinite|non-finite|invalid"):
            check_fn("field_bad", non_finite, 0.0)


@pytest.mark.unit
def test_audit_candidate_key_rename_contract() -> None:
    """audit_candidate.py must rename the reused `key` tuple variable to avoid type conflict."""
    file_path = DOCS_VALIDATION / "article_source_repair_v1/astra/audit_candidate.py"
    tree = ast.parse(file_path.read_text(encoding="utf-8"))

    # Verify that in the nested control_records loops, the tuple key is NOT named 'key'
    found_nested_loop = False
    for node in ast.walk(tree):
        if isinstance(node, ast.For) and isinstance(node.target, ast.Name):
            if node.target.id == "pair":
                for child in node.body:
                    if (
                        isinstance(child, ast.For)
                        and isinstance(child.target, ast.Name)
                        and child.target.id == "src"
                    ):
                        found_nested_loop = True
                        for inner in child.body:
                            if isinstance(inner, ast.Assign):
                                for target in inner.targets:
                                    if isinstance(target, ast.Name):
                                        assert target.id != "key", (
                                            "Tuple assignment in control_records loop must not reuse 'key'"
                                        )
    assert found_nested_loop, (
        "Did not locate nested control_records loop in audit_candidate.py"
    )


@pytest.mark.unit
def test_audit_interactions_decimal_guard_ast() -> None:
    """audit_interactions.py must validate finite Decimal inputs and int exponent."""
    file_path = DOCS_VALIDATION / "article_source_repair_v1/astra/audit_interactions.py"
    content = file_path.read_text(encoding="utf-8")
    assert "is_finite()" in content, (
        "audit_interactions.py must contain is_finite() check"
    )


@pytest.mark.unit
def test_final_check_decimal_guard_ast() -> None:
    """final_check.py must validate finite Decimal inputs and int exponent."""
    file_path = DOCS_VALIDATION / "article_source_repair_v1/astra/final_check.py"
    content = file_path.read_text(encoding="utf-8")
    assert "is_finite()" in content, "final_check.py must contain is_finite() check"


@pytest.mark.unit
def test_root_verify_container_annotations_ast() -> None:
    """root/verify.py must annotate effects and seen containers with actual types."""
    file_path = DOCS_VALIDATION / "article_source_repair_v1/root/verify.py"
    tree = ast.parse(file_path.read_text(encoding="utf-8"))

    annotated_vars: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            annotated_vars.add(node.target.id)

    assert "effects" in annotated_vars, (
        "effects container in root/verify.py must be type-annotated"
    )
    assert "seen" in annotated_vars, (
        "seen container in root/verify.py must be type-annotated"
    )


@pytest.mark.unit
def test_capture_bounds_gui_scrollbar_guard_ast() -> None:
    """capture_bounds_gui.py must bind verticalScrollBar() and reject None."""
    file_path = DOCS_VALIDATION / "capture_bounds_gui.py"
    content = file_path.read_text(encoding="utf-8")
    assert "scrollbar = widget.controls_scroll.verticalScrollBar()" in content
    assert (
        "scrollbar is None" in content
        or "if not scrollbar:" in content
        or "if scrollbar is None:" in content
    )


@pytest.mark.unit
def test_reproduce_saved_cell_typed_collection_ast() -> None:
    """reproduce_saved_cell.py must annotate the heterogeneous results collection."""
    file_path = (
        DOCS_VALIDATION / "final_figure_marginal_gutter_review/reproduce_saved_cell.py"
    )
    tree = ast.parse(file_path.read_text(encoding="utf-8"))

    annotated = False
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if node.target.id == "results":
                annotated = True
    assert annotated, "results in reproduce_saved_cell.py must be type-annotated"


@pytest.mark.unit
def test_test_review_batch_spec_and_loader_guard_ast() -> None:
    """test_review_batch.py must check spec and spec.loader before exec_module."""
    file_path = DOCS_VALIDATION / "v6_output_review_harness_v1/test_review_batch.py"
    content = file_path.read_text(encoding="utf-8")
    assert (
        "spec is None" in content
        or "if spec is None or spec.loader is None:" in content
    )
    assert "raising=False" in content, (
        "test_review_batch.py should use monkeypatch.setattr with raising=False"
    )


@pytest.mark.unit
def test_review_batch_reference_guard_and_pending_annotation_ast() -> None:
    """review_batch.py must reject None numeric reference and annotate pending list."""
    file_path = DOCS_VALIDATION / "v6_output_review_harness_v1/review_batch.py"
    content = file_path.read_text(encoding="utf-8")
    assert "if reference is None:" in content or "reference is None" in content
    tree = ast.parse(content)
    annotated_pending = False
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if node.target.id == "pending":
                annotated_pending = True
    assert annotated_pending, "pending in review_batch.py must be type-annotated"


@pytest.mark.unit
def test_preflight_variable_isolation_ast() -> None:
    """preflight.py must not reuse 'p' for source_hashes loop after pairs loop."""
    file_path = DOCS_VALIDATION / "driver_curve_bounds_reporting_review_v1/preflight.py"
    tree = ast.parse(file_path.read_text(encoding="utf-8"))

    for node in ast.walk(tree):
        if isinstance(node, ast.For):
            # Check if this loop iterates over source_hashes.items()
            iter_call = node.iter
            if (
                isinstance(iter_call, ast.Call)
                and isinstance(iter_call.func, ast.Attribute)
                and iter_call.func.attr == "items"
                and isinstance(iter_call.func.value, ast.Name)
                and iter_call.func.value.id == "source_hashes"
            ):
                if isinstance(node.target, ast.Tuple) and len(node.target.elts) == 2:
                    first = node.target.elts[0]
                    if isinstance(first, ast.Name):
                        assert first.id != "p", (
                            "source_hashes loop must use distinct variable name (e.g. path_str), not 'p'"
                        )


@pytest.mark.unit
def test_qualify_dataclass_type_exclusion() -> None:
    """qualify.py: data_value() must not pass dataclass classes (type[T]) to asdict()."""
    file_path = DOCS_VALIDATION / "selected_renderer_representative_v1/qualify.py"
    data_value_fn = _compile_isolated_function(file_path, "data_value")

    @dataclasses.dataclass
    class SampleConfig:
        name: str
        value: int

    # Instance should convert to dict
    inst = SampleConfig(name="test", value=42)
    res = data_value_fn(inst)
    assert res == {"name": "test", "value": 42}

    # Class object should NOT be passed to asdict (which raises TypeError), but returned as-is
    res_class = data_value_fn(SampleConfig)
    assert res_class is SampleConfig


@pytest.mark.unit
def test_qualify_scoped_mock_patch_ast() -> None:
    """qualify.py: Figure.savefig assignment must use scoped patch.object instead of direct method assignment."""
    file_path = DOCS_VALIDATION / "selected_renderer_representative_v1/qualify.py"
    content = file_path.read_text(encoding="utf-8")
    assert "Figure.savefig = save" not in content, (
        "Direct Figure.savefig assignment must be replaced with scoped patch.object"
    )
    assert "patch.object(Figure" in content or "patch.object(" in content, (
        "qualify.py must use scoped patch.object for Figure.savefig"
    )
