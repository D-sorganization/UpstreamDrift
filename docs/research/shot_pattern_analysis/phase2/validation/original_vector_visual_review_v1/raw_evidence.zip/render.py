from pathlib import Path
import hashlib,json,subprocess,os
from PIL import Image,ImageOps,ImageDraw
R=Path('/home/dieterolson/.codex/worktrees/shot-pattern-analysis/UpstreamDrift');B=R/'docs/research/shot_pattern_analysis/phase2';O=Path('/tmp/p2-original-vector-visual-review')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'final_figures_v1':'16e0a645fe840c24712c42467bffed59f3cb9204fabbeb8c5ce7289b3b9b2449','control_final_figures_v1':'47ea6e292883ea5958651e6786d5b73f2f463ebd004488d75c77f385036f34fd'}
rows=[]
selectors=[
('driver_academic_density','final_figures_v1','details/driver_lean5_curve2_rotation2_combined2/density'),
('driver_academic_overhead','control_final_figures_v1','details/driver_lean0_curve2_rotation2_combined2/overhead'),
('driver_social_density','final_figures_v1','social/details/driver_lean0_curve2_rotation2_combined2/density'),
('driver_social_overhead','final_figures_v1','social/details/driver_lean0_curve2_rotation2_combined2/overhead'),
('iron_academic_density','control_final_figures_v1','details/seven_iron_lean10_curve2_rotation2_shaft_only/density'),
('iron_academic_overhead','control_final_figures_v1','details/seven_iron_lean10_curve2_rotation2_shaft_only/overhead'),
('iron_social_density','final_figures_v1','social/details/seven_iron_lean0_curve2_rotation2_combined2/density'),
('iron_social_overhead','final_figures_v1','social/details/seven_iron_lean0_curve2_rotation2_combined2/overhead'),
('pw_academic_density','control_final_figures_v1','details/pitching_wedge_lean10_curve2_rotation2_combined2/density'),
('pw_academic_overhead','control_final_figures_v1','details/pitching_wedge_lean10_curve2_rotation2_combined2/overhead'),
('pw_social_density','final_figures_v1','social/details/pitching_wedge_lean5_curve2_rotation2_combined2/density'),
('pw_social_overhead','final_figures_v1','social/details/pitching_wedge_lean5_curve2_rotation2_combined2/overhead')]
for label,dataset,stem in selectors:
 m=B/dataset/'figure_manifest.json'
 if sha(m)!=expected[dataset]:raise ValueError('Manifest drift')
 outputs=json.loads(m.read_text())['outputs'];files={}
 for ext in ['png','pdf','svg']:
  rel=stem+'.'+ext;p=B/dataset/rel
  if sha(p)!=outputs[rel]:raise ValueError('Asset drift')
  files[ext]={'path':str(p),'sha256':outputs[rel]}
 rows.append({'label':label,'dataset':dataset,'stem':stem,'sources':files})
(O/'selected_before_view.json').write_text(json.dumps({'manifests':expected,'families':rows},indent=2)+'\n')
node='/home/dieterolson/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
env={**os.environ,'NODE_PATH':'/home/dieterolson/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'}
js="const sharp=require('sharp'); sharp(process.argv[1],{density:144,limitInputPixels:50000000}).flatten({background:'#fff'}).png().toFile(process.argv[2]).then(x=>console.log(JSON.stringify(x))).catch(e=>{console.error(e);process.exit(1)});"
for row in rows:
 paths=[]
 for ext in ['pdf','svg']:
  dest=O/(row['label']+'_'+ext+'.png');src=row['sources'][ext]['path']
  args=['pdftoppm','-f','1','-singlefile','-r','144','-png',src,str(dest.with_suffix(''))] if ext=='pdf' else [node,'-e',js,src,str(dest)]
  result=subprocess.run(args,env=env,capture_output=True,text=True)
  (O/(row['label']+'_'+ext+'.txt')).write_text(result.stdout+result.stderr)
  if result.returncode:raise ValueError((row['label'],ext,result.returncode))
  with Image.open(dest) as im:size=list(im.size)
  row.setdefault('renders',{})[ext]={'path':str(dest),'sha256':sha(dest),'dimensions':size,'command':args}
  paths.append(dest)
 panels=[]
 for ext,p in zip(['PDF','SVG'],paths):
  with Image.open(p) as im:
   fitted=ImageOps.contain(im.convert('RGB'),(1500,1900))
   canvas=Image.new('RGB',(1500,1950),'white');canvas.paste(fitted,((1500-fitted.width)//2,40));ImageDraw.Draw(canvas).text((12,12),row['label']+' '+ext,fill='black');panels.append(canvas)
 sheet=Image.new('RGB',(3000,1950),'white')
 for i,p in enumerate(panels):sheet.paste(p,(1500*i,0))
 view=O/(row['label']+'_review.jpg');sheet.save(view,quality=94);row['review_image']={'path':str(view),'sha256':sha(view)}
 print(row['label'],flush=True)
for row in rows:
 for item in row['sources'].values():
  if sha(Path(item['path']))!=item['sha256']:raise ValueError('Source changed')
for dataset,digest in expected.items():
 if sha(B/dataset/'figure_manifest.json')!=digest:raise ValueError('Manifest changed')
(O/'render_receipt.json').write_text(json.dumps({'families':rows,'manifests':expected,'sources_unchanged':True,'script_sha256':sha(Path(__file__)),'visual_acceptance':False,'density_caveat':'Actual dimensions recorded; no equal-DPI/pixel-equivalence claim'},indent=2)+'\n')
