import os,sys,json,hashlib,subprocess
from pathlib import Path
root=Path('/home/dieterolson/.codex/worktrees/shot-pattern-main-integration/UpstreamDrift');out=Path('/tmp/p2-launcher-boundary-review')
sys.path.insert(0,str(root/'vendor/ud-tools/src'))
from agent_context.catalog import load_catalog
from agent_context import reviews
import agent_context
cat=load_catalog(root);rel=next(r for r in cat.relations if r.id=='launcher-atlas');inputs=reviews.inputs(cat,rel);finger=reviews.fingerprint(rel,inputs)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
extra=['docs/agent_context/catalog.json','src/config/feature_parity_loader.py','src/tools/capture_rig/workflow.py','scripts/generate_capability_atlas.py','scripts/capability_atlas/template.html','tests/config/test_launcher_manifest.py']
paths=set(inputs)|set(extra)
paths.update(str(p.relative_to(root)) for p in (root/'vendor/ud-tools/src/agent_context').glob('*.py'))
before={p:sha(root/p) for p in sorted(paths)}
start={'fingerprint':finger,'relation_inputs':inputs,'before_sha256':before,'agent_context_module':agent_context.__file__,'python_executable':sys.executable,'tools_head':subprocess.check_output(['git','-C',str(root/'vendor/ud-tools'),'rev-parse','HEAD'],text=True).strip()}
(out/'start.json').write_text(json.dumps(start,indent=2)+'\n')
env=dict(os.environ,PYTHONPATH=str(root/'vendor/ud-tools/src')+':'+str(root),QT_QPA_PLATFORM='offscreen',MPLBACKEND='Agg',MUJOCO_GL='egl',SDL_VIDEODRIVER='dummy',PYTHONDONTWRITEBYTECODE='1')
cmd=[sys.executable,'-m','pytest','-o','addopts=','-q','tests/scripts/test_capability_atlas.py','tests/config/test_launcher_manifest.py','tests/tools/capture_rig/test_goal_catalog.py','tests/tools/capture_rig/test_goal_planner.py']
with (out/'tests.txt').open('w') as f:proc=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
after={p:sha(root/p) for p in sorted(paths)}
result={**start,'command':cmd,'exit_code':proc.returncode,'source_unchanged':before==after,'after_sha256':after,'tests_sha256':sha(out/'tests.txt'),'review_record_written':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(proc.returncode,before==after,finger)
sys.exit(0 if proc.returncode==0 and before==after else 1)
