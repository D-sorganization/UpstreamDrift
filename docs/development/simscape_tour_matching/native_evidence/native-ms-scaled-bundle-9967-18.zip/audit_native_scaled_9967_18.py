"""Audit actual scaled solver callbacks on native windows without optimization."""
import hashlib,json,runpy,sys
from pathlib import Path
import numpy as np
from src.shared.python.motion_matching import equality_least_squares as eq
root=Path('/mnt/c/Users/diete');out=root/'native-ms-scaled-audit-9967-18'
def audit(fun,y0,**kwargs):
    cfg=json.loads((out/'config.json').read_text()); scale=np.array(cfg['variable_scales'])
    assert np.array_equal(y0,np.zeros_like(y0))
    bounds=np.array(kwargs['bounds']); con=kwargs['constraints']; rows=[]
    cjac=con['jac'](y0); grad=kwargs['jac'](y0); identity=cjac/scale
    spectra={}
    for name,matrix in [('identity',identity),('half_box',cjac)]:
        singular=np.linalg.svd(matrix,compute_uv=False)
        spectra[name]={'largest':float(singular[0]),'smallest':float(singular[-1]),'condition':float(singular[0]/singular[-1]),'rank':int(np.linalg.matrix_rank(matrix))}
    rng=np.random.default_rng(996718)
    for name,direction in [('random',rng.normal(size=len(y0))),('gradient',grad.copy())]:
        direction/=np.linalg.norm(direction)
        expected_cost=float(grad@direction); expected_c=cjac@direction
        for h in [1e-5,1e-6]:
            plus=y0+h*direction;minus=y0-h*direction
            assert np.all(plus>bounds[:,0]) and np.all(plus<bounds[:,1]) and np.all(minus>bounds[:,0]) and np.all(minus<bounds[:,1])
            fp=fun(plus);cp=con['fun'](plus);fm=fun(minus);cm=con['fun'](minus)
            fd=(fp-fm)/(2*h);fc=(cp-cm)/(2*h)
            rows.append({'direction':name,'h':h,'predicted_cost_slope':expected_cost,'fd_cost_slope':float(fd),'cost_relative':float(abs(fd-expected_cost)/max(abs(fd),abs(expected_cost),1e-30)),'constraint_relative':float(np.linalg.norm(fc-expected_c)/max(np.linalg.norm(fc),np.linalg.norm(expected_c),1e-30))})
    passed=all(max(row['cost_relative'],row['constraint_relative'])<1e-3 for row in rows)
    report={'qualification':'Actual scaled SLSQP callback audit at native common initial point; no optimization or fit acceptance','passed':passed,'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'variables':len(y0),'objective':float(fun(y0)),'constraint_jacobian_spectra':spectra,'checks':rows}
    (out/'scaled-callback-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    if not passed:raise ValueError('Scaled native callback audit failed')
    raise SystemExit(0)
eq.minimize=audit
sys.argv=['run_native_ms_scaled_9967_18.py','--output',str(out),'--max-nfev','100','--max-iterations','60','--horizon','.85','--nodes','.2','.4','.6','.7','.8','.85','--basis-duration','.8','--node-bound','.05','--equality-tolerance','1e-7']
runpy.run_path(str(root/'run_native_ms_scaled_9967_18.py'),run_name='__main__')
