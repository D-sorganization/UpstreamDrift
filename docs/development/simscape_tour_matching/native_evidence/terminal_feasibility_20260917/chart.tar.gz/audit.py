from pathlib import Path
import json,sys,importlib.util
import numpy as np
from src.engines.physics_engines.pinocchio.python.native_node_chart import NativeNodeChart
p=Path('/home/dieterolson/native-terminal-feasibility-20260917-02/corrected_native.py');s=importlib.util.spec_from_file_location('corrected_native',p);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
root=Path('/home/dieterolson/native-clean-replay-20260917-01');doc=json.loads((root/'candidate.json').read_text());names=doc['coordinate_names'];n=len(names);plant=m.NativePinocchioModel(json.loads((root/'model.bin').read_bytes()));ref=np.load(root/'reference.npz');scales=np.r_[np.full(n,0.1),np.ones(n)]
chart=NativeNodeChart(names,plant,state_scales=scales,residual_scales=np.r_[np.full(6,0.01),np.full(6,0.1)],radius=0.5,tolerance=1e-8,jacobian_step=1e-6)
rng=np.random.default_rng(170917);records=[]
for index in [0,216,306]:
 base=ref['native_state'][index]
 for off in [0.0,0.1]:
  state=base.copy();state[names.index('LWInputX')]+=off;jac=chart.jacobian(state);errors=[];passed=True
  for eps in [1e-4,1e-5,1e-6]:
   direction=rng.normal(size=2*n);direction=direction/np.linalg.norm(direction)*scales
   observed=(chart.closure(state+eps*direction)-chart.closure(state-eps*direction))/(2*eps);predicted=jac@direction;errors.append(float(np.max(np.abs(observed-predicted))));passed=passed and bool(np.allclose(observed,predicted,rtol=2e-5,atol=2e-7))
  records.append({'kind':'closure_jacobian','frame':index,'wrist_offset_rad':off,'max_error':max(errors),'passed':passed})
 basis=chart.basis(base);z=rng.normal(size=basis.shape[1])*0.001;out=chart.retract(base,basis,z);direction=rng.normal(size=len(z));direction/=np.linalg.norm(direction);eps=1e-5
 lo=chart.retract(base,basis,z-eps*direction);hi=chart.retract(base,basis,z+eps*direction);observed=(hi.state-lo.state)/(2*eps);predicted=out.state_jacobian@direction
 records.append({'kind':'nonzero_retraction','frame':index,'closure_max_abs':float(np.max(np.abs(chart.closure(out.state)))),'max_derivative_error':float(np.max(np.abs(observed-predicted))),'passed':bool(np.allclose(observed,predicted,rtol=2e-5,atol=2e-7))})
receipt={'qualification':'sampled native chart/retraction directional tests; not full optimizer qualification','dependency_commit':'0db3c295a7f668789afbb4666f60912294f81cce','records':records};Path('receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
