from pathlib import Path
import json,sys,importlib.util,time
import numpy as np
from src.shared.python.motion_matching.pelvis_yaw import compute_pelvis_yaw_residual_and_derivative
from src.engines.physics_engines.pinocchio.python.native_node_chart import NativeNodeChart

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
native=load('corrected_native','corrected_native.py')
solver=load('src.shared.python.motion_matching.feasibility_audit_solver','constrained_marker_pose.py')
root=Path('/home/dieterolson/native-clean-replay-20260917-01');spec=json.loads((root/'model.bin').read_bytes());doc=json.loads((root/'candidate.json').read_text());ref=np.load(root/'reference.npz');names=tuple(doc['coordinate_names']);n=len(names);plant=native.NativePinocchioModel(spec)
state=ref['native_state'][-1];q0=state[:n].copy();target=ref['target_m'][-1];valid=ref['valid'][-1];offsets=np.array(doc['marker_offsets_m']);wl,wr=(doc['marker_labels'].index(k) for k in ['WaistLeft','WaistRight'])
def coordinates(q):return dict(zip(names,map(float,q),strict=True))
def marker(q):return plant.marker_derivatives(coordinates(q),doc['marker_bodies'],offsets)
def forward(q):return marker(q).positions_m
def yaw(q):
 m=marker(q);r,j,metrics=compute_pelvis_yaw_residual_and_derivative(m.positions_m,target,wl,wr,1.0,m.dposition_dq)
 if not metrics.valid:raise ValueError('Undefined pelvis yaw')
 v=m.positions_m[wr,:2]-m.positions_m[wl,:2];u=v/np.linalg.norm(v)
 return np.deg2rad(metrics.yaw_diff_deg),np.array([-u[1],u[0]])@j,metrics

yaw_offset=0.0
def closure(q):
 pose=plant.closure_residuals(coordinates(q))[0]
 return pose if yaw_offset is None else np.r_[pose,yaw(q)[0]-yaw_offset]
def closure_jac(q):
 jac=plant.closure_position_linearization(coordinates(q)).jacobian
 return jac if yaw_offset is None else np.vstack([jac,yaw(q)[1]])
# Qualify the augmented closure/yaw derivatives before supplying them to SLSQP.
rng=np.random.default_rng(170917);direction=rng.normal(size=n);direction/=np.linalg.norm(direction);eps=1e-6
observed=(closure(q0+eps*direction)-closure(q0-eps*direction))/(2*eps)
np.testing.assert_allclose(closure_jac(q0)@direction,observed,rtol=2e-6,atol=2e-7)
chart=NativeNodeChart(names,plant,state_scales=np.r_[np.full(n,0.1),np.ones(n)],residual_scales=np.r_[np.full(6,0.01),np.full(6,0.1)],radius=0.5,tolerance=1e-8,jacobian_step=1e-6)
basis=chart.basis(state);zero=chart.retract(state,basis,np.zeros(basis.shape[1]));tangent=basis@np.full(basis.shape[1],1e-5);chart_jac=chart.jacobian(state);observed=(chart.closure(state+1e-4*tangent)-chart.closure(state-1e-4*tangent))/(2e-4)
chart_error=float(np.max(np.abs(chart_jac@tangent-observed)));chart_ok=bool(np.allclose(chart_jac@tangent,observed,rtol=2e-4,atol=2e-7))
results=[];started=time.perf_counter()
yaw_limit=np.deg2rad(0.05*max(abs(yaw(q0)[2].yaw_target_deg),1.0))
for yaw_offset in [None,-yaw_limit,-yaw_limit/2,0.0,yaw_limit/2,yaw_limit]:
 radius=1.0
 widths=np.r_[np.full(3,0.25),np.full(n-3,radius)]
 for start_id in range(3):
  start=q0.copy() if start_id==0 else q0+rng.uniform(-0.2,0.2,n)*widths
  result=solver.fit_marker_pose(start,q0-widths,q0+widths,target,valid,forward,closure,forward_jacobian=lambda q:marker(q).dposition_dq,closure_jacobian=closure_jac,max_iterations=150,closure_tolerance=1e-7)
  pred=forward(result.coordinates);_,_,ym=yaw(result.coordinates)
  record={'prescribed_yaw_offset_rad':yaw_offset,'yaw_gate':ym.pelvis_yaw_error_pct<=5.0+1e-8,'radius_rad':radius,'translation_halfwidth_m':0.25,'start':start_id,'marker_rms_m':result.marker_rms_m,'closure_max_abs':result.closure_max_abs,'converged':result.optimizer_converged,'message':result.message,'iterations':result.iterations,'yaw_error_pct':ym.pelvis_yaw_error_pct,'marker_gate':result.marker_rms_m<=0.035,'closure_gate':result.closure_satisfied,'coordinates':result.coordinates.tolist(),'predicted_markers_m':pred.tolist(),'per_marker_error_m':dict(zip(doc['marker_labels'],np.linalg.norm(pred-target,axis=1).tolist(),strict=True))}
  results.append(record);print(json.dumps({k:v for k,v in record.items() if k not in ['coordinates','predicted_markers_m','per_marker_error_m']}),flush=True)
receipt={'qualification':'local static connected-pose witness; not forward-dynamics or anatomical-limit acceptance','dependency_commit':'0db3c295a7f668789afbb4666f60912294f81cce','time_s':float(ref['time_s'][-1]),'valid_markers':int(valid.sum()),'local_bounds_only':True,'geometry_and_attachments_unchanged':True,'chart_zero_retraction_max_shift':float(np.max(np.abs(zero.state-state))),'chart_directional_error':chart_error,'chart_directional_passed':chart_ok,'elapsed_s':time.perf_counter()-started,'records':results}
Path('receipt.json').write_text(json.dumps(receipt,indent=2));print('Audit complete',flush=True)
