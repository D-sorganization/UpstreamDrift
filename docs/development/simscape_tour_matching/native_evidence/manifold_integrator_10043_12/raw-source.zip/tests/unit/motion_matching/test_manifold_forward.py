"""Independent order checks for local-chart RK4 on configurations and tangents."""

import numpy as np
import pytest
from scipy.spatial.transform import Rotation

from src.shared.python.motion_matching.manifold_forward import (
    integrate_manifold_forward,
)

pytestmark = pytest.mark.unit


def _so3_integrate(q, u):
    return (Rotation.from_quat(q) * Rotation.from_rotvec(u.copy())).as_quat()


def _so3_difference_rate(anchor, q, velocity):
    u = (Rotation.from_quat(anchor).inv() * Rotation.from_quat(q)).as_rotvec()
    theta = np.linalg.norm(u)
    x, y, z = u
    skew = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
    coefficient = (
        1 / 12 if theta < 1e-6 else (1 - theta / (2 * np.tan(theta / 2))) / theta**2
    )
    return (np.eye(3) + 0.5 * skew + coefficient * skew @ skew) @ velocity


def test_noncommuting_rotation_has_fourth_order_convergence():
    # Independent exact R(t)=Rx(t) Ry(t^2), whose angular velocity in the
    # moving body is [cos(t^2), 2t, sin(t^2)]. Rotations do not commute.
    target = Rotation.from_rotvec([1, 0, 0]) * Rotation.from_rotvec([0, 1, 0])
    errors = []
    for step in (0.2, 0.1, 0.05):
        result = integrate_manifold_forward(
            np.array([0, 0, 0, 1.0]),
            np.array([1.0, 0, 0]),
            np.array([0.0, 1.0]),
            lambda t, q, v: np.array(
                [-2 * t * np.sin(t * t), 2.0, 2 * t * np.cos(t * t)]
            ),
            integrate=_so3_integrate,
            difference_rate=_so3_difference_rate,
            max_step=step,
        )
        error = np.linalg.norm(
            (target.inv() * Rotation.from_quat(result.configuration[-1])).as_rotvec()
        )
        errors.append(error)
        assert result.configuration.shape == (2, 4)
        assert result.velocity.shape == (2, 3)
        np.testing.assert_allclose(
            np.linalg.norm(result.configuration, axis=1), 1, atol=2e-15
        )
        assert result.evaluations == 4 * result.steps
    assert 12 < errors[0] / errors[1] < 20
    assert 12 < errors[1] / errors[2] < 20
    assert errors[-1] < 3e-7


def test_euclidean_limit_exact_clock_and_owned_readonly_outputs():
    q0, v0, clock = np.array([0.0]), np.array([2.0]), np.array([0.0, 0.13, 0.31, 0.7])
    calls = []

    def acceleration(t, q, v):
        calls.append(t)
        return np.array([3.0])

    result = integrate_manifold_forward(
        q0,
        v0,
        clock,
        acceleration,
        integrate=lambda q, u: q + u,
        difference_rate=lambda anchor, q, v: v,
        max_step=0.05,
    )
    np.testing.assert_array_equal(result.time, clock)
    np.testing.assert_allclose(
        result.configuration[:, 0], 2 * clock + 1.5 * clock**2, atol=2e-15
    )
    np.testing.assert_allclose(result.velocity[:, 0], 2 + 3 * clock, atol=2e-15)
    assert min(calls) == 0
    assert max(calls) == pytest.approx(clock[-1])
    q0[:], v0[:], clock[:] = 9, 9, 9
    assert result.time[0] == result.configuration[0, 0] == 0
    assert result.velocity[0, 0] == 2
    for array in (result.time, result.configuration, result.velocity):
        assert not array.flags.writeable


@pytest.mark.parametrize(
    "clock,step",
    [
        (np.array([0.0, 0.0]), 0.1),
        (np.array([1.0, 2.0]), 0.1),
        (np.array([0.0, 1.0]), 0),
        (np.array([0.0, 1.0]), np.nan),
    ],
)
def test_invalid_clock_or_step_is_rejected(clock, step):
    with pytest.raises(ValueError):
        integrate_manifold_forward(
            np.ones(1),
            np.ones(1),
            clock,
            lambda t, q, v: v,
            integrate=lambda q, u: q + u,
            difference_rate=lambda a, q, v: v,
            max_step=step,
        )


@pytest.mark.parametrize("kind", ["acceleration", "integrate", "difference_rate"])
def test_malformed_callback_output_is_rejected(kind):
    callbacks = {
        "acceleration": lambda t, q, v: v,
        "integrate": lambda q, u: q + u,
        "difference_rate": lambda a, q, v: v,
    }
    callbacks[kind] = lambda *args: np.array([np.nan])
    with pytest.raises(ValueError, match=kind):
        integrate_manifold_forward(
            np.ones(1), np.ones(1), np.array([0.0, 0.1]), **callbacks
        )


def test_euclidean_coupled_configuration_velocity_has_fourth_order():
    errors = []
    for h in (0.2, 0.1, 0.05):
        result = integrate_manifold_forward(
            np.array([1.0]),
            np.array([0.0]),
            np.array([0.0, 1.0]),
            lambda t, q, v: -q,
            integrate=lambda q, u: q + u,
            difference_rate=lambda anchor, q, v: v,
            max_step=h,
        )
        errors.append(
            np.linalg.norm(
                [
                    result.configuration[-1, 0] - np.cos(1),
                    result.velocity[-1, 0] + np.sin(1),
                ]
            )
        )
    assert 14 < errors[0] / errors[1] < 18
    assert 14 < errors[1] / errors[2] < 18
