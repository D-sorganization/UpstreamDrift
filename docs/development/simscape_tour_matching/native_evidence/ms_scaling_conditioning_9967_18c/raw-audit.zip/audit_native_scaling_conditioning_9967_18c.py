"""Compare native variable scalings without changing the physical problem."""
import hashlib,json,runpy,sys
from pathlib import Path
import numpy as np
from src.shared.python.motion_matching import multi_shooting_fit as shared
root=Path('/mnt/c/Users/diete');out=root/'native-ms-scaling-conditioning-9967-18c'
def spectrum(matrix):
    s=np.linalg.svd(matrix,compute_uv=False)
    retained=s[s>s[0]*1e-8]
    return {'largest':float(s[0]),'smallest':float(s[-1]),'condition':float(s[0]/s[-1]),'rank_relative_1e8':len(retained),'retained_condition_relative_1e8':float(retained[0]/retained[-1])}
def audit(fun,jac,x0,lower,upper,**kwargs):
    r=fun(x0);J=jac(x0);P=kwargs['projection'];start=kwargs['equality_start'];end=start+P.shape[1]
    C=P@J[start:end];mask=np.ones(len(r),dtype=bool);mask[start:end]=False;M=J[mask]
    norms=np.sqrt(np.sum(M*M,axis=0)+np.sum(C*C,axis=0));assert np.all(norms>0)
    balanced=1/norms;balanced/=np.median(balanced[:189])
    rows=[]
    for name,scale in [('identity',np.ones_like(x0)),('half_box',kwargs['variable_scales']),('combined_jacobian',balanced)]:
        cs=C*scale;ms=M*scale
        _,sv,vt=np.linalg.svd(cs,full_matrices=True);rank=int(np.linalg.matrix_rank(cs));assert rank==P.shape[0]
        Z=vt[rank:].T
        rows.append({'name':name,'scales':scale.tolist(),'constraint':spectrum(cs),'feasible_marker_jacobian':spectrum(ms@Z),'gradient_norm':float(np.linalg.norm(2*ms.T@r[mask])),'scale_min':float(scale.min()),'scale_max':float(scale.max())})
    report={'qualification':'Local Jacobian scaling comparison at common native initial point; singular values are not achieved tracking gains or a convergence proof','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
    (out/'scaling-conditioning.json').write_text(json.dumps(report,indent=2)+'\n')
    raise SystemExit(0)
shared.solve_equality_least_squares=audit
sys.argv=['run_native_ms_scaled_9967_18.py','--output',str(out),'--max-nfev','100','--max-iterations','60','--horizon','.85','--nodes','.2','.4','.6','.7','.8','.85','--basis-duration','.8','--node-bound','.05','--equality-tolerance','1e-7']
runpy.run_path(str(root/'run_native_ms_scaled_9967_18.py'),run_name='__main__')
