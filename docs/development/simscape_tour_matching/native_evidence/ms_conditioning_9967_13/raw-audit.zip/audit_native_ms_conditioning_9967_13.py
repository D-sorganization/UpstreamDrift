"""Measure assembled shooting conditioning without optimization or trial replay."""
import json,runpy,sys
from pathlib import Path
import numpy as np
from src.shared.python.motion_matching import multi_shooting_fit as shared
root=Path('/mnt/c/Users/diete');out=root/'native-ms-conditioning-9967-13'
def audit(fun,x0,**kwargs):
 r=fun(x0);J=kwargs['jac'](x0)
 norms=np.linalg.norm(J,axis=0);nonzero=norms>0;scale=np.where(nonzero,norms,1.)
 U,s,Vt=np.linalg.svd(J/scale,full_matrices=False)
 lo,hi=kwargs['bounds'];rows=[]
 for cutoff in [1e-4,1e-6,1e-8,1e-10]:
  keep=s>s[0]*cutoff
  step=-(Vt[keep].T@((U[:,keep].T@r)/s[keep]))/scale
  fraction=np.ones_like(step)
  np.divide(hi-x0,step,out=fraction,where=step>0)
  np.divide(lo-x0,step,out=fraction,where=step<0)
  bound_fraction=float(min(1.,np.min(fraction)))
  predicted=r+J@step
  rows.append({'relative_cutoff':cutoff,'retained_rank':int(keep.sum()),'predicted_full_step_cost':float(predicted@predicted),'first_bound_fraction':bound_fraction,'max_effort_control_step':float(np.max(abs(step[:189]))),'max_node_coordinate_step':float(np.max(abs(step[189:])))})
 report={'qualification':'Linearized column-normalized Jacobian conditioning at run13 initial point; no proposed step has been forward-replayed or accepted','parameter_count':len(x0),'residual_count':len(r),'initial_cost':float(r@r),'nonzero_columns':int(nonzero.sum()),'column_norm_min':float(norms.min()),'column_norm_max':float(norms.max()),'largest_scaled_singular_values':s[:10].tolist(),'smallest_scaled_singular_values':s[-10:].tolist(),'linearized_trials':rows}
 (out/'conditioning.json').write_text(json.dumps(report,indent=2)+'\n')
 raise SystemExit(0)
shared.least_squares=audit
sys.argv=['run_native_ms_horizon_9967_13.py','--output',str(out),'--horizon','.85','--nodes','.2','.4','.6','.7','.8','.85','--basis-duration','.8','--max-nfev','1','--defect-weight','1000']
runpy.run_path(str(root/'run_native_ms_horizon_9967_13.py'),run_name='__main__')
