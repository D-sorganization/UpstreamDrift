from pathlib import Path
import json,sys,importlib.util,time
import numpy as np
from src.shared.python.motion_matching.pelvis_yaw import compute_pelvis_yaw_residual_and_derivative
from src.engines.physics_engines.pinocchio.python.native_node_chart import NativeNodeChart

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
native=load('corrected_native','corrected_native.py')
solver=load('src.shared.python.motion_matching.feasibility_audit_solver','constrained_marker_pose.py')
root=Path('/home/dieterolson/native-clean-replay-20260917-01');spec=json.loads((root/'model.bin').read_bytes());doc=json.loads((root/'candidate.json').read_text());ref=np.load(root/'reference.npz');names=tuple(doc['coordinate_names']);n=len(names);plant=native.NativePinocchioModel(spec)
state=ref['native_state'][-1];q0=state[:n].copy();target=ref['target_m'][-1];valid=ref['valid'][-1];offsets=np.array(doc['marker_offsets_m']);wl,wr=(doc['marker_labels'].index(k) for k in ['WaistLeft','WaistRight'])
def coordinates(q):return dict(zip(names,map(float,q),strict=True))
def marker(q):return plant.marker_derivatives(coordinates(q),doc['marker_bodies'],offsets)
def forward(q):return marker(q).positions_m
def yaw(q):
 m=marker(q);r,j,metrics=compute_pelvis_yaw_residual_and_derivative(m.positions_m,target,wl,wr,1.0,m.dposition_dq)
 if not metrics.valid:raise ValueError('Undefined pelvis yaw')
 v=m.positions_m[wr,:2]-m.positions_m[wl,:2];u=v/np.linalg.norm(v)
 return np.deg2rad(metrics.yaw_diff_deg),np.array([-u[1],u[0]])@j,metrics

yaw_offset=0.0
def closure(q):
 pose=plant.closure_residuals(coordinates(q))[0]
 return pose if yaw_offset is None else np.r_[pose,yaw(q)[0]-yaw_offset]
def closure_jac(q):
 jac=plant.closure_position_linearization(coordinates(q)).jacobian
 return jac if yaw_offset is None else np.vstack([jac,yaw(q)[1]])

payload_path=Path('/home/dieterolson/native-fit-audit-20260917-01/inputs/driver_marker_payload_9967.json')
payload=json.loads(payload_path.read_text());assert payload['source_sha256']==doc['capture_sha256']
idx=[payload['labels'].index(k) for k in doc['marker_labels']]
clock=np.array(payload['time_s']);targets=np.array(payload['points_world_m'])[:,idx];masks=np.array(payload['valid'],bool)[:,idx]
assert len(clock)==654 and np.all(np.diff(clock)>0)
np.testing.assert_allclose(targets[:len(ref['time_s'])],ref['target_m'],atol=1e-12,rtol=0)
assert np.array_equal(masks[:len(ref['time_s'])],ref['valid'])
frames=sorted(set([int(np.argmin(abs(clock-t))) for t in np.arange(0,clock[-1],0.05)]+[len(clock)-1]))
results=[];rng=np.random.default_rng(170918);started=time.perf_counter();previous=ref['native_state'][0,:n].copy()
for frame in frames:
 target=targets[frame];valid=masks[frame];q0=ref['native_state'][frame,:n].copy() if frame<len(ref['native_state']) else previous.copy()
 widths=np.r_[np.full(3,0.25),np.full(n-3,1.0)]
 limit=np.deg2rad(.05*max(abs(yaw(q0)[2].yaw_target_deg),1.0))
 frame_records=[]
 for yaw_offset in [0.0,-limit,limit,None]:
  for start_id in range(2):
   start=q0.copy() if start_id==0 else q0+rng.uniform(-.2,.2,n)*widths
   fit=solver.fit_marker_pose(start,q0-widths,q0+widths,target,valid,forward,closure,forward_jacobian=lambda q:marker(q).dposition_dq,closure_jacobian=closure_jac,max_iterations=200,closure_tolerance=1e-7)
   pred=forward(fit.coordinates);metrics=yaw(fit.coordinates)[2]
   rec=dict(frame=int(frame),time_s=float(clock[frame]),start=start_id,prescribed_yaw_offset_rad=yaw_offset,marker_rms_m=fit.marker_rms_m,converged=fit.optimizer_converged,closure_gate=fit.closure_satisfied,closure_max_abs=fit.closure_max_abs,yaw_error_pct=metrics.pelvis_yaw_error_pct,yaw_gate=metrics.pelvis_yaw_error_pct<=5+1e-8,iterations=fit.iterations,message=fit.message,coordinates=fit.coordinates.tolist(),predicted_markers_m=pred.tolist(),target_markers_m=target.tolist(),valid=valid.tolist(),active_bounds=int(np.count_nonzero(np.minimum(fit.coordinates-(q0-widths),(q0+widths)-fit.coordinates)<1e-6)))
   frame_records.append(rec)
 passing=[r for r in frame_records if r['converged'] and r['closure_gate'] and r['yaw_gate']]
 if passing:previous=np.array(min(passing,key=lambda r:r['marker_rms_m'])['coordinates'])
 results.extend(frame_records)
 receipt=dict(qualification='sampled local static pose searches; not dynamics or global lower bound',dependency_commit='0db3c295a7f668789afbb4666f60912294f81cce',marker_labels=doc['marker_labels'],capture_sha256=doc['capture_sha256'],elapsed_s=time.perf_counter()-started,completed_frames=len(results)//8,planned_frames=len(frames),records=results)
 Path('receipt.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(dict(time_s=float(clock[frame]),best_allowed_mm=min([r['marker_rms_m']*1000 for r in passing],default=None),converged=sum(r['converged'] for r in frame_records))),flush=True)
print('Completed',flush=True)
