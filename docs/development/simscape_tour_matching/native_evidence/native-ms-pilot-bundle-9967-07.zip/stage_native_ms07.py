from pathlib import Path
import shutil
source=Path('/home/dieterolson/native-ms-pilot-9967-06');dest=Path('/home/dieterolson/native-ms-pilot-9967-07')
assert source.is_dir() and not dest.exists()
shutil.copytree(source,dest)
shutil.copyfile('/mnt/c/Users/diete/multi_shooting_fit_1d84cfc8e.py',dest/'src/shared/python/motion_matching/multi_shooting_fit.py')
