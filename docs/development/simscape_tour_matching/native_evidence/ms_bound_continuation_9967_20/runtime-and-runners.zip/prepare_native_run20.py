"""Prepare one explicit bound continuation from the terminal run19 artifact."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = root.parent / "Worktrees/UpstreamDrift-pinocchio-native"
files = root / "runtime20-files"
files.mkdir(exist_ok=False)
module = repo / "src/shared/python/motion_matching/native_restart.py"
(files / module.name).write_bytes(module.read_bytes())
(files / "manifest.json").write_text(json.dumps({module.name: hashlib.sha256(module.read_bytes()).hexdigest()}, indent=2))
text = (root / "run_native_ms_recentered_9967_19b.py").read_text()
text = text.replace("import prepare_native_restart", "import prepare_native_restart,widen_control_envelope")
text = text.replace("native-ms-fit-9967-18/returned-candidate.json", "native-ms-fit-9967-19/returned-candidate.json")
text = text.replace("917d2d29b66bc2ab947a6ea75255c35e47134e6a2d51cde7e1e69847cad379f7", "b5b1c3823c86a21df323dc4e430366dc093495b069b3d25c361b0d007b8ff24f")
anchor = "restart=prepare_native_restart("
assert text.count(anchor) == 1
policy = '''prior_run=root/'native-ms-fit-9967-19'
prior_run_config=json.loads((prior_run/'config.json').read_text())
bound_report=json.loads((prior_run/'bound-audit.json').read_text())
assert bound_report['candidate_sha256']==source_seed.sha256
assert np.array_equal(lower_effort,prior_run_config['lower_effort']) and np.array_equal(upper_effort,prior_run_config['upper_effort'])
selected=np.zeros((n,7),dtype=bool)
for item in bound_report['efforts']:
 selected[names.index(item['coordinate']),item['bernstein_index']]=True
recovered=recover_native_bernstein(base,seed,basis_duration_s=args.basis_duration).ravel()
actual=np.isclose(recovered,lower_effort,rtol=0,atol=1e-8)|np.isclose(recovered,upper_effort,rtol=0,atol=1e-8)
assert np.array_equal(selected.ravel(),actual) and selected.sum()==71
old_lower=lower_effort.copy();old_upper=upper_effort.copy()
lower_effort,upper_effort=[a.ravel() for a in widen_control_envelope(lower_effort.reshape(n,7),upper_effort.reshape(n,7),selected,factor=2.)]
policy={'qualification':'Explicit numerical control-bound continuation; not physical actuator limits','parent_candidate_sha256':source_seed.sha256,'bound_report_sha256':hashlib.sha256((prior_run/'bound-audit.json').read_bytes()).hexdigest(),'selected_count':int(selected.sum()),'selected_controls':np.argwhere(selected).tolist(),'factor':2.,'old_lower':old_lower.tolist(),'old_upper':old_upper.tolist(),'new_lower':lower_effort.tolist(),'new_upper':upper_effort.tolist(),'variable_scales_policy':'Frozen run19 vector; no scaling change with widened bounds','chart_centers_policy':'Own reconstructed run19 candidate continuous replay; original q0/qd0'}
(out/'bound-continuation.json').write_text(json.dumps(policy,indent=2)+'\\n')
'''
text = text.replace(anchor, policy + anchor)
old = "variable_scales=np.r_[.5*(upper_effort-lower_effort),np.full(sum(len(z) for z in node_initial.values()),args.node_bound)]"
assert old in text
text = text.replace(old, "variable_scales=np.array(prior_run_config['variable_scales']);assert variable_scales.shape==(189+sum(len(z) for z in node_initial.values()),)")
text = text.replace("run18 reconstructed continuous references; original parent/bounds; no physical state reset", "run19 reconstructed continuous references; original parent; selected bounds expanded; no physical state reset")
text = text.replace("'new_B0_B1_bounds':[-2,2]", "'B0_B1_bound_policy':'See per-entry lower_effort/upper_effort and bound-continuation.json'")
text = text.replace("strict source-state comparison remains failed", "source-state comparison reported separately")
path = root / "run_native_ms_bound_continuation_9967_20.py"
assert not path.exists()
path.write_text(text)
stage = (root / "stage_native_runtime_9967_19.py").read_text()
stage = stage.replace("source=Path('/home/dieterolson/native-ms-pilot-9967-18')", "source=Path('/home/dieterolson/native-ms-pilot-9967-19')")
stage = stage.replace("dest=Path('/home/dieterolson/native-ms-pilot-9967-19')", "dest=Path('/home/dieterolson/native-ms-pilot-9967-20')")
stage = stage.replace("runtime19", "runtime20")
(root / "stage_native_runtime_9967_20.py").write_text(stage)
