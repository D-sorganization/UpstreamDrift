"""Qualify native projected equalities and feasible objective derivatives."""
import json,runpy,sys
from pathlib import Path
import numpy as np
from src.shared.python.motion_matching import multi_shooting_fit as shared
root=Path('/mnt/c/Users/diete');out=root/'native-ms-constrained-audit-9967-14'
def audit(fun,jac,x0,lower,upper,**kwargs):
 r=fun(x0);J=jac(x0);P=kwargs['projection'];start=kwargs['equality_start'];end=start+P.shape[1]
 C=P@J[start:end];c=P@r[start:end];mask=np.ones(len(r),dtype=bool);mask[start:end]=False
 rm,Jm=r[mask],J[mask]
 _,s,Vt=np.linalg.svd(C,full_matrices=True);rank=int(np.sum(s>s[0]*1e-10));assert rank==P.shape[0]
 Z=Vt[rank:].T;scale=np.r_[np.ones(189),np.full(len(x0)-189,.01)]
 rng=np.random.default_rng(9967);v=scale*rng.normal(size=len(x0));v=Z@(Z.T@v)
 g=Z@(Z.T@(2*Jm.T@rm));rows=[]
 for name,direction in [('feasible_random',v),('feasible_gradient',g)]:
  direction=direction/np.linalg.norm(direction/scale)
  predicted=2*float(rm@(Jm@direction));predicted_c=C@direction
  for h in [1e-5,1e-6]:
   assert np.all(x0+h*direction<upper) and np.all(x0-h*direction>lower)
   plus=fun(x0+h*direction);minus=fun(x0-h*direction)
   fd_c=P@(plus[start:end]-minus[start:end])/(2*h)
   fd_cost=float((plus[mask]@plus[mask]-minus[mask]@minus[mask])/(2*h))
   rows.append({'direction':name,'h':h,'predicted_cost_slope':predicted,'fd_cost_slope':fd_cost,'cost_slope_relative_error':abs(fd_cost-predicted)/max(abs(fd_cost),abs(predicted),1e-30),'constraint_direction_error_max_abs':float(np.max(abs(fd_c-predicted_c))),'predicted_constraint_direction_max_abs':float(np.max(abs(predicted_c)))})
 report={'qualification':'Native projected-equality and feasible-direction audit only; no optimization','variables':len(x0),'projected_equalities':P.shape[0],'physical_defect_rows':P.shape[1],'constraint_jacobian_rank':rank,'initial_projected_max_abs':float(np.max(abs(c))),'initial_physical_defect_norm':float(np.linalg.norm(r[start:end])),'marker_objective':float(rm@rm),'constraint_singular_max':float(s[0]),'constraint_singular_min':float(s[-1]),'checks':rows}
 (out/'constraint-audit.json').write_text(json.dumps(report,indent=2)+'\n')
 raise SystemExit(0)
shared.solve_equality_least_squares=audit
sys.argv=['run_native_ms_constrained_9967_14.py','--output',str(out),'--max-nfev','24','--max-iterations','12','--horizon','.85','--nodes','.2','.4','.6','.7','.8','.85','--basis-duration','.8']
runpy.run_path(str(root/'run_native_ms_constrained_9967_14.py'),run_name='__main__')
