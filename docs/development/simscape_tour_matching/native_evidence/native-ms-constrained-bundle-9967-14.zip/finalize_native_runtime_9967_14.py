import hashlib,json,shutil
from pathlib import Path
root=Path('/mnt/c/Users/diete');dest=Path('/home/dieterolson/native-ms-pilot-9967-14');files=root/'runtime14-files'
assert not (root/'native-ms-constrained-audit-9967-14').exists()
old=json.loads((dest/'runtime14-manifest.json').read_text())
for name,digest in old.items():assert hashlib.sha256((dest/'src/shared/python/motion_matching'/name).read_bytes()).hexdigest()==digest
new=json.loads((files/'manifest.json').read_text())
for name,digest in new.items():assert hashlib.sha256((files/name).read_bytes()).hexdigest()==digest
for name in new:shutil.copyfile(files/name,dest/'src/shared/python/motion_matching'/name)
(dest/'runtime14-manifest.json').write_text(json.dumps(new,indent=2)+'\n')
