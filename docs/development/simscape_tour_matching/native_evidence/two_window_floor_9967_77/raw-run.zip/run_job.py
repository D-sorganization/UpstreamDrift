"""Record-keeping launcher: runs one command, writes launch JSON with pid/exit."""
import json, os, subprocess, sys, time
launch = sys.argv[1]
spec = json.load(open(launch))
env = {**os.environ, **spec["environment"]}
out = open(spec["stdout"], "ab"); err = open(spec["stderr"], "ab")
start = time.time()
proc = subprocess.Popen(spec["command"], env=env, cwd=spec["cwd"], stdout=out, stderr=err)
spec.update(status="running", pid=proc.pid, start_time=start, launcher_pid=os.getpid())
json.dump(spec, open(launch, "w"), indent=2)
code = proc.wait()
spec.update(status="terminal", exit_code=code, elapsed_s=time.time() - start)
json.dump(spec, open(launch, "w"), indent=2)
