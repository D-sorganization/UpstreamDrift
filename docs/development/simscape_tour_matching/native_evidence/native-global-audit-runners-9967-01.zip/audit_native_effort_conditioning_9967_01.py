"""Audit native constrained effort response along an immutable replay."""
import hashlib,json
from pathlib import Path
import numpy as np
from src.engines.physics_engines.pinocchio.python.native_model import NativePinocchioModel
from src.engines.physics_engines.pinocchio.python.native_replay import replay_candidate
from src.shared.python.motion_matching.native_candidate import NativeReplayCandidate
root=Path('/mnt/c/Users/diete');out=root/'native-effort-conditioning-9967-01.json'
if out.exists():raise FileExistsError(out)
raw=(root/'native_geometry_spec_9967.json').read_bytes();spec=json.loads(raw);names=spec['coordinate_order'];n=len(names);cp=root/'native-ms-fit-9967-08/returned-candidate.json';candidate=NativeReplayCandidate.from_document(json.loads(cp.read_text()),names,hashlib.sha256(raw).hexdigest());t=np.array([0.,.4,.6,.65,.7,.75,.8]);replay=replay_candidate(raw,candidate,t,rtol=1e-11,atol=1e-13,max_step=.00025);engine=NativePinocchioModel(spec);zero=dict.fromkeys(names,0.);rows=[]
for time,x in zip(t,replay.integration.state):
 q=dict(zip(names,x[:n]));v=dict(zip(names,x[n:]));r=engine.acceleration_derivatives(q,v,zero);G=r.deffort;sv=np.linalg.svd(G,compute_uv=False);threshold=sv[0]*1e-10;active=sv[sv>threshold]
 rows.append({'time_s':float(time),'active_rank_relative_1e_minus_10':len(active),'largest_gain':float(sv[0]),'smallest_retained_gain':float(active[-1]),'retained_condition_ratio':float(active[0]/active[-1]),'symmetry_max_abs':float(abs(G-G.T).max()),'singular_values':sv.tolist(),'max_absolute_coordinate_rate':float(abs(x[n:]).max())})
report={'qualification':'Instantaneous primitive effort-to-acceleration response in raw native coordinate units; numerical rank depends on stated cutoff. Not a trajectory optimizer condition number or proof of cause. Zero effort derivative evaluation is valid for effort-linear rigid dynamics.','candidate_sha256':candidate.sha256,'model_sha256':hashlib.sha256(raw).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
out.write_text(json.dumps(report,indent=2)+'\n')
