"""Audit assembled native shooting residual derivatives without optimizing."""
import json,runpy,sys
from pathlib import Path
import numpy as np
from src.shared.python.motion_matching import multi_shooting_fit as shared
root=Path('/mnt/c/Users/diete');out=root/'native-ms-global-jac-audit-9967-01'
def audit(fun,x0,**kwargs):
 r=fun(x0);J=kwargs['jac'](x0);scale=np.r_[np.ones(189),np.full(len(x0)-189,.01)];rng=np.random.default_rng(9967)
 v=scale*rng.normal(size=len(x0));v/=np.linalg.norm(v/scale)
 g=J.T@r;w=scale*scale*g;w/=np.linalg.norm(w/scale)
 rows=[]
 for label,direction in [('random',v),('gradient',w)]:
  expected=J@direction
  for h in [1e-4,1e-5,1e-6]:
   plus=fun(x0+h*direction);minus=fun(x0-h*direction);fd=(plus-minus)/(2*h)
   actual_cost=float((plus@plus-minus@minus)/(2*h));expected_cost=float(2*r@expected)
   rows.append({'direction':label,'h':h,'residual_relative_error':float(np.linalg.norm(fd-expected)/max(np.linalg.norm(fd),1e-30)),'predicted_cost_slope':expected_cost,'finite_difference_cost_slope':actual_cost,'cost_slope_relative_error':abs(actual_cost-expected_cost)/max(abs(actual_cost),1e-30)})
 report={'qualification':'Assembled residual directional derivative audit at restored run08 initial point; no optimization performed','parameter_count':len(x0),'residual_count':len(r),'initial_cost':float(r@r),'checks':rows}
 (out/'global-jacobian-audit.json').write_text(json.dumps(report,indent=2)+'\n')
 raise SystemExit(0)
shared.least_squares=audit
sys.argv=['run_native_ms_pilot_9967_09.py','--output',str(out),'--max-nfev','1','--defect-weight','100']
runpy.run_path(str(root/'run_native_ms_pilot_9967_09.py'),run_name='__main__')
