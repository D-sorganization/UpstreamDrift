"""Compare terminal shooting-window and independent continuous marker errors."""
import hashlib,json
from pathlib import Path
import numpy as np
from src.engines.physics_engines.pinocchio.python.native_replay import replay_window
from src.shared.python.motion_matching.native_candidate import NativeReplayCandidate
root=Path('/mnt/c/Users/diete');out=root/'native-terminal-gap-audit-9967-01.json'
if out.exists():raise FileExistsError(out)
raw=(root/'native_geometry_spec_9967.json').read_bytes();spec=json.loads(raw);model_hash=hashlib.sha256(raw).hexdigest()
payload=json.loads((root/'driver_marker_payload_9967.json').read_text());rows=[]
for number in ['08','10']:
 run=root/f'native-ms-fit-9967-{number}'
 c=NativeReplayCandidate.from_document(json.loads((run/'returned-candidate.json').read_text()),spec['coordinate_order'],model_hash)
 assert payload['source_sha256']==c.document['capture_sha256']
 nodes=json.loads((run/'returned-nodes.json').read_text());state=np.array(nodes['0.7'])
 idx=[payload['labels'].index(x) for x in c.document['marker_labels']]
 time=np.array(payload['time_s']);mask=(time>=.7)&(time<=.8);clock=time[mask]
 assert clock[0]==.7 and clock[-1]==.8
 pred=replay_window(raw,c,clock,state,rtol=1e-11,atol=1e-13,max_step=.00025).markers_m[-1]
 target=np.array(payload['points_world_m'])[mask][-1,idx];valid=np.array(payload['valid'],bool)[mask][-1,idx]&np.isfinite(target).all(axis=1)
 with np.load(run/('visual-replay.npz' if number=='08' else 'independent-replay.npz'),allow_pickle=False) as z:
  assert str(z['candidate_sha256'])==c.sha256
  full=z['prediction_m'][-1]
 segmented=float(np.sqrt(np.mean(np.sum((pred[valid]-target[valid])**2,axis=1))))
 continuous=float(np.sqrt(np.mean(np.sum((full[valid]-target[valid])**2,axis=1))))
 gap=float(np.sqrt(np.mean(np.sum((pred[valid]-full[valid])**2,axis=1))))
 rows.append({'run':number,'candidate_sha256':c.sha256,'terminal_segmented_rms_m':segmented,'terminal_continuous_rms_m':continuous,'segmented_vs_continuous_terminal_rms_m':gap,'weighted_terminal_cost':100*int(valid.sum())*segmented**2,'observed_count':int(valid.sum())})
out.write_text(json.dumps({'qualification':'Fresh final shooting-window replay versus saved independently replayed continuous endpoint; no optimization','rows':rows},indent=2)+'\n')

