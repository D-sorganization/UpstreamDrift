from pathlib import Path
import json,importlib.util,sys
import numpy as np
from src.engines.physics_engines.pinocchio.python.native_model import NativePinocchioModel
root=Path('/home/dieterolson/native-clean-replay-20260917-01')
spec=json.loads((root/'model.bin').read_bytes());candidate=json.loads((root/'candidate.json').read_text());names=candidate['coordinate_names']
loader=importlib.util.spec_from_file_location('corrected_native',Path('corrected_native.py'));module=importlib.util.module_from_spec(loader);sys.modules[loader.name]=module;loader.loader.exec_module(module)
reference=np.load(root/'reference.npz')
records=[]
for label,cls in [('current',NativePinocchioModel),('pr10263',module.NativePinocchioModel)]:
 plant=cls(spec)
 for state_label,values in [('initial',candidate['q0']),('terminal',reference['native_state'][-1,:len(names)])]:
  for offset in [0.0,0.1,-0.4]:
   pose=dict(zip(names,map(float,values),strict=True));pose['LWInputX']+=offset;pose['LWInputY']-=offset/2
   linear=plant.closure_position_linearization(pose);errors=[];passed=True
   rng=np.random.default_rng(10260)
   for step in [1e-5,1e-6,1e-7]:
    for _ in range(3):
     direction=rng.normal(size=len(names));direction/=np.linalg.norm(direction)
     samples=[plant.closure_residuals({n:pose[n]+sign*step*direction[i] for i,n in enumerate(names)})[0] for sign in [-1,1]]
     observed=(samples[1]-samples[0])/(2*step);predicted=linear.jacobian@direction
     errors.append(float(np.max(np.abs(observed-predicted))))
     passed=passed and bool(np.allclose(observed,predicted,rtol=2e-6,atol=2e-7))
   records.append({'provider':label,'state':state_label,'wrist_offset_rad':offset,'max_absolute_directional_error':max(errors),'passed':passed})
result={'qualification':'native finite weld position derivative only; not optimizer or acceleration/reaction qualification','dependency_commit':'0db3c295a7f668789afbb4666f60912294f81cce','records':records}
Path('receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
