from pathlib import Path
import shutil
source=Path('/home/dieterolson/native-ms-pilot-9967-07');dest=Path('/home/dieterolson/native-ms-pilot-9967-09')
assert source.is_dir() and not dest.exists()
shutil.copytree(source,dest)
shutil.copyfile('/mnt/c/Users/diete/multi_shooting_fit_47049e7f8.py',dest/'src/shared/python/motion_matching/multi_shooting_fit.py')
