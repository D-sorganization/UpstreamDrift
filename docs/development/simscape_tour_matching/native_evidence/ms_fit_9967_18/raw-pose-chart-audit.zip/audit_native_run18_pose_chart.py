"""Read-only lower bound on static pose displacement from the run18 chart."""
import hashlib
import json
from pathlib import Path

import numpy as np

root = Path(__file__).parent
paths = {
    "pose": root / "native-transition-pose-9967-02.json",
    "initial": root / "native-ms-fit-9967-18/evaluation-00001.json",
    "config": root / "native-ms-fit-9967-18/config.json",
}
docs = {key: json.loads(path.read_text()) for key, path in paths.items()}
assert docs["pose"]["input_sha256"]["model"] == docs["config"]["model_sha256"]
pose = next(row for row in docs["pose"]["poses"] if row["time_s"] == 0.8)
q = np.asarray(pose["coordinates"])
reference = np.asarray(docs["initial"]["physical_nodes"]["0.8"])
scale = np.asarray(docs["config"]["defect_scales"])[:len(q)]
delta = q - reference[:len(q)]
wrapped = delta.copy()
wrapped[3:] = (wrapped[3:] + np.pi) % (2 * np.pi) - np.pi
report = {
    "qualification": "Saved static pose versus initial shooting chart; no dynamic reachability or global impossibility claim",
    "input_sha256": {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in paths.items()},
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "time_s": 0.8,
    "static_marker_rms_m": pose["marker_rms_m"],
    "chart_radius": 0.5,
    "position_only_scaled_displacement_norm": float(np.linalg.norm(delta / scale)),
    "position_only_wrapped_scaled_displacement_norm": float(np.linalg.norm(wrapped / scale)),
    "max_abs_wrapped_rotation_rad": float(np.max(abs(wrapped[3:]))),
    "limitation": "Velocities omitted, hence a lower bound on full displacement. Wrapping removes individual 2*pi shifts only; alternate Euler branches not searched. Radius checked against immutable runtime18 implementation.",
}
with (root / "native-run18-pose-chart-audit.json").open("x") as stream:
    json.dump(report, stream, indent=2)
