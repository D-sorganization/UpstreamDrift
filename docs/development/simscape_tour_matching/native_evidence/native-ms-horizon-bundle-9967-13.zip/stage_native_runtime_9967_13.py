import hashlib,json,shutil
from pathlib import Path
source=Path('/home/dieterolson/native-ms-pilot-9967-09');dest=Path('/home/dieterolson/native-ms-pilot-9967-13');files=Path('/mnt/c/Users/diete/runtime13-files')
assert not dest.exists()
manifest=json.loads((files/'manifest.json').read_text())
for name,digest in manifest.items():assert hashlib.sha256((files/name).read_bytes()).hexdigest()==digest
shutil.copytree(source,dest)
for name in manifest:
 relative='src/engines/physics_engines/pinocchio/python' if name=='native_sensitivity.py' else 'src/shared/python/motion_matching'
 shutil.copyfile(files/name,dest/relative/name)
(dest/'runtime13-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
