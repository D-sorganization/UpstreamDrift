"""Reconstruct native chart coordinates and classify active optimization bounds."""
import hashlib,json
from pathlib import Path
import numpy as np
from src.engines.physics_engines.pinocchio.python.native_model import NativePinocchioModel
from src.engines.physics_engines.pinocchio.python.native_replay import replay_candidate
from src.shared.python.motion_matching.native_candidate import NativeReplayCandidate,recover_native_bernstein
from src.shared.python.motion_matching.node_retraction import retract_node
root=Path('/mnt/c/Users/diete');run=root/'native-ms-fit-9967-19';out=run/'bound-audit.json'
assert not out.exists()
raw=(root/'native_geometry_spec_9967.json').read_bytes();spec=json.loads(raw);names=spec['coordinate_order'];n=len(names);digest=hashlib.sha256(raw).hexdigest()
def load(path):return NativeReplayCandidate.from_document(json.loads(path.read_text()),names,digest)
c=load(run/'returned-candidate.json');config=json.loads((run/'config.json').read_text())
def covered(path):
 doc=load(path).document;doc['duration_s']=c.document['duration_s']
 return NativeReplayCandidate.from_document(doc,names,digest)
base=covered(root/'native-root-force-9967-02/returned-candidate.json');seed=load(run/'initial-candidate.json');assert seed.sha256==config['seed']
controls=recover_native_bernstein(base,c,basis_duration_s=config['basis_duration_s']).ravel();lo=np.array(config['lower_effort']);hi=np.array(config['upper_effort'])
active=np.isclose(controls,lo,rtol=0,atol=1e-8)|np.isclose(controls,hi,rtol=0,atol=1e-8)
efforts=[{'coordinate':names[i//7],'bernstein_index':int(i%7),'value':float(controls[i]),'lower':float(lo[i]),'upper':float(hi[i])} for i in np.flatnonzero(active)]
payload=json.loads((root/'driver_marker_payload_9967.json').read_text());clock=np.array(payload['time_s']);clock=clock[clock<=config['horizon']]
reference=replay_candidate(raw,seed,clock,rtol=1e-11,atol=1e-13,max_step=.00025)
engine=NativePinocchioModel(spec);d=np.array(config['defect_scales']);cs=np.r_[np.full(6,.01),np.full(6,.1)]
def closure(x):
 engine.accelerations(dict(zip(names,x[:n])),dict(zip(names,x[n:])),dict.fromkeys(names,0.));return np.concatenate(engine.closure_errors())
def cj(x):
 h=1e-6;eye=np.eye(2*n);return np.column_stack([(closure(x+h*e)-closure(x-h*e))/(2*h) for e in eye])
rows=[]
for key,values in json.loads((run/'returned-nodes.json').read_text()).items():
 time=float(key);x=np.array(values);ref=reference.integration.state[int(np.flatnonzero(clock==time)[0])]
 _,sv,vt=np.linalg.svd(cj(ref)*d/cs[:,None],full_matrices=True);assert sv[-1]>1e-6;basis=vt[12:].T;z=basis.T@((x-ref)/d)
 restored=retract_node(ref,basis,z,closure,cj,state_scales=d,residual_scales=cs,radius=.5,tolerance=1e-8)
 error=float(np.max(abs(restored.state-x)));assert error<1e-7
 bound=np.isclose(z,config['node_box'][0],rtol=0,atol=1e-8)|np.isclose(z,config['node_box'][1],rtol=0,atol=1e-8)
 rows.append({'time_s':time,'active_node_coordinates':int(bound.sum()),'max_abs_chart_coordinate':float(np.max(abs(z))),'reconstruction_max_abs':error,'physical_scaled_displacement_norm':float(np.linalg.norm((x-ref)/d)),'active_indices':np.flatnonzero(bound).tolist()})
report={'qualification':'Fresh reconstruction of original charts and existing optimization bounds; no physical-limit or optimality claim','candidate_sha256':c.sha256,'active_effort_controls':len(efforts),'active_node_coordinates':sum(row['active_node_coordinates'] for row in rows),'efforts':efforts,'nodes':rows}
report['total_active']=report['active_effort_controls']+report['active_node_coordinates'];assert report['total_active']==json.loads((run/'returned.json').read_text())['active_bound_count']
out.write_text(json.dumps(report,indent=2)+'\n')


