from pathlib import Path
import hashlib,json,shutil
source=Path('/home/dieterolson/native-ms-pilot-9967-18');dest=Path('/home/dieterolson/native-transition-pose-9967-01');extra=Path('/mnt/c/Users/diete/constrained_marker_pose_9967_18.py')
assert not dest.exists()
shutil.copytree(source,dest)
shutil.copy2(extra,dest/'src/shared/python/motion_matching/constrained_marker_pose.py')
(dest/'pose-runtime-manifest.json').write_text(json.dumps({'parent':str(source),'constrained_marker_pose.py':hashlib.sha256(extra.read_bytes()).hexdigest()},indent=2))
