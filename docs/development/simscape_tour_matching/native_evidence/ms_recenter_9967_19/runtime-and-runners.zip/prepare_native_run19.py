"""Stage a controlled run18 restart without changing the qualified runtime."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = root.parent / "Worktrees/UpstreamDrift-pinocchio-native"
files = root / "runtime19-files"
files.mkdir(exist_ok=False)
module = repo / "src/shared/python/motion_matching/native_restart.py"
(files / module.name).write_bytes(module.read_bytes())
(files / "manifest.json").write_text(json.dumps({module.name: hashlib.sha256(module.read_bytes()).hexdigest()}, indent=2))
text = (root / "run_native_ms_scaled_9967_18.py").read_text()
text = text.replace("from src.shared.python.motion_matching.node_retraction import retract_node", "from src.shared.python.motion_matching.node_retraction import retract_node\nfrom src.shared.python.motion_matching.native_restart import prepare_native_restart")
text = text.replace("native-ms-fit-9967-12/returned-candidate.json", "native-ms-fit-9967-18/returned-candidate.json")
text = text.replace("510b7a35152d9bd050be5b95e432c4619171f6a6385e683eab070566eeae02a3", "917d2d29b66bc2ab947a6ea75255c35e47134e6a2d51cde7e1e69847cad379f7")
old = "initial=recover_native_bernstein(base,seed,basis_duration_s=args.basis_duration)[:,:].ravel()"
assert old in text
text = text.replace(old, "")
old = "assert np.all(initial>=lower_effort-1e-8) and np.all(initial<=upper_effort+1e-8)"
assert old in text
text = text.replace(old, "restart=prepare_native_restart(base,seed,basis_duration_s=args.basis_duration,lower_controls=lower_effort.reshape(n,7),upper_controls=upper_effort.reshape(n,7),roundoff_tolerance=1e-10)\nseed=restart.candidate;initial=restart.controls.copy().ravel()\nassert np.all(initial>=lower_effort) and np.all(initial<=upper_effort)")
anchor = "nodes={time:continuous.integration.state"
assert anchor in text
audit = '''source_replay=replay_candidate(raw,covered(source_seed),t,rtol=1e-11,atol=1e-13,max_step=.00025)
delta=continuous.integration.state-source_replay.integration.state
restart_audit={'qualification':'Restart reconstruction only; not fit acceptance','source_candidate_sha256':source_seed.sha256,'reconstructed_candidate_sha256':seed.sha256,'max_bound_snap':restart.max_bound_snap,'snapped_control_count':restart.snapped_control_count,'q_max_abs':float(np.max(abs(delta[:,:n]))),'qd_max_abs':float(np.max(abs(delta[:,n:]))),'marker_max_distance_m':float(np.max(np.linalg.norm(continuous.markers_m-source_replay.markers_m,axis=2)))}
restart_audit['passed']=restart_audit['q_max_abs']<=1e-6 and restart_audit['qd_max_abs']<=1e-4 and restart_audit['marker_max_distance_m']<=1e-7
(out/'restart-audit.json').write_text(json.dumps(restart_audit,indent=2)+'\\n')
(out/'initial-candidate.json').write_text(json.dumps(seed.document,indent=2)+'\\n')
assert restart_audit['passed'], 'Restart primal reconstruction audit failed'
'''
text = text.replace(anchor, audit + anchor)
text = text.replace("'run12 continuous references at configurable nodes; no old-chart restart'", "'run18 reconstructed continuous references; original parent/bounds; no physical state reset'")
old = "for col in [0,36]:"
assert old in text
text = text.replace(old, "early_columns=[next(col for col in range(control,189,7) if min(initial[col]-lower_effort[col],upper_effort[col]-initial[col])>1e-5) for control in [0,1]]\nfor col in early_columns:")
path = root / "run_native_ms_recentered_9967_19.py"
assert not path.exists()
path.write_text(text)
stage = (root / "stage_native_runtime_9967_18.py").read_text()
stage = stage.replace("native-ms-pilot-9967-14", "native-ms-pilot-9967-18")
stage = stage.replace("dest=Path('/home/dieterolson/native-ms-pilot-9967-18')", "dest=Path('/home/dieterolson/native-ms-pilot-9967-19')")
stage = stage.replace("runtime18", "runtime19")
(root / "stage_native_runtime_9967_19.py").write_text(stage)
