import hashlib,json,shutil
from pathlib import Path
source=Path('/home/dieterolson/native-ms-pilot-9967-18');dest=Path('/home/dieterolson/native-ms-pilot-9967-19');files=Path('/mnt/c/Users/diete/runtime19-files')
assert not dest.exists()
manifest=json.loads((files/'manifest.json').read_text())
for name,digest in manifest.items():assert hashlib.sha256((files/name).read_bytes()).hexdigest()==digest
shutil.copytree(source,dest)
for name in manifest:shutil.copyfile(files/name,dest/'src/shared/python/motion_matching'/name)
(dest/'runtime19-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
