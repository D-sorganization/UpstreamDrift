"""Fourth-order forward integration in rebased local configuration charts.

Configuration dimension nq and tangent dimension nv are independent. Each step
integrates chart displacement u and tangent velocity v with classical RK4,
then changes the chart anchor without changing the physical state. There are no
constraint projections, target states, feedback, or intermediate state resets.
"""

from collections.abc import Callable
from math import ceil
from time import perf_counter
from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray

Array = NDArray[np.float64]
Acceleration = Callable[[float, Array, Array], Array]
Retraction = Callable[[Array, Array], Array]
DifferenceRate = Callable[[Array, Array, Array], Array]


class ManifoldForwardResult(NamedTuple):
    """Owned read-only samples, with explicit configuration/tangent dimensions."""

    time: Array
    configuration: Array
    velocity: Array
    evaluations: int
    steps: int
    elapsed_s: float


def _vector(value: Array, size: int, name: str) -> Array:
    result = np.array(value, dtype=float, copy=True)
    if result.shape != (size,) or not np.isfinite(result).all():
        raise ValueError(f"{name} must return a finite vector of length {size}")
    result.setflags(write=False)
    return result


def integrate_manifold_forward(
    initial_configuration: Array,
    initial_velocity: Array,
    time: Array,
    acceleration: Acceleration,
    *,
    integrate: Retraction,
    difference_rate: DifferenceRate,
    max_step: float = 0.001,
) -> ManifoldForwardResult:
    """Integrate one initial state, landing exactly at all requested sample times.

    `integrate(anchor,u)` retracts an nv displacement into nq configuration.
    `difference_rate(anchor,q,v)` computes the time derivative of
    difference(anchor,q) when q's instantaneous tangent velocity is v. It is
    generally NOT equal to v. Adapters own chart validity and branch rejection.
    Acceleration receives absolute physical time, current q and tangent v;
    its output is the derivative of that velocity convention. Callback inputs
    are read-only, outputs must be finite with the exact stated dimensions.

    This fixed-step solver has no adaptive error estimate. Acceptance requires
    step refinement on the actual problem, including constraints and effort
    conversion. max_step bounds every numerical step; sample boundaries may
    make individual steps shorter. Failure raises instead of returning a partial
    trajectory as successful. It does not normalize/project engine state.
    """
    initial_q = np.array(initial_configuration, dtype=float, copy=True)
    initial_v = np.array(initial_velocity, dtype=float, copy=True)
    for name, value in (
        ("initial_configuration", initial_q),
        ("initial_velocity", initial_v),
    ):
        if value.ndim != 1 or not value.size or not np.isfinite(value).all():
            raise ValueError(f"{name} must be a nonempty finite vector")
    clock = np.array(time, dtype=float, copy=True)
    if (
        clock.ndim != 1
        or clock.size < 2
        or not np.isfinite(clock).all()
        or clock[0] != 0
        or np.any(np.diff(clock) <= 0)
    ):
        raise ValueError("time must be finite and strictly increasing from zero")
    if not np.isfinite(max_step) or max_step <= 0:
        raise ValueError("max_step must be finite and positive")
    nq, nv = initial_q.size, initial_v.size
    q_samples, v_samples = np.empty((clock.size, nq)), np.empty((clock.size, nv))
    q_samples[0], v_samples[0] = initial_q, initial_v
    q, v = _vector(initial_q, nq, "initial_configuration"), initial_v
    steps = 0
    start = perf_counter()
    for sample in range(1, clock.size):
        t0, t1 = float(clock[sample - 1]), float(clock[sample])
        quotient = (t1 - t0) / max_step
        if not np.isfinite(quotient):
            raise ValueError("max_step is too small for the sample interval")
        count = max(1, ceil(quotient))
        h = (t1 - t0) / count
        for step in range(count):
            anchor = q
            physical_time = t0 + step * h

            def derivative(
                t: float, u: Array, tangent: Array, chart_anchor: Array = anchor
            ) -> tuple[Array, Array]:
                displacement = _vector(u, nv, "local displacement")
                rate = _vector(tangent, nv, "stage velocity")
                state = _vector(integrate(chart_anchor, displacement), nq, "integrate")
                udot = _vector(
                    difference_rate(chart_anchor, state, rate), nv, "difference_rate"
                )
                vdot = _vector(acceleration(t, state, rate), nv, "acceleration")
                return udot, vdot

            k1u, k1v = derivative(physical_time, np.zeros(nv), v)
            k2u, k2v = derivative(physical_time + h / 2, h / 2 * k1u, v + h / 2 * k1v)
            k3u, k3v = derivative(physical_time + h / 2, h / 2 * k2u, v + h / 2 * k2v)
            endpoint = t1 if step == count - 1 else t0 + (step + 1) * h
            k4u, k4v = derivative(endpoint, h * k3u, v + h * k3v)
            u = h / 6 * (k1u + 2 * k2u + 2 * k3u + k4u)
            q = _vector(integrate(anchor, u), nq, "integrate")
            v = _vector(v + h / 6 * (k1v + 2 * k2v + 2 * k3v + k4v), nv, "velocity")
            steps += 1
        q_samples[sample], v_samples[sample] = q, v
    for value in (clock, q_samples, v_samples):
        value.setflags(write=False)
    return ManifoldForwardResult(
        clock, q_samples, v_samples, 4 * steps, steps, perf_counter() - start
    )
