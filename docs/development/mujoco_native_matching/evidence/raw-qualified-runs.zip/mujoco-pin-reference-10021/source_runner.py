"""Native Drake qualification against an independently saved Pinocchio replay."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import time
import numpy as np
from src.engines.physics_engines.pinocchio.python.native_model import NativePinocchioModel
from src.engines.physics_engines.pinocchio.python.native_replay import replay_candidate
from src.shared.python.motion_matching.native_candidate import NativeReplayCandidate

parser=argparse.ArgumentParser()
for key in ('model','candidate','output'):
    parser.add_argument('--'+key,type=Path,required=True)
parser.add_argument('--urdf',type=Path)
parser.add_argument('--sidecar',type=Path)
parser.add_argument('--reference',type=Path)
a=parser.parse_args()
assert not a.output.exists()
a.output.mkdir()
raw=a.model.read_bytes()
spec=json.loads(raw)
names=spec['coordinate_order']
candidate=NativeReplayCandidate.from_document(json.loads(a.candidate.read_text()),names,hashlib.sha256(raw).hexdigest())
clock=np.linspace(0,.8,81)
start=time.perf_counter()
if a.reference:
    from src.engines.physics_engines.drake.python.native_model import NativeDrakeModel
    factory=lambda _:NativeDrakeModel(a.urdf.read_bytes(),a.sidecar.read_bytes(),raw)
    ref=np.load(a.reference/'reference.npz')
    states=ref['state']
else:
    factory=NativePinocchioModel
    result=replay_candidate(raw,candidate,clock,model_factory=factory,rtol=1e-11,atol=1e-13,max_step=.00025)
    states=result.integration.state
engine=factory(spec)
indices=[0,40,60,70,75,80]
pulses=np.vstack((np.zeros(27),np.eye(27)))
accelerations=[]
frames=[]
for i in indices:
    q=dict(zip(names,states[i,:27]))
    v=dict(zip(names,states[i,27:]))
    frame=engine.frame_poses(q)
    frames.append([frame[key] for key in sorted(frame)])
    accelerations.append([[engine.accelerations(q,v,dict(zip(names,pulse)))[key] for key in names] for pulse in pulses])
accelerations=np.asarray(accelerations)
frames=np.asarray(frames)
report={'model_sha256':hashlib.sha256(raw).hexdigest(),'candidate_sha256':candidate.sha256,'coordinate_order':names,'pulse_times_s':clock[indices].tolist(),'engine':'drake' if a.reference else 'pinocchio'}
if a.reference:
    report['pulse_max_abs']=float(np.max(np.abs(accelerations-ref['accelerations'])))
    report['pulse_max_scaled']=float(np.max(np.abs(accelerations-ref['accelerations'])/(1+np.abs(ref['accelerations']))))
    report['frame_max_abs']=float(np.max(np.abs(frames-ref['frames'])))
    (a.output/'pulse-report.json').write_text(json.dumps(report,indent=2))
    assert report['pulse_max_scaled']<1e-7,report
    assert report['frame_max_abs']<1e-10,report
    result=replay_candidate(raw,candidate,clock,model_factory=factory,rtol=1e-11,atol=1e-13,max_step=.00025)
    report['state_q_max_abs']=float(np.max(np.abs(result.integration.state[:,:27]-states[:,:27])))
    report['state_v_max_abs']=float(np.max(np.abs(result.integration.state[:,27:]-states[:,27:])))
    report['marker_max_abs_m']=float(np.max(np.abs(result.markers_m-ref['markers'])))
    report['runtime_version']=importlib.metadata.version('drake')
report.update(closure_pose_max_abs=result.closure_pose_max_abs,closure_rate_max_abs=result.closure_velocity_max_abs,replay_elapsed_s=result.integration.elapsed_s,total_elapsed_s=time.perf_counter()-start)
np.savez_compressed(a.output/'reference.npz',time_s=clock,state=result.integration.state,markers=result.markers_m,accelerations=accelerations,frames=frames)
(a.output/'report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
