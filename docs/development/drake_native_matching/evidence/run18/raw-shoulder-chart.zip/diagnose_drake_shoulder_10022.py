from pathlib import Path
import json
import numpy as np
from scipy.spatial.transform import Rotation
base=Path('/mnt/c/Users/diete')
spec=json.loads((base/'native_geometry_spec_9967.json').read_bytes())
names=spec['coordinate_order']
joint=next(j for j in spec['joints'] if any(p['coordinate']=='LSInputX' for p in j['primitives']))
primitives=joint['primitives']
assert [p['primitive'] for p in primitives]==['Rx','Ry','Rz']
columns=[names.index(p['coordinate']) for p in primitives]
report={'scope':'Existing trajectory shoulder coordinate chart diagnostic; no integration or physical instability claim','joint':joint,'samples':[]}
for label in ('01','02'):
    for engine,prefix in (('pinocchio','drake-run18-pin-reference'),('drake','drake-run18-parity')):
        data=np.load(base/f'{prefix}-10022-{label}/trajectory.npz')
        i=int(np.argmin(np.abs(data['time_s']-.7861111111111111)))
        q=data['state'][i,columns]
        qd=data['state'][i,np.array(columns)+27]
        rx=Rotation.from_rotvec([q[0],0,0]).as_matrix()
        ry=Rotation.from_rotvec([0,q[1],0]).as_matrix()
        e=np.column_stack(([1,0,0],rx@np.array([0,1,0]),rx@ry@np.array([0,0,1])))
        sv=np.linalg.svd(e,compute_uv=False)
        report['samples'].append({'engine':engine,'case':label,'time_s':float(data['time_s'][i]),'coordinates':[p['coordinate'] for p in primitives],'q_rad':q.tolist(),'q_deg':np.rad2deg(q).tolist(),'qd_rad_s':qd.tolist(),'abs_cos_middle_angle':float(abs(np.cos(q[1]))),'angular_rate_map_singular_values':sv.tolist(),'angular_rate_map_condition':float(sv.max()/sv.min()),'relative_angular_velocity_in_joint_base_rad_s':(e@qd).tolist(),'relative_angular_speed_rad_s':float(np.linalg.norm(e@qd))})
output=base/'drake-run18-shoulder-chart-10022-01.json'
assert not output.exists()
output.write_text(json.dumps(report,indent=2))
print(json.dumps(report))
