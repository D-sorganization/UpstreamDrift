from pathlib import Path
import json
import numpy as np
from src.shared.python.motion_matching.prefix_fit import bernstein_to_simscape
from src.shared.python.motion_matching.native_effort_profile import NativeEffortProfile
base=Path('/mnt/c/Users/diete')
result=np.load(base/'native-reaction-identification-10022-01/identified.npz')
doc=json.loads((base/'native-root-force-9967-02/returned-candidate.json').read_bytes())
spec=json.loads((base/'native_geometry_spec_9967.json').read_bytes())
conversion=bernstein_to_simscape(np.eye(7),duration_s=.8)
known=np.linalg.solve(conversion.T,np.asarray(doc['coefficients']).T).T
root=next(j for j in spec['joints'] if j['parent']=='world')
r=np.asarray(root['parent_to_base'])[:3,:3].T
reference=NativeEffortProfile(spec['coordinate_order'],doc['coefficients'],r)
identified=NativeEffortProfile(spec['coordinate_order'],result['coefficients'],r)
error=np.array([[identified.evaluate(float(t))[name]-reference.evaluate(float(t))[name] for name in spec['coordinate_order']] for t in result['time_s']])
report={'known_control_max_abs':float(np.max(np.abs(known))),'recovered_control_max_abs_difference':float(np.max(np.abs(result['controls']-known))),'native_power_coefficient_max_abs_difference':float(np.max(np.abs(result['coefficients']-doc['coefficients']))),'sampled_primitive_effort_max_abs_difference':float(np.max(np.abs(error))),'scope':'Comparison against known baseline after identification; known controls were not supplied to least-squares'}
output=base/'native-reaction-identification-10022-01/known-profile-comparison.json'
assert not output.exists()
output.write_text(json.dumps(report,indent=2))
print(json.dumps(report))

